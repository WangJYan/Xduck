"""RSL-RL-specific training helpers."""

from __future__ import annotations

import json
import os
from collections.abc import Iterator
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import torch
from omegaconf import open_dict
from tensordict import TensorDict

from unilab.base.final_observation import resolve_terminal_observation_contract
from unilab.base.np_env import NpEnvState
from unilab.utils.tensor import to_numpy, to_torch


def restore_env_progress_from_runner(
    env: Any,
    runner: Any,
    *,
    num_steps_per_env: int,
    checkpoint_infos: dict | None = None,
    source_run_dir: Path | None = None,
) -> int:
    """Advance a loaded zero-based completed iteration to the next rollout.

    Call once after runner.load(), never on a fresh runner. RSL-RL saves
    iteration 999 after completing 1000 rollouts, but load restores 999.
    """
    next_iteration = int(runner.current_learning_iteration) + 1
    progress = (checkpoint_infos or {}).get("unilab_progress")
    if progress is not None:
        if progress["next_iteration"] != next_iteration:
            raise ValueError("Checkpoint progress does not match its iteration")
        restored_step = int(progress["env_steps_per_env"])
    elif source_run_dir is not None:
        config_path = source_run_dir / "run_config.json"
        if not config_path.is_file():
            raise ValueError(
                "Cannot restore curriculum without checkpoint progress or source run_config.json"
            )
        source = json.loads(config_path.read_text())["config"]["algo"]
        if str(source.get("load_run", "-1")) != "-1":
            raise ValueError("Legacy resumed checkpoint lacks cumulative environment progress")
        restored_step = next_iteration * int(source["num_steps_per_env"])
    else:
        restored_step = next_iteration * int(num_steps_per_env)
    runner.current_learning_iteration = next_iteration
    env.step_counter = restored_step
    return restored_step


def attach_checkpoint_progress(env: Any, runner: Any) -> None:
    """Persist actual cumulative environment steps at every checkpoint boundary."""
    original_save = runner.save

    def save_with_progress(path, infos=None):
        info = dict(infos or {})
        info["unilab_progress"] = {
            "version": 1,
            "env_steps_per_env": int(env.step_counter),
            "next_iteration": int(runner.current_learning_iteration) + 1,
        }
        return original_save(path, infos=info)

    runner.save = save_with_progress


def apply_rsl_rl_rank_seed(cfg: Any, rank: int) -> int:
    """Apply RSL-RL's ``base seed + global rank`` data-parallel contract."""
    if rank < 0:
        raise ValueError(f"rank must be non-negative, got {rank}")
    base_seed = int(cfg.algo.seed)
    with open_dict(cfg):
        cfg.algo.seed = base_seed + int(rank)
    return int(cfg.algo.seed)


def resolve_rsl_rl_device(
    *,
    configured_device: str | None,
    devices: tuple[int, ...] | None,
    world_size: int,
    local_rank: int,
    default_device: str,
) -> str:
    """Resolve the exact device string expected by RSL-RL's runner.

    Integrated multi-GPU workers see the selected physical devices through a
    remapped ``CUDA_VISIBLE_DEVICES`` list, so RSL-RL must receive
    ``cuda:LOCAL_RANK`` rather than the original host-global device index.
    """
    if configured_device is not None and devices is not None:
        raise ValueError("Set either training.device or training.devices, not both")
    if world_size < 1:
        raise ValueError(f"world_size must be positive, got {world_size}")
    if local_rank < 0 or local_rank >= world_size:
        raise ValueError(f"local_rank={local_rank} is out of range for world_size={world_size}")
    if world_size > 1:
        if configured_device is not None:
            raise ValueError(
                "training.device cannot select one device in a distributed run; "
                "use training.devices"
            )
        if devices is not None and len(devices) != world_size:
            raise ValueError(
                f"training.devices has {len(devices)} entries but WORLD_SIZE={world_size}"
            )
        return f"cuda:{local_rank}"
    if devices is not None:
        return f"cuda:{devices[0]}"
    return configured_device or default_device


def ppo_samples_per_iteration(*, num_envs: int, num_steps_per_env: int, world_size: int) -> int:
    """Return the global fresh rollout sample count for one PPO iteration."""
    return int(num_envs) * int(num_steps_per_env) * int(world_size)


def finish_rsl_rl_distributed(*, training_succeeded: bool) -> None:
    """Synchronize successful ranks and release RSL-RL's process group."""
    if not torch.distributed.is_available() or not torch.distributed.is_initialized():
        return
    try:
        if training_succeeded:
            torch.distributed.barrier()
    finally:
        torch.distributed.destroy_process_group()


@contextmanager
def rsl_rl_single_process_topology() -> Iterator[None]:
    """Temporarily hide torchrun's worker topology from rank-0-only work.

    Destroying a process group does not clear ``WORLD_SIZE`` / ``RANK`` /
    ``LOCAL_RANK``. RSL-RL would therefore initialize a second distributed
    group when rank 0 constructs a fresh runner for post-training playback,
    even though every other rank has already exited. Present the playback
    scope as a single-process runtime, then restore launcher-owned variables.
    """
    single_process_topology = {
        "WORLD_SIZE": "1",
        "RANK": "0",
        "LOCAL_RANK": "0",
    }
    previous = {name: os.environ.get(name) for name in single_process_topology}
    os.environ.update(single_process_topology)
    try:
        yield
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value


def get_policy_obs_dims(obs_groups_spec: dict[str, int]) -> tuple[int, int]:
    """Return ``(actor_obs_dim, flat_policy_obs_dim)`` for RSL-RL policies."""
    actor_obs_dim = int(obs_groups_spec.get("obs", 0))
    flat_policy_obs_dim = int(
        sum(dim for group_name, dim in obs_groups_spec.items() if group_name != "critic")
    )
    return actor_obs_dim, flat_policy_obs_dim or actor_obs_dim


def normalize_ppo_train_cfg(train_cfg: dict[str, Any]) -> dict[str, Any]:
    """Map UniLab PPO owner config to the current RSL-RL schema."""
    normalized = deepcopy(train_cfg)
    algorithm_cfg = normalized.get("algorithm")
    if isinstance(algorithm_cfg, dict):
        for key in (
            "target_kl_stop",
            "adaptive_kl_beta",
            "adaptive_lr_growth",
            "adaptive_lr_decay",
            "adaptive_lr_update_interval",
            "metrics_interval",
            "finite_check_interval",
            "warmup_strict_iters",
            "warmup_metrics_interval",
            "warmup_finite_check_interval",
            "disable_finite_checks",
        ):
            algorithm_cfg.pop(key, None)

    if "actor" in normalized and "critic" in normalized:
        return normalized

    policy_cfg = normalized.pop("policy", None)
    if not isinstance(policy_cfg, dict):
        return normalized

    actor_hidden_dims = policy_cfg.get("actor_hidden_dims", [512, 256, 128])
    critic_hidden_dims = policy_cfg.get("critic_hidden_dims", actor_hidden_dims)
    activation = policy_cfg.get("activation", "elu")
    init_noise_std = float(policy_cfg.get("init_noise_std", 1.0))
    obs_normalization = bool(normalized.get("empirical_normalization", False))

    normalized["actor"] = {
        "class_name": "rsl_rl.models.MLPModel",
        "hidden_dims": actor_hidden_dims,
        "activation": activation,
        "obs_normalization": obs_normalization,
        "distribution_cfg": {
            "class_name": policy_cfg.get(
                "distribution_class_name", "rsl_rl.modules.distribution.GaussianDistribution"
            ),
            "init_std": init_noise_std,
        },
    }
    for name in ("std_type", "min_std", "max_std", "action_low", "action_high"):
        if name in policy_cfg:
            normalized["actor"]["distribution_cfg"][name] = policy_cfg[name]
    if "std_type" not in normalized["actor"]["distribution_cfg"] and not all(
        name in policy_cfg for name in ("min_std", "max_std", "action_low", "action_high")
    ):
        normalized["actor"]["distribution_cfg"]["std_type"] = "scalar"
    normalized["critic"] = {
        "class_name": "rsl_rl.models.MLPModel",
        "hidden_dims": critic_hidden_dims,
        "activation": activation,
        "obs_normalization": obs_normalization,
    }

    obs_groups = normalized.get("obs_groups")
    if isinstance(obs_groups, dict) and "actor" not in obs_groups and "default" in obs_groups:
        default_groups = obs_groups.pop("default")
        if isinstance(default_groups, list) and default_groups:
            obs_groups["actor"] = list(default_groups)

    return normalized


class RslRlVecEnvWrapper:
    """Adapter from UniLab's env contract to the RSL-RL VecEnv contract."""

    def __init__(
        self,
        env: Any,
        device: str = "cpu",
        policy_obs_mode: str = "flat",
    ) -> None:
        if policy_obs_mode == "auto":
            policy_obs_mode = "flat"
        if policy_obs_mode not in {"actor", "flat"}:
            raise ValueError(
                f"Unsupported policy_obs_mode={policy_obs_mode!r}; expected 'actor' or 'flat'."
            )

        self.env = env
        self.cfg = env.cfg
        self.device = device
        self.policy_obs_mode = policy_obs_mode
        self.num_envs = env.num_envs
        self.observation_space = env.observation_space
        self.action_space = env.action_space

        self._actor_obs_dim, self._flat_obs_dim = get_policy_obs_dims(env.obs_groups_spec)
        self.num_obs = (
            self._actor_obs_dim if self.policy_obs_mode == "actor" else self._flat_obs_dim
        )
        self.num_privileged_obs = int(env.obs_groups_spec.get("critic", self.num_obs))
        action_shape = env.action_space.shape
        if action_shape is None:
            raise ValueError("env.action_space.shape must be defined")
        self.num_actions = int(action_shape[0])

        self.episode_returns = torch.zeros(self.num_envs, device=device)
        self.episode_lengths = torch.zeros(self.num_envs, device=device)
        self.episode_length_buf = self.episode_lengths
        self.max_episode_length = np.ceil(env.cfg.max_episode_seconds / env.cfg.ctrl_dt)
        self.reset()

    def _policy_obs(self, obs: dict[str, Any]) -> torch.Tensor:
        if self.policy_obs_mode == "actor":
            return to_torch(obs["obs"], self.device)

        policy_groups = [
            to_numpy(value) for group_name, value in obs.items() if group_name != "critic"
        ]
        if not policy_groups:
            raise KeyError("Observation dict must contain at least one non-critic group")
        if len(policy_groups) == 1:
            return to_torch(policy_groups[0], self.device)
        return to_torch(np.concatenate(policy_groups, axis=1), self.device)

    def _obs_to_tensordict(
        self,
        obs: dict[str, Any],
        info: dict[str, Any] | None = None,
    ) -> TensorDict:
        del info
        actor_obs = to_torch(obs["obs"], self.device)
        td_dict: dict[str, torch.Tensor] = {
            "actor": actor_obs,
            "policy": self._policy_obs(obs),
        }
        if "critic" in obs:
            td_dict["critic"] = to_torch(obs["critic"], self.device)
        return TensorDict(td_dict, batch_size=self.num_envs, device=self.device)

    def _resolve_final_observation(self, state: NpEnvState) -> dict[str, Any] | None:
        if isinstance(state.final_observation, dict):
            return state.final_observation
        if isinstance(state.info, dict):
            final_observation = state.info.get("final_observation")
            if isinstance(final_observation, dict):
                return final_observation
        return None

    def _resolve_done(self, state: NpEnvState) -> torch.Tensor:
        return to_torch(state.terminated | state.truncated, self.device).bool()

    def step(
        self, actions: torch.Tensor | np.ndarray
    ) -> tuple[TensorDict, torch.Tensor, torch.Tensor, dict]:
        actions_np = to_numpy(actions)
        state = self.env.step(actions_np)
        rewards = to_torch(state.reward, self.device)
        dones = self._resolve_done(state)

        self.episode_returns += rewards
        self.episode_lengths += 1

        infos: dict[str, torch.Tensor | TensorDict | dict[str, Any]] = {}
        done_idx = torch.nonzero(dones).flatten()
        if len(done_idx) > 0:
            infos["time_outs"] = to_torch(state.truncated, self.device).bool()

            final_observation = self._resolve_final_observation(state)
            terminal_contract = resolve_terminal_observation_contract(
                next_obs_batch_size=self.num_envs,
                final_observation=final_observation,
                done=to_numpy(dones),
                info=state.info,
                truncated=to_numpy(infos["time_outs"]),
            )
            if np.any(terminal_contract.timeout_terminal_mask) and final_observation is not None:
                infos["time_out_bootstrap_obs"] = self._obs_to_tensordict(final_observation)

            self.episode_returns[done_idx] = 0
            self.episode_lengths[done_idx] = 0

        if "log" in state.info:
            infos["log"] = state.info["log"]

        return (
            self._obs_to_tensordict(state.obs, getattr(state, "info", None)),
            rewards,
            dones,
            infos,
        )

    def reset(self) -> tuple[TensorDict, dict[str, Any]]:
        if self.env.state is None:
            self.env.init_state()

        env_indices = np.arange(self.num_envs, dtype=np.int32)
        obs_out, info = self.env.reset(env_indices)
        self.episode_returns[:] = 0
        self.episode_lengths[:] = 0
        return self._obs_to_tensordict(obs_out, info), info

    def get_observations(self) -> TensorDict:
        assert self.env.state is not None
        return self._obs_to_tensordict(self.env.state.obs, self.env.state.info)

    def get_privileged_observations(self) -> torch.Tensor:
        assert self.env.state is not None
        obs = self.env.state.obs
        return to_torch(obs.get("critic", obs["obs"]), self.device)

    def close(self) -> None:
        self.env.close()

from common import *
from metrics import alternating_step_statistics,step_target_pass,measurement_self_test
import argparse,hashlib,onnxruntime as ort
ap=argparse.ArgumentParser();ap.add_argument('--checkpoint',default='parent_flex50.pt');ap.add_argument('--prefix',default='baseline');ap.add_argument('--bank',default='heldout_rigid_bank.npz');ap.add_argument('--n',type=int,default=8);ap.add_argument('--seconds',type=float,default=16);args=ap.parse_args();assert args.seconds>=16;measurement_self_test();B=args.n;N=2*B;ids=np.tile(np.arange(B),2);bank=np.load(R/args.bank);torch.set_num_threads(2)
class Actor(torch.nn.Module):
 def __init__(self,path):
  super().__init__();sd=torch.load(path,map_location='cpu',weights_only=False)['actor_state_dict'];self.register_buffer('mean',sd['obs_normalizer._mean']);self.register_buffer('std',sd['obs_normalizer._std']);self.net=torch.nn.Sequential(torch.nn.Linear(61,512),torch.nn.ELU(),torch.nn.Linear(512,256),torch.nn.ELU(),torch.nn.Linear(256,128),torch.nn.ELU(),torch.nn.Linear(128,14));self.net.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')})
 def forward(self,x):return self.net((x-self.mean)/(self.std+.01))
models=[Actor(R/'parent_flex50.pt').eval(),Actor(R/args.checkpoint).eval()];opt=ort.SessionOptions();opt.intra_op_num_threads=1;sess=ort.InferenceSession(str(R/'parent_flex50.onnx'),sess_options=opt,providers=['CPUExecutionProvider']);parity=0.
e=env(N);m,qi,vi,names,local=metadata();goal=np.array(json.loads((R/'NEW_STANDING_TARGET.json').read_text())['target_rad']);bodyids=np.array([e._backend.get_body_id(n) for n in names],np.int32);cmd=np.zeros((N,3));rows=[]
try:
 e.init_state();e.set_autoreset(False)
 from unilab.dr.types import ResetRandomizationPayload
 e._backend.set_state(np.arange(N,dtype=np.int32),bank['qpos'][ids],bank['qvel'][ids],ResetRandomizationPayload(**{k:bank[k][ids] for k in FIELDS}))
 for k in ['encoder_bias','imu_rotation','sole_angles','sole_delta_quat']:getattr(e,'_'+k)[:]=bank[k][ids]
 rng=np.random.default_rng(1202001);drng=np.random.default_rng(1202002)
 def noise(data,scale):
  z=rng.uniform(-1,1,(B,data.shape[1])).astype(data.dtype);return data+np.concatenate([z,z])*float(e.cfg.noise_config.level)*scale
 def delay(env_ids=None):
  lo,hi=e._imu_delay_bounds
  if env_ids is None:
   x=drng.integers(lo,hi+1,B);e._imu_delay_lag[:]=np.concatenate([x,x])
  else:e._imu_delay_lag[env_ids]=drng.integers(lo,hi+1,len(env_ids))
 e._obs_noise=noise;e._sample_imu_delay=delay
 def hold(st):st.info['commands'][:]=0;st.info['commands'][:,:3]=cmd
 e._maybe_resample_commands=hold;first=e._current_action_target.copy()
 for tick in range(200):
  hold(e.state);u=np.clip(tick/75,0,1);u=u*u*u*(10+u*(-15+6*u));target=(1-u)*first+u*goal;e.step((target-e.default_angles)/e._physical_scales)
 initial,_=state(e,m)
 for tick in range(round(args.seconds/.02)):
  cmd[:,0]=.3;hold(e.state);obs=e.state.obs['obs'].copy();obs[:,48:51]=cmd
  with torch.inference_mode():raw=np.concatenate([model(torch.tensor(x,dtype=torch.float32)).numpy() for model,x in zip(models,np.split(obs,2))])
  assert np.isfinite(raw).all()
  if tick in [0,200,round(args.seconds/.02)-1]:
   for j in [0,B-1]:
    err=float(abs(sess.run(None,{'obs':obs[j:j+1].astype(np.float32)})[0][0]-raw[j]).max());assert err<2e-5;parity=max(parity,err)
  e.step(raw);q,v=state(e,m);velocity=e.get_local_linvel().copy();pos,quat=e._backend.get_body_pose_w(bodyids);footworld=pos+rotate(quat,np.broadcast_to(local,pos.shape));normal=rotate(quat,rotate(e._sole_delta_quat,np.broadcast_to(np.array(e._sole_normals),pos.shape)))
  rows.append(dict(qpos=q,velocity=velocity,world_velocity=rotate(q[:,3:7],velocity),feet_world=footworld,clearance=e._foot_height.copy(),contact=e._contact.copy(),foot_velocity=e._foot_vel.copy(),sole_normal=normal,gyro=e.get_gyro().copy(),actor_obs=obs,raw_actions=raw,qvel=v))
  if (tick+1)%200==0:print('STEP20_EVAL',tick+1,flush=True)
 z={k:np.array([r[k] for r in rows]) for k in rows[0]};np.savez_compressed(R/(args.prefix+'_trace.npz'),**z,initial=initial,source_indices=ids,**{k:bank[k][ids] for k in FIELDS});records=[];start=200
 for j in range(N):
  q=z['qpos'][:,j];w,x,y,zz=q[:,3:7].T;tilt=np.degrees(np.arccos(np.clip(1-2*(x*x+y*y),-1,1)));yaw=np.unwrap(np.arctan2(2*(w*zz+x*y),1-2*(y*y+zz*zz)));q0=initial[j,3:7];heading0=np.arctan2(2*(q0[0]*q0[3]+q0[1]*q0[2]),1-2*(q0[2]**2+q0[3]**2));axis=np.array([np.cos(heading0),np.sin(heading0),0]);laxis=np.array([-np.sin(heading0),np.cos(heading0),0]);vf=z['world_velocity'][:,j]@axis
  events=[];air=np.zeros(2,bool);peak=np.zeros(2)
  for t,h in enumerate(z['clearance'][:,j]):
   leaving=(~air)&(h>.0015);peak=np.maximum(peak,h);landing=air&z['contact'][t,j]&(h<.003)
   for side in np.flatnonzero(landing):
    if peak[side]>=.008:events.append(dict(time=(t+1)*.02,side=int(side),point=z['feet_world'][t,j,side].copy(),peak=float(peak[side]),yaw=float(yaw[t])))
   peak[landing]=0;air=(air|leaving)&(~landing)
  early=[v for v in events if v['time']<=4];late=[v for v in events if v['time']>=4];stats=alternating_step_statistics(late,axis,body_frame=True);global_stats=alternating_step_statistics(late,axis);stable=bool(tilt.max()<20 and q[:,2].min()>.25);started=bool(len({v['side'] for v in early})==2 and (q[199,:3]-initial[j,:3])@axis>.1 and tilt[:200].max()<20)
  windows=np.convolve(vf[start:],np.ones(100)/100,'valid');counts=[sum(v['side']==s for v in late) for s in range(2)];sustained=bool(stable and started and min(counts)>=3)
  yaw_drift=float(np.max(abs(np.degrees(yaw-heading0))));delta=q[-1,:3]-initial[j,:3];angle=float(np.degrees(np.arctan2(abs(delta@laxis),delta@axis)));direction=bool(yaw_drift<30 and angle<20 and delta@axis>.2)
  flat=z['contact'][start:,j]&(z['clearance'][start:,j]<.003)&(np.linalg.norm(z['sole_normal'][start:,j,:,:2],axis=2)<.15);slips=np.linalg.norm(z['foot_velocity'][start:,j,:,:2],axis=2)[flat];slip95=float(np.percentile(slips,95)) if len(slips) else None
  mean_speed=float(vf[start:].mean());body_path_speed=float(np.linalg.norm(z['world_velocity'][start:,j,:2],axis=1).mean());body_series=np.linalg.norm(z['world_velocity'][start:,j,:2],axis=1);speed_windows=np.linalg.norm(q[start:,:2]-q[start-100:-100,:2],axis=1)/2.;speed_ok=bool(speed_windows.max()<=.35);timing_ok=None;step_ok=step_target_pass(stats,.20);passed=bool(sustained and direction and speed_ok and step_ok and slip95 is not None and slip95<=.15)
  same=[]
  for side in range(2):
   ev=[v for v in late if v['side']==side]
   same.extend(float((b['point']-a['point'])@axis) for a,b in zip(ev,ev[1:]))
  records.append(dict(scenario='forward',model='flex50_baseline' if j<B else 'candidate',case=j%B,trace_index=j,started=started,stable=stable,sustained=sustained,direction_pass=direction,speed_band_pass=speed_ok,alternating_step_target_pass=step_ok,joint_acceptance=passed,forward_speed_mean_m_s=mean_speed,body_horizontal_speed_mean_m_s=body_path_speed,body_speed_max_m_s=float(body_series.max()),body_speed_p95_m_s=float(np.percentile(body_series,95)),translation_speed2s_mean_m_s=float(speed_windows.mean()),body_speed_2s_min_m_s=float(speed_windows.min()),body_speed_2s_max_m_s=float(speed_windows.max()),timing_target_pass=timing_ok,body_speed_mean_m_s=float(z['velocity'][start:,j,0].mean()),same_foot_stride_median_m=float(np.median(same)) if same else None,max_yaw_drift_deg=yaw_drift,net_heading_error_deg=angle,tilt_max_deg=float(tilt.max()),flat_stance_slip_p95_m_s=slip95,foot_peak_median_mm=[float(np.median([v['peak'] for v in late if v['side']==s])*1000) if any(v['side']==s for v in late) else None for s in range(2)],foot_landings_after4s=counts,global_left_step_median_m=global_stats['left_step_median_m'],global_right_step_median_m=global_stats['right_step_median_m'],**stats))
 report=dict(command=[.3,0,0],seconds=args.seconds,statistics_window_seconds=[4,args.seconds],measurement='successive opposite-foot physical touchdowns projected along midpoint body heading; heading checked against initial direction; norm of horizontal displacement over each trailing2s<=0.35m/s; no lower bound; instant speed diagnostic only',alternating_step_target_m=.20,speed_band_m_s=[None,.35],speed_objective_enabled=True,normalization='embedded',paired_physics_noise_delay=True,original_actor_onnx_parity_error=parity,records=records,source_checkpoint=args.checkpoint)
 (R/(args.prefix+'_results.json')).write_text(json.dumps(report,indent=2));print('STEP20_RESULTS',[(name,sum(r['joint_acceptance'] for r in records if r['model']==name)) for name in ['flex50_baseline','candidate']],flush=True)
finally:e.close()

from common import *
import argparse,time
ap=argparse.ArgumentParser();ap.add_argument('--prefix',required=True);ap.add_argument('--seed',type=int,required=True);ap.add_argument('--n',type=int,default=64);a=ap.parse_args()
np.random.seed(a.seed);torch.manual_seed(a.seed);torch.set_num_threads(2)
e=env(a.n,dr_seed=a.seed);m,qi,vi,names,local=metadata();assert (m.nq,m.nv,m.nu)==(21,20,14) and not e.cfg.flexible_dr_enabled
goal=np.array(json.loads((R/'NEW_STANDING_TARGET.json').read_text())['target_rad']);chunks=[];reports=[]
try:
 e.init_state();e.set_autoreset(False);bodyids=np.array([e._backend.get_body_id(n) for n in names],np.int32);first=e._current_action_target.copy()
 def hold(st):st.info['commands'][:]=0
 e._maybe_resample_commands=hold
 for tick in range(200):
  hold(e.state);u=np.clip(tick/75,0,1);u=u*u*u*(10+u*(-15+6*u));targets=(1-u)*first+u*goal;e.step((targets-e.default_angles)/e._physical_scales)
  np.testing.assert_allclose(e._current_action_target,targets,atol=4e-7)
  if tick not in [149,199]:continue
  q,v=state(e,m);tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,4]**2+q[:,5]**2),-1,1)));vel=e.get_local_linvel().copy();xyz=feet(e,q,bodyids,local);good=(tilt<6)&(np.linalg.norm(vel[:,:2],axis=1)<.02)&(q[:,2]>.28)&(q[:,2]<.4)
  saved={k:getattr(e._backend._device_model,k).numpy()[good].copy() for k in FIELDS};saved.update(qpos=q[good],qvel=v[good],target=targets[good].copy(),initial_width=xyz[good,0,1]-xyz[good,1,1],linvel=vel[good],source_case=np.flatnonzero(good),**{k:getattr(e,'_'+k)[good].copy() for k in ['encoder_bias','imu_rotation','sole_angles','sole_delta_quat']});chunks.append(saved);reports.append(dict(tick=tick+1,accepted=int(good.sum()),rejected=int((~good).sum())));print('HOLD',reports[-1],flush=True)
 bank={k:np.concatenate([c[k] for c in chunks]) for k in chunks[0]};assert len(bank['qpos'])>=a.n and not np.any(bank['jnt_stiffness'])
 np.savez_compressed(R/(a.prefix+'.npz'),**bank);(R/(a.prefix+'_manifest.json')).write_text(json.dumps(dict(seed=a.seed,nq=m.nq,nv=m.nv,frames=len(bank['qpos']),reports=reports,physical_free_root_hold=True,flexible_states_projected=False,sole_deg=np.degrees([bank['sole_angles'].min(),bank['sole_angles'].max()]).tolist()),indent=2));print('BANK_READY',a.prefix,len(bank['qpos']),flush=True)
finally:e.close()

from pathlib import Path
import argparse,json,hashlib
import numpy as np,torch,onnxruntime as ort
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--updates',type=int,required=True);a=ap.parse_args();torch.set_num_threads(2);p=R/'ppo_run'/f'model_{a.updates-1}.pt';ck=torch.load(p,map_location='cpu',weights_only=False);parent=torch.load(R/'parent_flex50.pt',map_location='cpu',weights_only=False);assert ck['infos']['unilab_progress']['next_iteration']==a.updates;sd=ck['actor_state_dict']
for k,v in sd.items():
 assert torch.isfinite(v).all()
 if k.startswith('obs_normalizer.'):assert torch.equal(v,parent['actor_state_dict'][k]),k
class Actor(torch.nn.Module):
 def __init__(self):
  super().__init__();self.register_buffer('mean',sd['obs_normalizer._mean']);self.register_buffer('std',sd['obs_normalizer._std']);self.net=torch.nn.Sequential(torch.nn.Linear(61,512),torch.nn.ELU(),torch.nn.Linear(512,256),torch.nn.ELU(),torch.nn.Linear(256,128),torch.nn.ELU(),torch.nn.Linear(128,14));self.net.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')})
 def forward(self,x):return self.net((x-self.mean)/(self.std+.01))
actor=Actor().eval();out=R/f'flex50_direct_step20_{a.updates}.onnx';torch.onnx.export(actor,torch.zeros(1,61),str(out),input_names=['obs'],output_names=['actions'],opset_version=17,dynamo=False);opts=ort.SessionOptions();opts.intra_op_num_threads=1;sess=ort.InferenceSession(str(out),sess_options=opts,providers=['CPUExecutionProvider']);x=np.random.default_rng(1103350).normal(0,.2,(128,61)).astype(np.float32);x[:,48:]=0;x[:,48]=.3
with torch.inference_mode():expected=actor(torch.tensor(x)).numpy()
actual=np.concatenate([sess.run(None,{'obs':v[None]})[0] for v in x]);err=float(abs(actual-expected).max());assert err<2e-5
report=dict(status='PASS',completed_repair_updates=a.updates,parent='original flex_adapt_50',checkpoint=str(p.relative_to(R)),checkpoint_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),onnx=out.name,onnx_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),max_torch_onnx_error=err,input_shape=[1,61],output_shape=[1,14],normalizer_frozen=True)
(R/f'EXPORT_{a.updates}.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

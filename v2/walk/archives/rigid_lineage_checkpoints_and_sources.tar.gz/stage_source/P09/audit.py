from pathlib import Path
import json,hashlib,ast,argparse
from runtime import atomic_json
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--final',action='store_true');a=ap.parse_args()
assert hashlib.sha256((R/'parent_flex50.pt').read_bytes()).hexdigest()=='e959c81f9a362bc6c3c0a4f2cc626716c41d54fafad2ff74debe900e65458ad9'
assert hashlib.sha256((R/'parent_flex50.onnx').read_bytes()).hexdigest()=='3db03a4558cb06033e9239af4c57bec5bff107bc9d2fed27df127221e564f85d'
for p in R.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
assert json.loads((R/'CPU_TESTS.json').read_text())['status']=='PASS'
assert json.loads((R/'REACH_AUDIT.json').read_text())['status']=='PASS_KINEMATIC_ONLY'
paths=list(R.glob('*.py'))+list(R.glob('*.yaml'))+[R/'parent_flex50.pt',R/'parent_flex50.onnx',R/'physics/effective_training.mjb']+list(R.glob('*.npz'))+list((R/'project/src').rglob('*.py'))+list((R/'project/scripts').rglob('*.py'))
frozen={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
if a.final:
 for n in ['SMOKE_SMALL.json','SMOKE_4096.json','LIVE_REGRESSION.json','FRESH32_REGRESSION.json']:assert json.loads((R/n).read_text())['status']=='PASS',n
 before=json.loads((R/'CPU_AUDIT.json').read_text())['frozen_sha256']
 for n,h in before.items():assert frozen[n]==h,n
atomic_json(R/('PRETRAIN_AUDIT.json' if a.final else 'CPU_AUDIT.json'),dict(status='PASS_READY_FOR_TRAINING' if a.final else 'PASS_CPU_READY_FOR_GPU',parent='original flex_adapt_50',requested_updates=400,frozen_sha256=frozen))
print('AUDIT_PASS',a.final,flush=True)

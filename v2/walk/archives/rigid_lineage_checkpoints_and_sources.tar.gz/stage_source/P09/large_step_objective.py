"""Fixed20cm touchdown objective. No stage, phase clock or minimum speed."""
import numpy as np
GOAL=.10
GAMMA=.995

def length_score(lengths):
    """Worst side governs credit; monotone until20cm, plateau thereafter."""
    return np.clip(np.min(lengths,axis=1)/GOAL,0.,1.)**2

def touchdown_credit(valid, pair_valid, lengths, peak, heading, lateral, speed2s):
    quality=length_score(lengths)*pair_valid.all(1)
    height=np.exp(-((np.maximum(.025-peak,0)+np.maximum(peak-.085,0))/.025)**2)
    direction=1/(1+(heading/.26)**2)
    lateral_gate=1/(1+(lateral/.10)**2)
    speed_gate=1/(1+(np.maximum(speed2s-.35,0)/.04)**2)
    # Per landing, NOT elapsed time: waiting cannot accumulate credit.
    bonus=12*quality*(height*valid).sum(1)*direction*lateral_gate*speed_gate
    excess=np.maximum(lengths-1.1*GOAL,0)
    overshoot=4*np.max(excess/.05,axis=1)*valid.any(1)*pair_valid.all(1)
    return bonus-overshoot

def independent_costs(speed2s,heading):
    excess=np.maximum(speed2s-.35,0)
    speed=40*excess+80*excess**2
    direction=.2*np.minimum((heading/.35)**2,25.)
    return speed,direction

def swing_potential(swing_lengths, airborne, heading):
    # Dense potential signal; exact discounted telescoping, no extra net return
    # for raising/lowering, reversing a swing or ending an episode in the air.
    progress=np.clip(swing_lengths/GOAL,0.,1.)**2
    return 3*np.max(progress*airborne,axis=1)/(1+(heading/.26)**2)

class FixedGoal:
    goal=GOAL
    stage=0
    def record(self,passed):pass
    def advance(self,update):return False
    def snapshot(self):return dict(mode='fixed10cm_monotone',current_goal_m=GOAL,final_goal_m=GOAL,no_curriculum_gate=True)

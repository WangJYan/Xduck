from pathlib import Path
import shutil,ast,json
R=Path(__file__).resolve().parent;S=R.parent/'flex50_verified_gait400_24_20261104';assert not (R/'project').exists()
shutil.copytree(S/'project',R/'project',symlinks=True,ignore=shutil.ignore_patterns('.venv','__pycache__','.git','outputs','logs'));(R/'project/.venv').symlink_to((S/'project/.venv').resolve());(R/'physics').symlink_to((S/'physics').resolve())
for n in ['parent_flex50.pt','parent_flex50.onnx','direction_anchor.npz','train_rigid_bank.npz','heldout_rigid_bank.npz','train_rigid_bank_manifest.json','heldout_rigid_bank_manifest.json','NEW_STANDING_TARGET.json','xc_walking_v3_policy.py','KINEMATIC_AUDIT.json']:
 shutil.copy2(S/n,R/n)
for n in ['common.py','metrics.py','evaluate.py','report_phase.py','collect_bank.py','export_phase.py','runtime.py','speed_history.py','curriculum.py']:
 shutil.copy2(S/n,R/n)
for n in ['TRAINING_CONFIG.yaml','COLLECT_CONFIG.yaml']:
 s=(S/n).read_text().replace(str(S),str(R)).replace('XDuckVerifiedGait400','XDuckDirectStep20');(R/n).write_text(s)
s=(S/'verified_gait.py').read_text().replace('VerifiedGait','DirectStep').replace('XDuckDirectStep400','XDuckDirectStep20').replace('from curriculum import GaitCurriculum','from large_step_objective import FixedGoal, touchdown_credit, independent_costs, swing_potential, GAMMA')
s=s.replace('self.curriculum = GaitCurriculum()','self.curriculum = FixedGoal()\n        self._stride_potential = np.zeros(num_envs)')
s=s.replace('        self._reset_chunks(ids)\n        self._walk_last_interval[ids] = 0','        self._reset_chunks(ids)\n        self._stride_potential[ids] = 0\n        self._walk_last_interval[ids] = 0')
a=s.index('        fraction = np.clip(',s.index('    def _compute_reward'));b=s.index('        physical_extra =',a)
s=s[:a]+'''        presence = evidence_freshness * self._pair_valid.all(1) * (np.min(self._pair_lengths,axis=1) > .015)
        speed_quality = 1/(1+(np.maximum(speed2s-.35,0)/.04)**2)
        lateral_quality = 1/(1+(self._step_mean_lateral/.10)**2)
        gate = presence * heading_gate * speed_quality * lateral_quality
        step_credit = touchdown_credit(valid_step,self._pair_valid,self._pair_lengths,self._smooth_peak_before_landing,heading_error,self._step_mean_lateral,speed2s)
        speed_cost, heading_cost = independent_costs(speed2s,heading_error)
        startup = np.clip(episode_age/1.2,0,1); startup = startup**3*(10+startup*(-15+6*startup))
        idle = 4*(1-presence)*startup
        progress = np.zeros(self.num_envs)
        potential = swing_potential(step_length,self._smooth_air & (h>.0015),heading_error)
        shaping = GAMMA*potential-self._stride_potential
        self._stride_potential = potential
''' + s[b:]
s=s.replace('        self._smooth_peak[landing] = 0','        self._smooth_peak_before_landing = self._smooth_peak.copy()\n        self._smooth_peak[landing] = 0')
s=s.replace('+ (progress - idle) * dt)', '+ shaping - (idle+speed_cost+heading_cost)*dt)')
s=s.replace("'task/progress_credit_per_s': float(progress.mean())", "'task/shaping_per_s':float((shaping/dt).mean()), 'task/speed_excess_cost_per_s':float(speed_cost.mean()), 'task/heading_cost_per_s':float(heading_cost.mean())")
s=s.replace('        return result.replace(reward=result.reward - penalty.astype(result.reward.dtype))','''        ended = result.terminated | (state.info['steps']+1 >= self.cfg.max_episode_steps)
        terminal_shaping = GAMMA*self._stride_potential*ended
        self._stride_potential[ended] = 0
        return result.replace(reward=result.reward - penalty.astype(result.reward.dtype) - terminal_shaping.astype(result.reward.dtype))''')
ast.parse(s);(R/'direct_step.py').write_text(s);(R/'project/src/unilab/envs/locomotion/xduck_gf43x40/direct_step.py').write_text(s)
# Keep physical setup and frozen original actor unchanged; seed is independent.
from omegaconf import OmegaConf
c=OmegaConf.load(R/'TRAINING_CONFIG.yaml');c.algo.seed=1104401;c.env.newstand_seed=1104402;c.env.direction_seed=1104403;c.env.fast_step_start_m=.20;c.env.fast_step_goal_m=.20
OmegaConf.save(c,R/'TRAINING_CONFIG.yaml')
(R/'DESIGN.json').write_text(json.dumps(dict(parent='original flex_adapt_50',fixed_goal_m=.20,speed_upper_m_s=.35,speed_lower_m_s=None,rollout_steps=24,num_envs=4096,save_interval=50,requested_updates=400,curriculum_gate=False,monotone_step_score=True,landing_reward_not_accumulated_by_waiting=True,swing_potential_gamma=.995,independent_speed_and_heading_cost=True),indent=2))

from common import *
from unilab.envs.locomotion.xduck_gf43x40.direct_step import DirectStepEnv
from runtime import atomic_json
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--cases',type=int,default=8);ap.add_argument('--bank',default='heldout_rigid_bank.npz');ap.add_argument('--out',default='LIVE_REGRESSION.json');args=ap.parse_args()
B=args.cases;K=5;N=2*K*B;torch.set_num_threads(2)
class Actor(torch.nn.Module):
 def __init__(self,path):
  super().__init__();sd=torch.load(path,map_location='cpu',weights_only=False)['actor_state_dict'];self.register_buffer('mean',sd['obs_normalizer._mean']);self.register_buffer('std',sd['obs_normalizer._std']);self.net=torch.nn.Sequential(torch.nn.Linear(61,512),torch.nn.ELU(),torch.nn.Linear(512,256),torch.nn.ELU(),torch.nn.Linear(256,128),torch.nn.ELU(),torch.nn.Linear(128,14));self.net.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')})
 def forward(self,x):return self.net((x-self.mean)/(self.std+.01))
actor=Actor(R/'parent_flex50.pt').eval();negative=R.parent/'walk_required_step20_speedcap035_24_400_20261104/ppo_run/model_399.pt';stop=Actor(negative).eval()
c=OmegaConf.load(R/'TRAINING_CONFIG.yaml');c.env.newstand_bank_path=str(R/args.bank);E.ensure_registries();e=E.create_env(c,num_envs=N,env_cfg_override=E.build_ppo_env_cfg_override(c))
class Rows:
 def __init__(self):self.rng=np.random.default_rng(1104999)
 def integers(self,high,size):assert size==N;return np.tile(np.arange(B),2*K)
 def uniform(self,*a,**kw):return self.rng.uniform(*a,**kw)
 def random(self,*a,**kw):return self.rng.random(*a,**kw)
e._newstand_rng=Rows();rng=np.random.default_rng(1104998);arng=np.random.default_rng(1104997);drng=np.random.default_rng(1104996)
def noise(data,scale):
 z=rng.uniform(-1,1,(B,data.shape[1])).astype(data.dtype);return data+np.tile(z,(2*K,1))*float(e.cfg.noise_config.level)*scale
def delay(ids=None):
 lo,hi=e._imu_delay_bounds;x=drng.integers(lo,hi+1,B)
 if ids is None:e._imu_delay_lag[:]=np.tile(x,2*K)
 else:e._imu_delay_lag[ids]=x[np.asarray(ids)%B]
e._obs_noise=noise;e._sample_imu_delay=delay;tot=np.zeros(N);alive=np.ones(N,bool);falls=np.zeros(N,bool);labels=['forward','backward','turn','pause_restart','stationary']; components={}
try:
 e.init_state();e.set_autoreset(False)
 for tick in range(1000):
  parts=[]
  with torch.inference_mode():
   for j,x in enumerate(np.split(e.state.obs['obs'],2*K)):
    x=x.copy();label=labels[j%K]
    if label=='backward':x[:,48:51]=[-.3,0,0]
    if label=='turn':x[:,48:51]=[0,0,.6]
    chosen=stop if label=='stationary' or (label=='pause_restart' and 200<=tick<600) else actor
    parts.append(chosen(torch.tensor(x,dtype=torch.float32)).numpy())
  a=np.concatenate(parts);a[K*B:]+=np.tile(arng.normal(0,.25,(B,14)),(K,1));s=e.step(a);assert np.isfinite(s.reward).all();tot+=s.reward*alive
  cap=e._audit_task
  for key in ['step_credit','base_positive','base_negative']:
   components[key]=components.get(key,np.zeros(N))+cap[key]*alive
  for key in ['physical_extra','idle']:
   components[key]=components.get(key,np.zeros(N))+cap[key]*.02*alive
  q=e._backend.get_base_quat();w,x,y,z=q.T;yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z));heading=np.arctan2(np.sin(yaw-e._dir_heading0),np.cos(yaw-e._dir_heading0))
  from large_step_objective import independent_costs
  sc,hc=independent_costs(cap['speed2s'],heading)
  for key,value in [('speed_cost',sc),('heading_cost',hc)]:components[key]=components.get(key,np.zeros(N))+value*.02*alive
  falls|=s.terminated&alive;alive&=~s.terminated
  if (tick+1)%200==0:print('LIVE_REGRESSION',tick+1,flush=True)
 records=[]; failures=[]
 for mode in range(2):
  scores=tot[mode*K*B:(mode+1)*K*B].reshape(K,B)/20
  for j,label in enumerate(labels):
   sl=slice((mode*K+j)*B,(mode*K+j+1)*B)
   records.append(dict(mode='mean' if mode==0 else 'sampled_std025',control=label,mean_reward_per_s=float(scores[j].mean()),falls=int(falls[sl].sum()),components_per_s={key:float(value[sl].mean()/20) for key,value in components.items()}))
  if scores[0].mean()<=scores[4].mean():failures.append(f'stationary beats forward: mode{mode}')
  if scores[0].mean()<=max(scores[1].mean(),scores[2].mean()):failures.append(f'wrong direction beats forward: mode{mode}')
  # Pause/restart also changes yaw trajectory; report it rather than forcing an
  # incorrect ranking against the drifting original. A separate identical-path
  # insertion test verifies that waiting cannot create reward.
  if scores[4].mean()>=0:failures.append(f'stationary positive: mode{mode}')
 assert e.curriculum.goal==.20
 report=dict(status='FAIL' if failures else 'PASS',failures=failures,records=records,policy_updates=0,negative_control_checkpoint=str(negative),negative_control_used_for_initialization=False,actual_production_reward=True,paired_cases=B,seconds=20)
 atomic_json(R/args.out,report);print(json.dumps(report,indent=2),flush=True)
 assert not failures,failures
finally:e.close()

from pathlib import Path
import subprocess,sys,json,time,os,traceback,fcntl
from runtime import atomic_json
R=Path(__file__).resolve().parent;lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
PYTHON=[str(Path('/home/xingchen/.local/bin/uv')),'run','--python',str(R/'project/.venv/bin/python'),'--no-project']
def status(s,**kw):atomic_json(R/'RUN_STATUS.json',dict(status=s,controller_pid=os.getpid(),updated_unix=time.time(),**kw));print(s,kw,flush=True)
def free():return int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip().splitlines()[0])
def wait_gpu():
 while free()<17408:status('WAITING_FOR_GPU',free_gpu_mib=free(),required_free_mib=17408);time.sleep(30)
def run(script,args=(),log=None):
 with (R/(log or script.replace('.py','.log'))).open('a') as f:subprocess.run(PYTHON+[str(R/script),*map(str,args)],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
def evaluate(update,final=False):
 status('EVALUATING',completed_checkpoint=update,training_continues=not final)
 run('export_phase.py',['--updates',update])
 prefix=f'probe_{update}'
 run('evaluate.py',['--checkpoint',f'ppo_run/model_{update-1}.pt','--prefix',prefix,'--n',8])
 run('report_phase.py',['--updates',update,'--prefix',prefix])
 if final:
  run('collect_bank.py',['--prefix','fresh_final_bank','--seed',1104299,'--n',32])
  run('evaluate.py',['--checkpoint',f'ppo_run/model_{update-1}.pt','--prefix','final32','--bank','fresh_final_bank.npz','--n',32])
  run('report_phase.py',['--updates',update,'--prefix','final32'])
try:
 status('CPU_AUDIT');run('audit_reach.py');run('test_cpu.py');run('audit.py');wait_gpu()
 status('SMOKE_SMALL');run('train.py',['--smoke','--smoke-envs',16],'smoke_small.log')
 wait_gpu();status('LIVE_REWARD_REGRESSION');run('live_regression.py')
 wait_gpu();status('INDEPENDENT32_REWARD_REGRESSION');run('live_regression.py',['--cases',32,'--bank','design_fresh_bank.npz','--out','FRESH32_REGRESSION.json'],'fresh32_regression.log')
 wait_gpu();status('SMOKE_4096');run('train.py',['--smoke','--smoke-envs',4096],'smoke_4096.log')
 run('audit.py',['--final']);wait_gpu();status('TRAINING_RUNNING',requested_updates=400)
 with (R/'train.log').open('a') as f:
  child=subprocess.Popen(PYTHON+[str(R/'train.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
  atomic_json(R/'TRAIN_PROCESS.json',dict(pid=child.pid,started_unix=time.time(),requested_updates=400))
  done200=False
  while child.poll() is None:
   if not done200 and (R/'CHECKPOINT_200.json').exists() and free()>=10000:
    evaluate(200);done200=True;status('TRAINING_RUNNING',checkpoint200_evaluated=True)
   time.sleep(15)
  assert child.returncode==0,('training failed',child.returncode)
 if not done200:wait_gpu();evaluate(200)
 wait_gpu();evaluate(400,True)
 status('COMPLETE',completed_updates=400,final_report='final32_summary.json',goal_achievement=json.loads((R/'final32_summary.json').read_text())['status'])
except BaseException as ex:
 status('FAILED',error=repr(ex),traceback=traceback.format_exc());raise

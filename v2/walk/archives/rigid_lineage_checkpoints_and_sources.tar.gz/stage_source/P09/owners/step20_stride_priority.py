"""Command-aligned locomotion with accepted gait and speed across DR."""
from dataclasses import dataclass
import numpy as np
from unilab.base import registry
from .new_stand_smooth import NewStandSmoothCfg,NewStandSmoothEnv,NewStandBankReset
from .startup_flex import StartupFlexEnv
from .rigid_startcourse import RigidStartCourseEnv
import mujoco
from .startup_flex import rotate

COMMANDS=np.array([[.3,0,0],[-.3,0,0],[0,0,.4],[0,0,-.4],[.3,0,.4],[.3,0,-.4]])

def motion_metrics(command,velocity,yaw_rate,gain=.65):
    norm=np.linalg.norm(command[:,:2],axis=1)
    translating=norm>.05
    axis=command[:,:2]/np.maximum(norm[:,None],1e-6)
    signed_speed=np.sum(velocity[:,:2]*axis,axis=1)
    signed_turn=np.sign(command[:,2])*yaw_rate
    return translating,axis,signed_speed,signed_turn,gain*command[:,:2]


def midpoint_step_axes(current_yaw,other_touchdown_yaw):
    delta=np.arctan2(np.sin(current_yaw[:,None]-other_touchdown_yaw),np.cos(current_yaw[:,None]-other_touchdown_yaw))
    middle=current_yaw[:,None]-.5*delta
    return np.stack([np.cos(middle),np.sin(middle),np.zeros_like(middle)],axis=2)

def opposite_step_lengths(world,last_touchdown,forward_axis):
    axis=forward_axis[:,None,:] if forward_axis.ndim==2 else forward_axis
    return np.sum((world-last_touchdown[:,::-1,:])*axis,axis=2)

def pseudo_huber(x):
    return np.sqrt(1.+np.asarray(x)**2)-1.

def pair_step_terms(lengths,goal=.20,error_scale=.05,symmetry_scale=.04):
    error=lengths-goal
    worst=np.max(np.abs(error),axis=1)
    quality=1./(1.+(worst/(2.*error_scale))**2)
    target_cost=pseudo_huber(error/error_scale).mean(1)
    asymmetry=pseudo_huber((lengths[:,0]-lengths[:,1])/symmetry_scale)
    return quality,1.2*target_cost+.8*asymmetry

def paired_step_reward(landed,known_other,interval,step_length,peak,goal_step,alternating,pair_lengths,pair_valid,error_scale=.05,symmetry_scale=.04):
    duration=np.clip(interval,0.,2.)
    active=landed&known_other&alternating
    quality,pair_loss=pair_step_terms(pair_lengths,goal_step,error_scale,symmetry_scale)
    pair_ready=pair_valid.all(1)
    elapsed=(duration*active).sum(1)
    peak_score=np.exp(-((np.maximum(.025-peak,0)+np.maximum(peak-.085,0))/.025)**2)
    event_height=(peak_score*active).sum(1)/np.maximum(active.sum(1),1)
    events=pair_ready*6*quality*event_height*elapsed
    # A weak short step remains in pair_lengths when the longer opposite step lands.
    cost=pair_ready*pair_loss*elapsed
    cost+=(landed*known_other*.35*pseudo_huber((step_length-goal_step)/error_scale)*duration).sum(1)
    cost+=(landed*known_other*(~alternating)*.5*duration).sum(1)
    return events,cost,quality,pair_loss

def speed_band_terms(speed,age,low=.15,high=.6,std=.07):
    u=np.clip(age/1.2,0,1);shape=u*u*u*(10+u*(-15+6*u))
    distance=np.maximum(low*shape-speed,0)+np.maximum(speed-high,0)
    return np.exp(-(distance/std)**2),np.minimum((distance/std)**2,9.)

@registry.envcfg('XDuckStep20StridePriority')
@dataclass
class Step20StridePriorityCfg(NewStandSmoothCfg):
    direction_speed_gain: float=.65
    direction_seed: int=1490091
    direction_switch_fraction: float=.6
    smooth_width_target_m: float=.212
    smooth_width_weight: float=2.
    smooth_height_weight: float=0.
    smooth_head_target: tuple[float,float]=(.018978888,.059834011)
    direction_stall_seconds: float=3.
    fast_ramp_updates: int=80
    fast_command_start: float=.30
    fast_command_low: float=.30
    fast_command_high: float=.30
    fast_step_start_m: float=.06
    fast_step_goal_m: float=.20
    fast_step_minimum_m: float=.18
    fast_step_maximum_m: float=.22
    fast_step_sigma_m: float=.03
    fast_speed_min_m_s: float=.15
    fast_speed_max_m_s: float=.60
    fast_speed_band_std_m_s: float=.07
    fast_start_allowed_drop_m: float=.02
    repair_error_scale_m: float=.05
    repair_symmetry_scale_m: float=.04
    repair_heading_scale_rad: float=.17
    repair_heading_gate_rad: float=.26
    repair_heading_weight: float=1.5
    repair_yawrate_scale_rad_s: float=.04
    repair_yawrate_weight: float=1.0
    repair_angular_std_rad_s: float=.12
    repair_yaw_ema_retention: float=.985
    repair_instant_yaw_scale_rad_s: float=.20
    repair_instant_yaw_weight: float=.1
    repair_pair_objective_weight: float=3.
    repair_lateral_scale_m: float=.10
    repair_lateral_weight: float=.5

@registry.env('XDuckStep20StridePriority',sim_backend='mjwarp')
class Step20StridePriorityEnv(RigidStartCourseEnv):
    def __init__(self,cfg,num_envs=1,backend_type='mjwarp'):
        self._dir_rng=np.random.default_rng(cfg.direction_seed)
        self._dir_commands=np.zeros((num_envs,13))
        self._dir_old_commands=np.zeros((num_envs,3))
        self._dir_kind=np.zeros(num_envs,int)
        self._fast_command_targets=np.zeros(num_envs)
        self._dir_age=np.zeros(num_envs,int)
        self._dir_next_switch=np.full(num_envs,np.inf)
        self._dir_mean_v=np.zeros((num_envs,2));self._dir_mean_w=np.zeros(num_envs)
        self._dir_land_time=np.full((num_envs,2),-1.)
        self._dir_land_position=np.zeros((num_envs,2,3))
        self._step_last_side=np.full(num_envs,-1,np.int8)
        self._pair_lengths=np.zeros((num_envs,2))
        self._touchdown_yaw=np.zeros((num_envs,2))
        self._pair_valid=np.zeros((num_envs,2),bool)
        self._repair_origin_xy=np.zeros((num_envs,2))
        self._step_mean_forward=np.zeros(num_envs)
        self._step_mean_lateral=np.zeros(num_envs)
        self._dir_land_axis=np.zeros((num_envs,2,3))
        self._dir_last_full=np.full(num_envs,-1.)
        self._dir_stall_at=np.full(num_envs,3.)
        self._dir_heading0=np.zeros(num_envs)
        if cfg.newstand_bank_path is None:
            raise ValueError('A physically collected new-standing bank is required')
        with np.load(cfg.newstand_bank_path) as z:
            self._newstand_bank = {k:z[k].copy() for k in z.files}
        self._newstand_rng = np.random.default_rng(cfg.newstand_seed)
        self._smooth_age = np.zeros(num_envs,int)
        self._smooth_z0 = np.zeros(num_envs)
        self._smooth_heading0 = np.zeros(num_envs)
        self._smooth_width0 = np.zeros(num_envs)
        self._smooth_previous_v = np.zeros(num_envs)
        self._smooth_air = np.zeros((num_envs,2),bool)
        self._smooth_peak = np.zeros((num_envs,2))
        self._smooth_liftoff = np.zeros((num_envs,2,3))
        self._smooth_axis = np.zeros((num_envs,2,3))
        self._smooth_landings = np.zeros(num_envs,int)
        # Model and site metadata are read only on initialization.
        m = mujoco.MjModel.from_binary_path(cfg.warp_compiled_model_file)
        self._smooth_site_local = np.array([m.site(s+'_foot').pos.copy() for s in ['left','right']])
        names = [m.body(int(m.site(s+'_foot').bodyid[0])).name for s in ['left','right']]
        super().__init__(cfg,num_envs=num_envs,backend_type=backend_type)
        self._smooth_body_ids = np.array([self._backend.get_body_id(n) for n in names],np.int32)
        assert len(self._passive_qpos_indices)==0 and not cfg.flexible_dr_enabled and cfg.physics_microsteps==1

    def _make_dr_provider(self):return Step20StridePriorityReset()

    def _fast_ramp(self):
        return float(np.clip((self.step_counter-self.cfg.startup_initial_step)/self.cfg.rollout_steps/self.cfg.fast_ramp_updates,0.,1.))

    def _set_direction(self,ids,initial=False):
        ids=np.asarray(ids,dtype=int);n=len(ids)
        self._fast_command_targets[ids]=self._dir_rng.uniform(self.cfg.fast_command_low,self.cfg.fast_command_high,n)
        self._dir_old_commands[ids]=0;self._dir_commands[ids]=0
        self._dir_commands[ids,0]=self.cfg.fast_command_start+(self._fast_command_targets[ids]-self.cfg.fast_command_start)*self._fast_ramp()
        self._dir_kind[ids]=0;self._dir_age[ids]=0;self._dir_mean_v[ids]=0;self._dir_mean_w[ids]=0
        self._dir_land_time[ids]=-1;self._dir_last_full[ids]=-1
        self._dir_stall_at[ids]=self._dir_rng.uniform(2.8,3.8,n);self._dir_next_switch[ids]=np.inf

    def _maybe_resample_commands(self,state):
        super()._maybe_resample_commands(state)
        self._dir_commands[:,0]=self.cfg.fast_command_start+(self._fast_command_targets-self.cfg.fast_command_start)*self._fast_ramp()
        state.info['commands'][:]=self._dir_commands

    def _reset_episode_history(self,ids):
        super()._reset_episode_history(ids)
        self._smooth_age[ids]=0;self._smooth_air[ids]=False;self._smooth_peak[ids]=0;self._smooth_landings[ids]=0
        self._dir_mean_v[ids]=0;self._dir_mean_w[ids]=0
        self._dir_land_time[ids]=-1;self._dir_last_full[ids]=-1
        self._dir_age[ids]=0
        self._step_last_side[ids]=-1
        self._pair_lengths[ids]=0;self._pair_valid[ids]=False;self._touchdown_yaw[ids]=0
        self._step_mean_forward[ids]=0;self._step_mean_lateral[ids]=0

    def _compute_reward(self,state,linvel,gyro,upvector,dof_pos):
        # Reuse the infrastructure/base regularizers, skipping all previous
        # positive-forward-only startup/style/progress rewards.
        reward=StartupFlexEnv._compute_reward(self,state,linvel,gyro,upvector,dof_pos)
        dt=self.cfg.ctrl_dt;episode_age=self._smooth_age*dt;age=self._dir_age*dt
        cmd=state.info['commands'][:,:3]
        q=self._backend.get_base_quat();w,x,y,z=q.T
        roll=np.arctan2(2*(w*x+y*z),1-2*(x*x+y*y))
        pitch=np.arcsin(np.clip(2*(w*y-z*x),-1,1))
        yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))
        yaw_rate=(gyro[:,1]*np.sin(roll)+gyro[:,2]*np.cos(roll))/np.maximum(np.cos(pitch),.5)
        translating,axis,speed,turn,target=motion_metrics(cmd,linvel,yaw_rate,self.cfg.direction_speed_gain)
        self._dir_mean_v=.95*self._dir_mean_v+.05*linvel[:,:2]
        self._dir_mean_w=self.cfg.repair_yaw_ema_retention*self._dir_mean_w+(1-self.cfg.repair_yaw_ema_retention)*yaw_rate
        world_velocity=rotate(q,linvel)
        forward_axis=np.c_[np.cos(self._dir_heading0),np.sin(self._dir_heading0),np.zeros(self.num_envs)]
        lateral_axis=np.c_[-np.sin(self._dir_heading0),np.cos(self._dir_heading0),np.zeros(self.num_envs)]
        forward_speed=np.sum(world_velocity*forward_axis,axis=1)
        lateral_speed=np.sum(world_velocity*lateral_axis,axis=1)
        self._step_mean_forward=.95*self._step_mean_forward+.05*forward_speed
        self._step_mean_lateral=.95*self._step_mean_lateral+.05*lateral_speed
        velocity_score,speed_cost=speed_band_terms(self._step_mean_forward,age,self.cfg.fast_speed_min_m_s,self.cfg.fast_speed_max_m_s,self.cfg.fast_speed_band_std_m_s)
        velocity_score*=np.exp(-(self._step_mean_lateral/.10)**2)
        instant_score,_=speed_band_terms(forward_speed,age,self.cfg.fast_speed_min_m_s,self.cfg.fast_speed_max_m_s,.16)
        instant_score*=np.exp(-(lateral_speed/.15)**2)
        angular_score=np.exp(-((self._dir_mean_w-cmd[:,2])/self.cfg.repair_angular_std_rad_s)**2)
        consistency=np.zeros(self.num_envs)
        pos,quat=self._backend.get_body_pose_w(self._smooth_body_ids)
        world=pos+rotate(quat,np.broadcast_to(self._smooth_site_local,pos.shape))
        inverse=q.copy();inverse[:,1:]*=-1
        width=np.abs(rotate(inverse,world[:,0]-world[:,1])[:,1])
        width_cost=np.minimum(((width-.212)/np.where(translating,.03,.045))**2,9.)
        height=self._backend.get_base_pos()[:,2]
        down_cost=np.minimum((np.maximum(self._smooth_z0-height-self.cfg.fast_start_allowed_drop_m,0)/.012)**2,9.)*(episode_age<2.)
        world_velocity=rotate(q,linvel)
        vertical_cost=np.minimum((np.maximum(abs(world_velocity[:,2])-.14,0)/.10)**2,9.)*(episode_age<2.)
        initial_roll_cost=np.minimum((np.maximum(abs(roll)-np.deg2rad(6),0)/.08)**2,9.)*(episode_age<1.)
        h=self._foot_height;leaving=(~self._smooth_air)&(h>.0015)
        self._smooth_peak=np.maximum(self._smooth_peak,h)
        seed=(self._dir_land_time<0)&self._contact&(h<.003)
        times=np.broadcast_to(episode_age[:,None],(self.num_envs,2))
        self._dir_land_position[seed]=world[seed];self._dir_land_time[seed]=times[seed]
        yaw_rows=np.broadcast_to(yaw[:,None],(self.num_envs,2));self._touchdown_yaw[seed]=yaw_rows[seed]
        landing=self._smooth_air&self._contact&(h<.003)
        touchdown=landing&(self._smooth_peak>=.008)
        known_other=self._dir_land_time[:,::-1]>=0
        step_axes=midpoint_step_axes(yaw,self._touchdown_yaw[:,::-1])
        step_length=opposite_step_lengths(world,self._dir_land_position,step_axes)
        interval=episode_age[:,None]-self._dir_land_time[:,::-1]
        one=touchdown.sum(1)==1;side=np.argmax(touchdown,axis=1)
        alternate_row=one&((self._step_last_side<0)|(side!=self._step_last_side))
        alternating=touchdown&alternate_row[:,None]
        ramp=self._fast_ramp();goal_step=self.cfg.fast_step_start_m+ramp*(self.cfg.fast_step_goal_m-self.cfg.fast_step_start_m)
        proper=touchdown
        valid_step=proper&known_other&alternating
        invalid_transition=touchdown.any(1)&(~alternate_row)
        self._pair_valid[invalid_transition]=False
        self._pair_lengths[valid_step]=step_length[valid_step];self._pair_valid[valid_step]=True
        events,gait_cost,pair_quality,pair_loss=paired_step_reward(proper,known_other,interval,step_length,self._smooth_peak,goal_step,alternating,self._pair_lengths,self._pair_valid,self.cfg.repair_error_scale_m,self.cfg.repair_symmetry_scale_m)
        events*=self.cfg.repair_pair_objective_weight;gait_cost*=self.cfg.repair_pair_objective_weight
        self._gait_events=events.copy();self._gait_cost=gait_cost.copy();self._fast_step_goal=goal_step
        short_cost=(landing&(self._smooth_peak<.014)).sum(1)*.5
        overheight=(landing*np.minimum((np.maximum(self._smooth_peak-.085,0)/.025)**2,4.)).sum(1)*.8
        self._dir_land_position[touchdown]=world[touchdown];self._dir_land_time[touchdown]=times[touchdown];self._touchdown_yaw[touchdown]=yaw_rows[touchdown]
        self._step_last_side[one]=side[one];self._step_last_side[touchdown.sum(1)>1]=-1
        self._dir_last_full[proper.any(1)]=episode_age[proper.any(1)]
        self._smooth_peak[landing]=0;self._smooth_air=(self._smooth_air|leaving)&(~landing)
        peak_goal=np.full(self.num_envs,.032)
        single=(h>.003).sum(1)==1
        swing=np.minimum(h.max(1)/peak_goal,1.)*single
        head=(dof_pos+self._encoder_bias)[:,[5,6]]
        head_score=np.exp(-np.mean(((head-np.array(self.cfg.smooth_head_target))/.15)**2,axis=1))
        # A small deviation is allowed; penalize large sustained turn on straight commands.
        straight=(np.abs(cmd[:,2])<.05)&translating
        unwanted_turn=np.minimum((np.maximum(abs(self._dir_mean_w)-.10,0)/.15)**2,4.)*straight
        # Forward world progress and heading stop a fast circling/skating shortcut.
        heading_error=np.arctan2(np.sin(yaw-self._dir_heading0),np.cos(yaw-self._dir_heading0))
        heading_cost=pseudo_huber(heading_error/self.cfg.repair_heading_scale_rad)
        heading_gate=np.exp(-(heading_error/self.cfg.repair_heading_gate_rad)**2)
        lateral_offset=np.sum((self._backend.get_base_pos()[:,:2]-self._repair_origin_xy)*lateral_axis[:,:2],axis=1)
        lateral_path_cost=pseudo_huber(lateral_offset/self.cfg.repair_lateral_scale_m)
        yawrate_cost=pseudo_huber(self._dir_mean_w/self.cfg.repair_yawrate_scale_rad_s)
        instant_yawrate_cost=pseudo_huber(yaw_rate/self.cfg.repair_instant_yaw_scale_rad_s)
        world_progress=world_velocity[:,0]*np.cos(self._dir_heading0)+world_velocity[:,1]*np.sin(self._dir_heading0)
        progress=np.clip(world_progress,-.3,self.cfg.fast_speed_min_m_s)
        normal=rotate(quat,rotate(self._sole_delta_quat,np.broadcast_to(np.array(self._sole_normals),pos.shape)))
        ground=self._contact&(h<.003)&(np.linalg.norm(normal[:,:,:2],axis=2)<.15)
        slip_speed=np.linalg.norm(self._foot_vel[:,:,:2],axis=2)
        slip_cost=(np.minimum((np.maximum(slip_speed-.08,0)/.20)**2,4.)*ground).sum(1)/np.maximum(ground.sum(1),1)
        density=(heading_gate*(2*velocity_score+instant_score+angular_score+4*progress+1.5*swing)
            -2*width_cost-2*down_cost-.5*vertical_cost-.5*initial_roll_cost
            -.5*(h>.003).all(1)+.6*head_score-.5*unwanted_turn
            -self.cfg.repair_heading_weight*heading_cost-self.cfg.repair_lateral_weight*lateral_path_cost-3*slip_cost-2*speed_cost-self.cfg.repair_yawrate_weight*yawrate_cost-self.cfg.repair_instant_yaw_weight*instant_yawrate_cost)
        reward=reward+(density*dt+events-short_cost-overheight-gait_cost).astype(reward.dtype)
        state.info.setdefault('log',{}).update({'repair/pair_quality':float(pair_quality[self._pair_valid.all(1)].mean()) if self._pair_valid.all(1).any() else 0.,'repair/pair_loss':float(pair_loss[self._pair_valid.all(1)].mean()) if self._pair_valid.all(1).any() else 0.,'repair/yawrate_cost':float(yawrate_cost.mean()),'repair/yawrate_abs_rad_s':float(abs(yaw_rate).mean()),'repair/slow_yawrate_abs_rad_s':float(abs(self._dir_mean_w).mean()),'repair/instant_yawrate_cost':float(instant_yawrate_cost.mean()),'repair/heading_gate':float(heading_gate.mean()),'repair/heading_abs_deg':float(np.degrees(abs(heading_error)).mean()),'repair/lateral_path_cost':float(lateral_path_cost.mean()),'fast/step_goal_m':float(goal_step),'fast/forward_speed_mean':float(self._step_mean_forward.mean()),'fast/command_mean':float(cmd[:,0].mean()),'fast/stance_slip_cost':float(slip_cost.mean()),'fast/speed_deviation_cost':float(speed_cost.mean()),'gait/event_reward':float(events.mean()),'fast/step_deviation_cost':float(gait_cost.mean()),'direction/vx':float(linvel[:,0].mean()),'direction/mean_speed_score':float(velocity_score.mean()),'direction/turn_score':float(angular_score.mean()),'direction/width_mm':float(width.mean()*1000),'direction/dr_consistency_cost':float(consistency.mean()),'direction/backward_fraction':float((cmd[:,0]<-.05).mean()),'direction/proper_step_fraction':float(proper.any(1).mean())})
        self._smooth_age+=1;self._dir_age+=1
        return reward

    def update_state(self,state):
        result=super().update_state(state)
        cmd=state.info['commands'][:,:3]
        translating,axis,speed,turn,target=motion_metrics(cmd,np.c_[self._dir_mean_v,np.zeros(self.num_envs)],self._dir_mean_w,self.cfg.direction_speed_gain)
        age=self._dir_age*self.cfg.ctrl_dt;episode=self._smooth_age*self.cfg.ctrl_dt
        movement=np.where(translating,speed>.045,turn>.08)
        stalled=(age>self._dir_stall_at)&((~movement)|(self._dir_last_full<0)|((episode-self._dir_last_full)>2.1))
        newly=stalled&(~result.terminated)
        return result.replace(terminated=result.terminated|stalled,reward=result.reward-(3*newly).astype(result.reward.dtype))

class Step20StridePriorityReset(NewStandBankReset):
    def build_reset_plan(self,env,ids):
        plan=super().build_reset_plan(env,ids)
        env._set_direction(ids,initial=True)
        env._repair_origin_xy[np.asarray(ids,dtype=int)]=plan.qpos[:,:2]
        plan.info_updates['commands'][:]=env._dir_commands[ids]
        q=plan.qpos[:,3:7]
        env._dir_heading0[ids]=np.arctan2(2*(q[:,0]*q[:,3]+q[:,1]*q[:,2]),1-2*(q[:,2]**2+q[:,3]**2))
        return plan

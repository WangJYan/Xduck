from common import *
from scipy.optimize import least_squares
from runtime import atomic_json
m,qi,vi,names,local=metadata();b=np.load(R/'train_rigid_bank.npz');d=mujoco.MjData(m);q=b['qpos'][0].copy();q[:2]=0;q[3:7]=[1,0,0,0];d.qpos[:]=q;mujoco.mj_forward(m,d)
sites=np.array([m.site(s+'_foot').id for s in ['left','right']]);bids=np.array([m.body(n).id for n in names]);normal=np.array([d.xmat[bid].reshape(3,3).T@np.array([0.,0.,1.]) for bid in bids]);basefeet=d.site_xpos[sites].copy();legs=np.array([0,1,2,3,4,9,10,11,12,13]);jointids=m.actuator_trnid[legs,0];lo=m.jnt_range[jointids,0]+1e-4;hi=m.jnt_range[jointids,1]-1e-4;x0=np.clip(q[qi[legs]],lo,hi);records=[]
for rootz in [float(q[2]),.30]:
 for length in [.06,.10,.14,.18,.20]:
  target=basefeet.copy();target[:,0]=basefeet[:,0].mean()+np.array([length/2,-length/2]);target[:,2]=.003
  def residual(x):
   d.qpos[:]=q;d.qpos[2]=rootz;d.qpos[qi[legs]]=x;mujoco.mj_forward(m,d);norm=np.array([d.xmat[bid].reshape(3,3)@n for bid,n in zip(bids,normal)])
   return np.r_[(d.site_xpos[sites]-target).ravel()/.01,norm[:,:2].ravel()/.10]
  best=least_squares(residual,x0,bounds=(lo,hi),max_nfev=1000,ftol=1e-11,xtol=1e-11,gtol=1e-11);residual(best.x)
  err=float(np.max(np.linalg.norm(d.site_xpos[sites]-target,axis=1)));norm=np.array([d.xmat[bid].reshape(3,3)@n for bid,n in zip(bids,normal)]);tilt=float(np.degrees(np.arccos(np.clip(norm[:,2],-1,1))).max())
  records.append(dict(root_height_m=rootz,opposite_foot_separation_m=length,max_foot_target_error_m=err,max_foot_tilt_deg=tilt,within_joint_limits=True,feasible=err<.002 and tilt<2,leg_angles_rad=best.x.tolist()))
assert any(r['feasible'] and r['opposite_foot_separation_m']==.20 for r in records)
atomic_json(R/'REACH_AUDIT.json',dict(status='PASS_KINEMATIC_ONLY',dynamic_balance_demonstrated=False,records=records));print(json.dumps(records,indent=2))

from pathlib import Path
import json,ast,numpy as np
from large_step_objective import *
from speed_history import TranslationSpeedHistory
from curriculum import ExactCheckpointFilter
R=Path(__file__).resolve().parent
# Both feet must improve; at a fixed valid speed20cm earns more per second than6cm.
lengths=np.repeat(np.linspace(0,.30,301)[:,None],2,axis=1);s=length_score(lengths)
assert np.all(np.diff(s)>=-1e-12) and s[60]<s[100]<s[200] and s[200]==s[300]==1
for speed in [.1,.2,.3,.35]:
 rates=[]
 for L in [.03,.06,.10,.14,.18,.20]:
  bonus=touchdown_credit(np.array([[1,0]],bool),np.ones((1,2),bool),np.full((1,2),L),np.full((1,2),.04),np.zeros(1),np.zeros(1),np.array([speed]))[0]
  rates.append(bonus*speed/L)
 assert np.all(np.diff(rates)>0),rates
# One long side and one short side does not get the full-length bonus.
assert length_score(np.array([[.2,.04]]))[0]==length_score(np.array([[.04,.04]]))[0]
# No elapsed interval in credit: pauses add zero credit; no side update means zero bonus.
assert touchdown_credit(np.zeros((1,2),bool),np.ones((1,2),bool),np.full((1,2),.2),np.full((1,2),.04),np.zeros(1),np.zeros(1),np.array([.3]))[0]==0
# Independent penalties rise with excess speed / yaw even when posture/gait gate is zero.
v,h=independent_costs(np.array([0,.2,.35,.4,.5]),np.array([0,.1,.2,.3,.4]));assert np.all(v[:3]==0) and v[3]>0 and v[4]>v[3] and np.all(np.diff(h)>0)
# Shaping telescopes to zero, including failed/reversed swings and terminal-in-air closure.
for phi in [np.array([0,1,2,0,3,0.]),np.array([0,3,2,1,0.])]:
 rewards=GAMMA*phi[1:]-phi[:-1];assert abs(sum(GAMMA**np.arange(len(rewards))*rewards))<1e-10
h=TranslationSpeedHistory(2);h.reset(np.arange(2),np.zeros((2,2)))
for k in range(1,301):
 t=k*.02;v=h.update(np.array([[.3*t,.03*np.sin(4*np.pi*t)],[0,0]]),np.full(2,k))
 if k>100:np.testing.assert_allclose(v,[.3,0],atol=1e-10)
h.reset(np.array([0]),np.array([[10,1]]));v=h.update(np.array([[10.006,1],[0,0]]),np.array([1,301]));np.testing.assert_allclose(v,[.3,0],atol=1e-10)
f=ExactCheckpointFilter(50,400);assert [i for i in range(1,401) if f.accept(i)]==list(range(50,401,50)) and not f.accept(400)
assert FixedGoal().goal==.2 and not FixedGoal().advance(400)
for p in R.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
source=(R/'direct_step.py').read_text();assert 'self.curriculum = FixedGoal()' in source and 'terminal_shaping = GAMMA*self._stride_potential*ended' in source and 'self._stride_potential[ids] = 0' in source
report=dict(status='PASS',fixed20cm_from_start=True,longer_valid_steps_earn_more_at_same_speed=True,both_sides_required=True,pause_does_not_accumulate_credit=True,no_velocity_lower_bound=True,independent_speed_heading_penalties=True,potential_telescoping_zero=True,partial_speed_reset=True,checkpoint_every50=True)
(R/'CPU_TESTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

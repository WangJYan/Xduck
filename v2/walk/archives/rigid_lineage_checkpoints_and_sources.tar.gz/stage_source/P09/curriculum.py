from collections import deque
import numpy as np
GOALS=(.06,.08,.10,.12,.14,.16,.18,.20)
class GaitCurriculum:
 def __init__(self,min_updates=25,min_samples=512,window=1024,threshold=.8):
  self.stage=0;self.last_advance=0;self.min_updates=min_updates;self.min_samples=min_samples;self.threshold=threshold;self.results=deque(maxlen=window);self.transitions=[]
 @property
 def goal(self):return GOALS[self.stage]
 def record(self,passed):self.results.extend(bool(v) for v in passed)
 def advance(self,update):
  rate=float(np.mean(self.results)) if self.results else 0.
  if self.stage==len(GOALS)-1 or update-self.last_advance<self.min_updates or len(self.results)<self.min_samples or rate<self.threshold:return False
  old=self.goal;self.stage+=1;self.last_advance=update;self.transitions.append(dict(update=update,old_goal_m=old,new_goal_m=self.goal,pass_rate=rate,samples=len(self.results)));self.results.clear();return True
 def snapshot(self):return dict(stage=self.stage,current_goal_m=self.goal,final_goal_m=.2,last_advance_update=self.last_advance,recent_samples=len(self.results),recent_pass_rate=float(np.mean(self.results)) if self.results else None,transitions=self.transitions)
class ExactCheckpointFilter:
 def __init__(self,interval=50,total=400):self.interval=interval;self.total=total;self.saved=set()
 def accept(self,completed):
  if completed in self.saved or completed<=0 or not (completed%self.interval==0 or completed==self.total):return False
  self.saved.add(completed);return True

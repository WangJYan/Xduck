from pathlib import Path
import os,json,subprocess,hashlib,argparse
os.environ.setdefault('MUJOCO_GL','egl')
import numpy as np,mujoco,imageio_ffmpeg
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--prefix',default='probe_50');a=ap.parse_args();z=np.load(R/(a.prefix+'_trace.npz'));rs=json.loads((R/(a.prefix+'_results.json')).read_text())['records'];m=mujoco.MjModel.from_binary_path(str(R/'physics/effective_training.mjb'));d=mujoco.MjData(m)
W,H=640,360;m.vis.global_.offwidth=W;m.vis.global_.offheight=H;m.mat_rgba[:,3]=1;m.geom_rgba[:,3]=1;m.geom_group[:]=0
renderer=mujoco.Renderer(m,height=H,width=W);opt=mujoco.MjvOption();cam=mujoco.MjvCamera();entries=[]
for scenario in ['forward']:
 for model in ['flex50_baseline','candidate']:
  r=next(r for r in rs if r['model']==model and r['scenario']==scenario and r['case']==0)
  entries.append((r['trace_index'],f'{model if model=="flex50_baseline" else "direct_step20_400"} | cmd=0.30 | DR0'))
def panel(j,t,label):
 u=t/.02;i=min(int(u),len(z['qpos']));f=u-int(u);q0=z['initial'][j] if i==0 else z['qpos'][i-1,j];q1=z['qpos'][min(i,len(z['qpos'])-1),j];d.qpos[:]=(1-f)*q0+f*q1;d.qpos[3:7]/=np.linalg.norm(d.qpos[3:7]);m.geom_pos[:]=z['geom_pos'][j];m.geom_quat[:]=z['geom_quat'][j];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d)
 w,x,y,zz=z['initial'][j,3:7];yaw=np.degrees(np.arctan2(2*(w*zz+x*y),1-2*(y*y+zz*zz)));cam.azimuth=yaw+90;cam.elevation=-9;cam.distance=1.4;cam.lookat[:]=d.qpos[:3];cam.lookat[2]=.31
 renderer.update_scene(d,camera=cam,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,W,44),fill=(15,25,36));draw.text((10,6),label,fill='white');draw.text((10,25),f't={t:.2f}s | 1x | actual rigid closed-loop trajectory',fill='white');return im
ff=subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-v','error','-f','rawvideo','-s',f'{W*2}x{H}','-pix_fmt','rgb24','-r','25','-i','-','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p',str(R/(a.prefix+'_1x.mp4'))],stdin=subprocess.PIPE)
try:
 for frame in range(400):
  im=Image.new('RGB',(W*2,H))
  for k,(j,label) in enumerate(entries):im.paste(panel(j,frame/25,label),((k%2)*W,(k//2)*H))
  if frame==75:im.save(R/(a.prefix+'_preview.png'))
  ff.stdin.write(np.asarray(im).tobytes())
finally:ff.stdin.close();assert ff.wait()==0;renderer.close()
(R/(a.prefix+'_video_binding.json')).write_text(json.dumps(dict(source_trace=a.prefix+'_trace.npz',source_trace_sha256=hashlib.sha256((R/(a.prefix+'_trace.npz')).read_bytes()).hexdigest(),panels=entries,selection='DR case 0 fixed before result inspection; no failure trimming',seconds=16,fps=25,speed=1),indent=2));print('VIDEO_READY',flush=True)

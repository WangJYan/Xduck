from pathlib import Path
import json,os,hashlib,time
from curriculum import ExactCheckpointFilter

def atomic_json(path,data):
 path=Path(path);tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(data,indent=2));os.replace(tmp,path)

def attach_exact_saves(runner,env,root,total=400):
 root=Path(root);decision=ExactCheckpointFilter(50,total);original=runner.save;pid=os.getpid();env_identity=id(env)
 def save(path,infos=None):
  completed=int(runner.current_learning_iteration)+1
  if not decision.accept(completed):return
  info=dict(infos or {});info['curriculum']=env.curriculum.snapshot();info['runtime']=dict(training_pid=pid,environment_identity=env_identity,continuous_process=True,rollout_steps=24)
  final=root/'ppo_run'/f'model_{completed-1}.pt';tmp=final.with_name(final.name+'.tmp')
  original(str(tmp),infos=info);os.replace(tmp,final)
  atomic_json(root/f'CHECKPOINT_{completed}.json',dict(completed_updates=completed,checkpoint=str(final.relative_to(root)),sha256=hashlib.sha256(final.read_bytes()).hexdigest(),training_pid=pid,environment_identity=env_identity,curriculum=env.curriculum.snapshot(),saved_unix=time.time()))
 runner.save=save
 # Actual RSL-RL loop calls save at each iteration; this filter writes only exact50-update boundaries.
 runner.cfg['save_interval']=1
 return decision

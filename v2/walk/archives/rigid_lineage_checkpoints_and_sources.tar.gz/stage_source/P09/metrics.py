import numpy as np

def alternating_step_statistics(events,forward_axis,body_frame=False):
    """events: chronological {time,side,point,peak}; side0=L,1=R."""
    lengths=[];intervals=[];left=[];right=[];invalid=0
    for a,b in zip(events,events[1:]):
        dt=b['time']-a['time']
        if a['side']==b['side'] or dt<.04-1e-9:
            invalid+=1;continue
        axis=forward_axis
        if body_frame:
            delta=np.arctan2(np.sin(b['yaw']-a['yaw']),np.cos(b['yaw']-a['yaw']));phi=a['yaw']+.5*delta;axis=np.array([np.cos(phi),np.sin(phi),0.])
        length=float((np.asarray(b['point'])-np.asarray(a['point']))@axis)
        lengths.append(length);intervals.append(dt);(left if b['side']==0 else right).append(length)
    def median(x):return float(np.median(x)) if x else None
    return dict(step_count=len(lengths),left_step_count=len(left),right_step_count=len(right),left_step_median_m=median(left),right_step_median_m=median(right),step_median_m=median(lengths),step_min_m=min(lengths) if lengths else None,step_p10_m=float(np.percentile(lengths,10)) if lengths else None,step_p90_m=float(np.percentile(lengths,90)) if lengths else None,step_interval_median_s=median(intervals),invalid_transitions=invalid,alternating_fraction=len(lengths)/max(len(events)-1,1))

def step_target_pass(stats,target=.20):
    return bool(stats['left_step_count']>=3 and stats['right_step_count']>=3 and stats['alternating_fraction']>=.9 and .9*target<=stats['left_step_median_m']<=1.1*target and .9*target<=stats['right_step_median_m']<=1.1*target and stats['step_p10_m']>=.85*target and stats['step_p90_m']<=1.15*target)

def measurement_self_test():
    axis=np.array([1.,0,0]);events=[dict(time=i*.5,side=i%2,point=np.array([i*.2,0,0]),peak=.04) for i in range(10)]
    good=alternating_step_statistics(events,axis);assert abs(good['step_median_m']-.2)<1e-9 and step_target_pass(good)
    # Opposite-foot20cm means same-foot40cm; this test catches the former metric error.
    assert abs(events[2]['point'][0]-events[0]['point'][0]-.4)<1e-9
    uneven=[];x=0.
    for i in range(10):
        if i:x+=.1 if i%2 else .3
        uneven.append(dict(time=i*.5,side=i%2,point=np.array([x,0,0]),peak=.04))
    assert not step_target_pass(alternating_step_statistics(uneven,axis))
    hops=[dict(time=(i//2)*.5,side=i%2,point=np.array([(i//2)*.4,0,0]),peak=.04) for i in range(10)]
    assert not step_target_pass(alternating_step_statistics(hops,axis))
    # A60deg turn projects lateral stance width onto globalX; physical step stays20cm.
    phi=np.pi/3;rot=np.array([[np.cos(phi),-np.sin(phi),0],[np.sin(phi),np.cos(phi),0],[0,0,1]])
    turned=[dict(time=i*.5,side=i%2,point=rot@np.array([i*.2, .106 if i%2==0 else -.106,0]),peak=.04,yaw=phi) for i in range(10)]
    physical=alternating_step_statistics(turned,axis,body_frame=True);global_projection=alternating_step_statistics(turned,axis)
    assert step_target_pass(physical) and not step_target_pass(global_projection)
    return True

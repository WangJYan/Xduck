from pathlib import Path
import json,hashlib,shutil
from omegaconf import OmegaConf
R=Path(__file__).resolve().parent
p=R/'project/src/unilab/algos/torch/masked_anchor.py';s=p.read_text()
s=s.replace('fixed_learning_rate=5e-5,**kwargs','fixed_learning_rate=5e-5,anchor_pool_weights=None,**kwargs')
s=s.replace('self.generator=torch.Generator',"self.anchor_pool_weights=list(anchor_pool_weights) if anchor_pool_weights is not None else [2.,1.,.5,2.]\n  assert len(self.anchor_pool_weights)>=len(self.pools)\n  self.generator=torch.Generator")
s=s.replace('weights=[2.,1.,.5,2.]','weights=self.anchor_pool_weights');p.write_text(s)
shutil.copy2(R/'balanced_env.py',R/'project/src/unilab/envs/locomotion/xduck_gf43x40/balanced_env.py')
c=OmegaConf.load(R/'TRAINING_CONFIG.yaml');c.algo.seed=1105291;c.env.newstand_seed=1105292;c.env.direction_seed=1105293;c.algo.algorithm.anchor_dataset=str(R/'motion_anchor.npz');c.algo.algorithm.anchor_weight=.025;c.algo.algorithm.anchor_pool_weights=[3.,.5,1.];OmegaConf.save(c,R/'TRAINING_CONFIG.yaml')
io=json.loads((R/'IO_CONTRACT.json').read_text());io.update(version='multimotion-phase61-v5',parent_sha256=json.loads((R/'PARENT.json').read_text())['seed_sha256'],teacher_distillation='PARENT.json');(R/'IO_CONTRACT.json').write_text(json.dumps(io,indent=2))
design=json.loads((R/'DESIGN.json').read_text());design.update(parent='audited distillation of keep10 forward and original flex50 backward/turn',parent_sha256=io['parent_sha256'],failed_parent_used=False,reward_fixes=['no positive heading bonus for stationary backward','linear signed progress from rest','posture credit gated by progress after grace','excess side contacts charged once','turn per-foot stepping reference','restore frozen physical teacher anchors'],anchor_pools=['keep10_forward','original_backward','original_inplace_turn']);(R/'DESIGN.json').write_text(json.dumps(design,indent=2))
old=json.loads((R/'audit_failed_reward_audit.json').read_text());original=json.loads((R/'audit_original_summary.json').read_text())
report=dict(status='PASS_REWARD_REPAIR',evidence=dict(failed_stationary_backward_reward_per_s=old['components_per_second']['backward']['reward'],failed_stationary_backward_heading_velocity_bonus_per_s=old['components_per_second']['backward']['locomotion'],failed_side_standing_reward_per_s=old['components_per_second']['side_left']['reward'],original_turning_and_backward_motion_observed=True,normalizer_command_channels_unchanged=True),scope='reward and seed repair; final tasks remain subject to physical evaluation',source_reports=['audit_failed_reward_audit.json','audit_original_summary.json'],repaired_reward_tests='CPU_TESTS.json')
(R/'REPAIR_AUDIT.json').write_text(json.dumps(report,indent=2))
# Export the actual distilled initialization so parent checkpoint/ONNX agree.
import torch,onnxruntime as ort,numpy as np
from model_io import NativeActor
actor=NativeActor(R/'parent_walk400.pt').eval();torch.onnx.export(actor,torch.zeros(1,61),str(R/'parent_walk400.onnx'),input_names=['obs'],output_names=['actions'],opset_version=17,dynamo=False)
sess=ort.InferenceSession(str(R/'parent_walk400.onnx'),providers=['CPUExecutionProvider']);x=np.random.default_rng(1105294).normal(0,.15,(16,61)).astype(np.float32)
with torch.inference_mode():expected=actor(torch.tensor(x)).numpy()
actual=np.concatenate([sess.run(None,{'obs':v[None]})[0] for v in x]);error=float(abs(expected-actual).max());assert error<3e-5 and not actual[:,5:9].any()
report['parent_onnx_error']=error;(R/'REPAIR_AUDIT.json').write_text(json.dumps(report,indent=2));print('REPAIR_CONFIGURED',error,flush=True)

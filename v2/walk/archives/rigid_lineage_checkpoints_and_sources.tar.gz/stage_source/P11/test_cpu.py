from pathlib import Path
import ast,json,numpy as np
from balance_objective import terms
from task_adapter import TaskAdapter,reference
R=Path(__file__).resolve().parent
for p in R.glob('*.py'):ast.parse(p.read_text())
n=8;zero=np.zeros(n);one=np.ones(n);length=np.full((n,2),.1);valid=np.ones((n,2),bool)
cmd=np.array([[.24,0,0],[-.24,0,0],[0,0,.35],[0,0,-.35],[0,.1,0],[0,-.1,0],[.24,0,.35],[-.24,0,-.35]])
def calc(v,yaw,pres=one,events=zero):
 return terms(valid,length,np.full((n,2),.035),np.zeros((n,2)),np.zeros((n,2)),valid,np.zeros((n,2)),np.zeros((n,2)),~valid,one,np.linalg.norm(v[:,:2],axis=1),yaw,cmd,pres,zero,.1,True,local_velocity=v,requested=cmd,heading_error=zero,side=np.isin(np.arange(n),[4,5]),side_displacement=zero,forward_displacement=zero,segment_age=one*5,side_lands=np.zeros((n,2),int),side_tracking=zero,extra_events=events,net_velocity=v[:,:2],loss_update=200)
a=calc(cmd,cmd[:,2]);b=calc(np.zeros_like(cmd),zero,zero)
assert a['locomotion_credit'][2]>b['locomotion_credit'][2]+7
assert a['locomotion_credit'][3]>b['locomotion_credit'][3]+7
assert b['locomotion_credit'][0]==b['locomotion_credit'][1]==0
assert (b['idle'][0]>4) and (b['idle'][2]>=4)
assert b['posture_gate'][0]==.15
c=calc(cmd,cmd[:,2],zero);assert c['locomotion_credit'][2]==a['locomotion_credit'][2]
assert a['landing'][0]==a['landing'][1]
ad=TaskAdapter(n,[0,0],[.04,.04],.1,True);ad.reset(np.arange(n),zero);ad.advance(zero,cmd,dt=.02,feedback=False);assert abs(ad.phase[0]-ad.phase[1])<1e-12
x,h,sw,ramp=reference(one,np.arange(n)/n,zero,np.tile([-.04,.04],(n,1)));assert x.shape==(n,2) and np.isfinite(x).all()
# A prior extra step must incur no further cumulative charge when no new contact occurs.
no=calc(cmd,cmd[:,2]);event=calc(cmd,cmd[:,2],events=np.isin(np.arange(n),[4,5]).astype(float));assert np.allclose((event['side_cost']-no['side_cost'])[[4,5]]*.02,.5)
for value in a.values():assert np.isfinite(value).all()
(R/'CPU_TESTS.json').write_text(json.dumps(dict(status='PASS',checks=['all_python_parsed','standing_no_walk_credit','standing_no_turn_credit','idle_penalty_and_posture_gate','turn_progress_independent_of_stride','reverse_forward_reward_equal','backward_phase_interval','per_foot_turn_reference','excess_contact_cost_charged_once','finite_terms']),indent=2))
print('CPU_TEST_PASS',flush=True)

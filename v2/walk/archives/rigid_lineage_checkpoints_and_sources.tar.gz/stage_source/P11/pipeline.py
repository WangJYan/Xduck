from pathlib import Path
import os,subprocess,time,json,fcntl,traceback
from runtime import atomic_json
R=Path(__file__).resolve().parent;lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);P=['/home/xingchen/.local/bin/uv','run','--python',str(R/'project/.venv/bin/python'),'--no-project']
def status(s,**kw):atomic_json(R/'RUN_STATUS.json',dict(status=s,controller_pid=os.getpid(),requested_updates=400,updated_unix=time.time(),**kw));print(s,kw,flush=True)
def free():return int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).splitlines()[0])
def wait_gpu(threshold=14336):
 while free()<threshold:status('WAITING_FOR_GPU',free_mib=free());time.sleep(20)
def run(script,args=(),log=None):
 with (R/(log or script.replace('.py','.log'))).open('a') as f:subprocess.run(P+[str(R/script),*map(str,args)],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
def evaluate(n,final=False):
 status('EVALUATING',checkpoint_updates=n,training_continues=not final);run('evaluate.py',['--checkpoint',f'ppo_run/model_{n-1}.pt','--prefix',f'probe_{n}']);run('export.py',['--updates',n])
 if final:
  run('collect_bank.py',['--prefix','fresh_final_bank','--seed',1105191,'--n',32]);run('evaluate.py',['--checkpoint',f'ppo_run/model_{n-1}.pt','--prefix','final32','--bank','fresh_final_bank.npz','--n',32],'final32.log')
try:
 status('CPU_AUDIT');run('test_cpu.py');run('audit.py');wait_gpu();status('SMOKE_SMALL');run('train.py',['--smoke','--smoke-envs',16],'smoke_small.log')
 wait_gpu();status('INITIAL_CLOSED_LOOP_CHECK');run('evaluate.py',['--preflight','--prefix','preflight'],'preflight.log');wait_gpu();status('SMOKE_4096');run('train.py',['--smoke','--smoke-envs',4096],'smoke_4096.log');run('audit.py',['--final']);wait_gpu();status('TRAINING_RUNNING')
 with (R/'train.log').open('a') as f:
  child=subprocess.Popen(P+[str(R/'train.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT);checked=False
  while child.poll() is None:
   if not checked and (R/'CHECKPOINT_200.json').exists() and free()>=10000:evaluate(200);checked=True;status('TRAINING_RUNNING',checkpoint200_evaluated=True)
   time.sleep(15)
  assert child.returncode==0,child.returncode
 if not checked:wait_gpu();evaluate(200)
 wait_gpu();evaluate(400,True)
 report=json.loads((R/'final32_summary.json').read_text());outcome=report['status'];atomic_json(R/'ACCEPTANCE.json',dict(status=outcome,final_report='final32_summary.json',raw_policy_turning_required=True))
 import zipfile
 with zipfile.ZipFile(R/'multimotion_repair_400_bundle.zip','a',zipfile.ZIP_DEFLATED) as z:
  for name in ['ACCEPTANCE.json','final32_summary.json','DESIGN.json']:z.write(R/name,name)
 status('COMPLETE',completed_updates=400,result=outcome,final_report='final32_summary.json')
except BaseException as ex:status('FAILED',error=repr(ex),traceback=traceback.format_exc());raise

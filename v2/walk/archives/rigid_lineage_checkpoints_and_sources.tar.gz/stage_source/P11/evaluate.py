from common import *
from unilab.envs.locomotion.xduck_gf43x40.balanced_env import BalancedPhaseEnv
from metrics import alternating_step_statistics
from runtime import atomic_json
from model_io import NativeActor
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--checkpoint',default='parent_walk400.pt');ap.add_argument('--prefix',default='preflight');ap.add_argument('--bank',default='heldout_rigid_bank.npz');ap.add_argument('--n',type=int,default=8);ap.add_argument('--preflight',action='store_true');a=ap.parse_args()
scenarios=['forward','backward','forward_left','forward_right','backward_left','backward_right','inplace_left','inplace_right','side_left','side_right'];K=len(scenarios);B=a.n;N=K*B;torch.set_num_threads(2)
actor=NativeActor(R/a.checkpoint).eval();c=OmegaConf.load(R/'TRAINING_CONFIG.yaml');c.env.newstand_bank_path=str(R/a.bank);E.ensure_registries();e=E.create_env(c,num_envs=N,env_cfg_override=E.build_ppo_env_cfg_override(c));m,qi,vi,names,local=metadata()
class Rows:
 def __init__(self):self.rng=np.random.default_rng(1105199)
 def integers(self,high,size):return np.tile(np.arange(B),K)
 def uniform(self,*args,**kw):return self.rng.uniform(*args,**kw)
 def random(self,*args,**kw):return self.rng.random(*args,**kw)
e._newstand_rng=Rows()
def desired(t):
 commands=[]
 for name in scenarios:
  vx=-.24 if name.startswith('backward') else .24 if name.startswith('forward') else 0.
  vy=(.10 if name=='side_left' else -.10) if name.startswith('side') and t<1.2 else 0.
  w=(.35 if name.endswith('left') else -.35) if ('left' in name or 'right' in name) and not name.startswith('side') else 0.
  commands.extend([[vx,vy,w]]*B)
 return np.asarray(commands)
def fixed(ids,initial=False):
 ids=np.asarray(ids,int);e._task_kind[ids]=ids//B;e._requested[ids]=desired(0)[ids];e._dir_commands[ids]=0;e._dir_commands[ids,:3]=e._requested[ids];e._feedback[ids]=False;e._next_switch[ids]=1e9;e._segment_start[ids]=0;e._side_lands[ids]=0
 # Origins are overwritten by the reset plan after this call.
e._set_direction=fixed
original_phase_reset=e._phase.reset
def paired(ids,yaw,offset=0):return original_phase_reset(ids,yaw,(np.asarray(ids)%B%2)*.5)
e._phase.reset=paired
bodyids=np.array([e._backend.get_body_id(n) for n in names],np.int32);trace=[]
try:
 e.init_state();e.set_autoreset(False);initial,_=state(e,m)
 for tick in range(1000):
  e._requested[:]=desired(tick*.02)
  obs=e.state.obs['obs'].copy();obs[:,48:51]=e._requested
  with torch.inference_mode():raw=actor(torch.tensor(obs,dtype=torch.float32)).numpy()
  assert np.isfinite(raw).all();assert not raw[:,5:9].any()
  s=e.step(raw);q,v=state(e,m);cap=e._audit_task
  assert np.isfinite(q).all() and np.isfinite(s.reward).all()
  pos,quat=e._backend.get_body_pose_w(bodyids);feet=pos+rotate(quat,np.broadcast_to(local,pos.shape))
  trace.append(dict(qpos=q,feet_world=feet,contact=e._contact.copy(),clearance=e._foot_height.copy(),requested=e._requested.copy(),heading_error=cap['heading_error'],speed2s=cap['speed2s'],yaw_rate=cap['yaw_rate'],local_velocity=cap['local_velocity']))
  if (tick+1)%250==0:print('MULTIMOTION_EVAL',tick+1,flush=True)
 z={key:np.asarray([r[key] for r in trace]) for key in trace[0]};bank=np.load(R/a.bank);ids=np.tile(np.arange(B),K)
 np.savez_compressed(R/(a.prefix+'_trace.npz'),**z,initial=initial,**{k:bank[k][ids] for k in FIELDS});records=[]
 for j in range(N):
  name=scenarios[j//B];q=z['qpos'][:,j];tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,4]**2+q[:,5]**2),-1,1)));stable=bool(tilt.max()<20 and q[:,2].min()>.25)
  h0=np.arctan2(2*(initial[j,3]*initial[j,6]+initial[j,4]*initial[j,5]),1-2*(initial[j,5]**2+initial[j,6]**2));f=np.array([np.cos(h0),np.sin(h0)]);l=np.array([-np.sin(h0),np.cos(h0)])
  side=name.startswith('side');inplace=name.startswith('inplace');back=name.startswith('backward');walk=not side and not inplace
  delta=q[-1,:2]-initial[j,:2];headingmax=float(np.degrees(abs(z['heading_error'][100:,j])).max());yawmae=float(np.mean(abs(z['yaw_rate'][100:,j]-z['requested'][100:,j,2])));speedmax=float(z['speed2s'][100:,j].max())
  turnsign=np.abs(z['requested'][100:,j,2])>.1
  signfraction=float(np.mean(np.sign(z['yaw_rate'][100:,j][turnsign])==np.sign(z['requested'][100:,j,2][turnsign]))) if turnsign.any() else 1.
  head=float(np.percentile(np.degrees(abs(q[100:,qi[5:9]])),95));headpass=head<=5
  air=np.zeros(2,bool);peak=np.zeros(2);events=[];counts=np.zeros(2,int)
  for ti,h in enumerate(z['clearance'][:,j]):
   peak=np.maximum(peak,h);leaving=(~air)&(h>.0015);landing=air&z['contact'][ti,j]&(h<.003)
   for foot in np.flatnonzero(landing):
    if peak[foot]>=.008:
     counts[foot]+=1
     if ti>=200:
      p=q[ti];w,x,y,zz=p[3:7];yaw=np.arctan2(2*(w*zz+x*y),1-2*(y*y+zz*zz))+(np.pi if back else 0)
      events.append(dict(time=(ti+1)*.02,side=int(foot),point=z['feet_world'][ti,j,foot],peak=float(peak[foot]),yaw=float(yaw)))
   peak[landing]=0;air=(air|leaving)&(~landing)
  steps=alternating_step_statistics(events,np.array([1,0,0]),body_frame=True)
  gaitpass=(not walk) or (all(steps[k] is not None and .08<=steps[k]<=.12 for k in ['left_step_median_m','right_step_median_m']) and steps['alternating_fraction']>=.9)
  turnpass=yawmae<.15 and headingmax<20 and signfraction>=.8
  if inplace:turnpass=turnpass and np.linalg.norm(delta)<.30
  if walk and name in ['forward','backward']:
   signedforward=float(delta@f)*(-1 if back else 1);turnpass=turnpass and signedforward>.2 and abs(delta@l)<max(.1,signedforward*np.tan(np.deg2rad(20)))
  sidepass=True;sidedistance=None
  if side:
   sidedistance=float(delta@l)*(1 if name=='side_left' else -1)
   sidepass=bool(.07<=sidedistance<=.13 and abs(delta@f)<=.04 and np.linalg.norm(z['local_velocity'][-100:,j,:2],axis=1).mean()<.04 and z['contact'][-100:,j].all(1).mean()>.8 and counts.min()>=1 and counts.max()<=2 and headingmax<10)
  records.append(dict(scenario=name,model='candidate',case=j%B,trace_index=j,feedback=False,stable=stable,mean_body_forward_velocity_m_s=float(z['local_velocity'][100:,j,0].mean()),mean_body_yaw_rate_rad_s=float(z['yaw_rate'][100:,j].mean()),max_tilt_deg=float(tilt.max()),head_pass=bool(headpass),head_p95_abs_deg=head,turn_pass=bool(turnpass),yaw_rate_mae_rad_s=yawmae,turn_sign_fraction=signfraction,max_reference_heading_error_deg=headingmax,speed_pass=speedmax<=.35,speed2s_max_m_s=speedmax,speed2s_mean_m_s=float(z['speed2s'][100:,j].mean()),gait_required=walk,gait_pass=bool(gaitpass),side_pass=sidepass,side_displacement_m=sidedistance,foot_landing_counts=counts.tolist(),left_step_median_m=steps['left_step_median_m'],right_step_median_m=steps['right_step_median_m'],joint_pass=bool(stable and headpass and turnpass and speedmax<=.35 and gaitpass and sidepass)))
 summary={}
 for name in scenarios:
  rs=[r for r in records if r['scenario']==name];summary[name]=dict(cases=B,**{key:sum(r[key] for r in rs) for key in ['stable','head_pass','turn_pass','speed_pass','gait_pass','side_pass','joint_pass']},**{key:float(np.median([r[key] for r in rs if r[key] is not None])) if any(r[key] is not None for r in rs) else None for key in ['left_step_median_m','right_step_median_m','side_displacement_m','speed2s_mean_m_s','yaw_rate_mae_rad_s','mean_body_forward_velocity_m_s','mean_body_yaw_rate_rad_s']})
 report=dict(status='ALL_MET' if all(r['joint_pass'] for r in records) else 'NEEDS_REVIEW',preflight=a.preflight,checkpoint=a.checkpoint,seconds=20,cases_per_scenario=B,heading_feedback=False,dr_multiplier=e._dr_multiplier,summary=summary)
 atomic_json(R/(a.prefix+'_results.json'),dict(**report,records=records));atomic_json(R/(a.prefix+'_summary.json'),report)
 if a.preflight:
  rs=[r for r in records if r['scenario']=='forward'];assert sum(r['stable'] for r in rs)>=B-1;assert max(r['max_tilt_deg'] for r in rs)<30
  assert summary['backward']['mean_body_forward_velocity_m_s']<-.015,summary['backward']
  assert summary['inplace_left']['mean_body_yaw_rate_rad_s']>.05,summary['inplace_left']
  assert summary['inplace_right']['mean_body_yaw_rate_rad_s']<-.05,summary['inplace_right']
  for name in ['backward','inplace_left','inplace_right']:assert summary[name]['stable']>=B-2,(name,summary[name])
  atomic_json(R/'LIVE_REGRESSION.json',dict(status='PASS',existing_forward_stability_checked=True,backward_and_both_turn_signs_restored=True,new_tasks_not_claimed_fully_learned=True,all_ten_command_paths_finite=True,source=a.prefix+'_summary.json'))
 print('MULTIMOTION_RESULTS',json.dumps(summary),flush=True)
finally:e.close()

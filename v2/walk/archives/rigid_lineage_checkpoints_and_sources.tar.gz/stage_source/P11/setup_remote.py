from pathlib import Path
import shutil,json,hashlib
from omegaconf import OmegaConf
R=Path(__file__).resolve().parent;S=R.parent/'headzero_turn_keep10_mirror200_20261104'
assert not (R/'project').exists()
shutil.copytree(S/'project',R/'project',symlinks=True,ignore=shutil.ignore_patterns('.venv','__pycache__','.git','outputs','logs'))
(R/'project/.venv').symlink_to((S/'project/.venv').resolve());(R/'physics').symlink_to((S/'physics').resolve())
for name in ['curriculum.py','common.py','metrics.py','collect_bank.py','speed_history.py','runtime.py','head_freeze.py','heading_adapter.py','direction_anchor.npz','train_rigid_bank.npz','heldout_rigid_bank.npz','NEW_STANDING_TARGET.json','xc_walking_v3_policy.py']:
 shutil.copy2(S/name,R/name)
shutil.copy2(S/'ppo_run/model_199.pt',R/'parent_walk400.pt');shutil.copy2(S/'balanced_keep10turn_200.onnx',R/'parent_walk400.onnx')
sha=hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest();assert sha=='6999becb8fffee86eab067af0d0dd6a4956c5b3710078dd56bdba25f70863511'
for name in ['TRAINING_CONFIG.yaml','COLLECT_CONFIG.yaml']:
 c=OmegaConf.load(S/name);c=OmegaConf.create(OmegaConf.to_yaml(c).replace(str(S),str(R)))
 if name=='TRAINING_CONFIG.yaml':
  c.env.task_mode='headturn';c.env.step_goal_m=.10;c.algo.max_iterations=400;c.algo.seed=1105101;c.env.newstand_seed=1105102;c.env.direction_seed=1105103
  c.algo.algorithm.learning_rate=3e-5;c.algo.algorithm.fixed_learning_rate=3e-5
 OmegaConf.save(c,R/name)
shutil.copy2(R/'balanced_env.py',R/'project/src/unilab/envs/locomotion/xduck_gf43x40/balanced_env.py')
io=json.loads((S/'IO_CONTRACT.json').read_text());io.update(version='multimotion-phase61-v4',parent_sha256=sha,phase_interval_formula='clip(.10/max(abs(vx),.05),.35,.65); inplace .5; side single 1.2s command then zero and settle',side_step_goal_m=.10,heading_feedback_required_for_acceptance=False)
(R/'IO_CONTRACT.json').write_text(json.dumps(io,indent=2))
(R/'DESIGN.json').write_text(json.dumps(dict(parent='new keep10/headzero 200',parent_sha256=sha,updates=400,num_envs=4096,rollout_steps=24,save_interval=50,evaluate_interval=200,dr_multiplier=2.5,rigid=True,head_zero=True,walking_goal_m=.10,speed_max_m_s=.35,speed_window_s=2,speed_lower=None,side_step_goal_m=.10,side_goal_assumption='user requested one step without distance; use10cm',scenarios=['forward','backward','forward_left','forward_right','backward_left','backward_right','inplace_left','inplace_right','side_left','side_right'],acceptance_without_external_heading_feedback=True,turn_reward_not_gated_by_forward_steps=True),indent=2))

"""Reward progress from rest, and require progress before awarding task credit."""
import numpy as np
GAMMA=.995
class FixedGoal:
 def __init__(self,goal):self.goal=goal
 stage=0
 def record(self,passed):pass
 def advance(self,update):return False
 def snapshot(self):return dict(mode='repaired_multimotion',target_step_m=self.goal,side_step_m=.10,turn_gait_required=False,forward_backward_gait_required=True)
def terms(valid,lengths,peak,foot_x,height,contact,target_x,target_h,swing,ramp,speed2s,yaw_rate,command,presence,lateral_net,goal,headturn,*,local_velocity,requested,heading_error,side,side_displacement,forward_displacement,segment_age,side_lands,side_tracking,extra_events,net_velocity,loss_update):
 walk=np.abs(requested[:,0])>.05;turn=(~walk)&(~side)&(np.abs(requested[:,2])>.05);turning=np.abs(requested[:,2])>.05
 warm=np.clip(loss_update/150,0,1);gait_weight=np.where(requested[:,0]<0,warm,1.)
 size=np.clip(lengths/goal,0,1)**2;hq=np.exp(-((np.maximum(.018-peak,0)+np.maximum(peak-.065,0))/.025)**2)
 short=np.maximum(.9*goal-lengths,0)/(.30*goal);costs=3*(np.sqrt(1+short**2)-1)+4*np.maximum(lengths-1.2*goal,0)/(.3*goal)
 landing=np.sum(valid*np.where(walk[:,None],4*size*hq-gait_weight[:,None]*costs,.5*hq*turn[:,None]),axis=1)
 coverage=np.clip(lengths,0,goal).mean(1)/goal;gap=np.abs(lengths[:,0]-lengths[:,1])/(.3*goal)
 pair_cost=1.5*(np.sqrt(1+gap**2)-1)*presence*walk*gait_weight
 tracking=np.exp(-((foot_x-target_x)/.05)**2-((height-target_h)/.025)**2).mean(1);contact_match=np.where(swing,~contact,contact).mean(1)
 reference_credit=(walk|turn)*ramp*(4*(tracking-.7)+1.5*(contact_match-.75))
 signed=np.sign(requested[:,0])*net_velocity[:,0];walk_progress=np.clip(signed/np.maximum(np.abs(requested[:,0]),.10),-1,1)
 turn_progress=np.clip(np.sign(requested[:,2])*yaw_rate/np.maximum(np.abs(requested[:,2]),.15),-1,1)
 locomotion_credit=walk*10*walk_progress+turning*8*turn_progress
 yawerror=yaw_rate-requested[:,2];yaw_cost=2*np.minimum((yawerror/.20)**2,9)+.3*np.minimum((heading_error/.4)**2,9)
 # Separate desired velocity tracking from the user's2s speed ceiling.
 velocity_cost=walk*6*np.minimum(((net_velocity[:,0]-requested[:,0])/.12)**2,9)
 lateral_cost=walk*4*np.minimum((lateral_net/.10)**2,9)+velocity_cost
 over=np.maximum(speed2s-.32,0);speed_cost=120*over+240*over**2
 inplace_cost=turn*4*(np.sqrt(1+(speed2s/.06)**2)-1)
 grace=np.clip((segment_age-1.5)/1.5,0,1)
 idle=grace*(walk*(3*(1-np.clip(walk_progress,0,1))+2*(1-presence))+turn*4*(1-np.clip(turn_progress,0,1)))
 settle=segment_age>=1.2;position_quality=np.exp(-((side_displacement-.10)/.035)**2-(forward_displacement/.04)**2)
 stopped=np.exp(-np.sum(local_velocity[:,:2]**2,axis=1)/.04**2);evidence=(side_lands.min(1)>=1)&(side_lands.max(1)<=2)
 side_credit=side*(5*side_tracking+8*position_quality*evidence+settle*6*position_quality*stopped*contact.all(1)*evidence)
 # Charge excess contacts ONCE, not for every subsequent timestep.
 side_cost=side*(2*np.minimum((forward_displacement/.05)**2,9)+settle*2*(1-stopped)+.5*extra_events/.02+grace*3*(1-evidence))
 progress=np.where(walk,np.clip(walk_progress,0,1),np.where(turn,np.clip(turn_progress,0,1),np.clip(side_lands.min(1),0,1)))
 posture_gate=np.maximum(1-grace,.15+.85*progress)
 return dict(landing=landing,inplace_cost=inplace_cost,pair_cost=pair_cost,reference_credit=reference_credit,speed_cost=speed_cost,yaw_cost=yaw_cost,lateral_cost=lateral_cost,idle=idle,reference_tracking=tracking,contact_match=contact_match,locomotion_credit=locomotion_credit,coverage=coverage,side_credit=side_credit,side_cost=side_cost,posture_gate=posture_gate)

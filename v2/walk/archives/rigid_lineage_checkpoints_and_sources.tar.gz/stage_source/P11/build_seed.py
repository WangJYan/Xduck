from pathlib import Path
import json,hashlib,numpy as np,torch
from model_io import NativeActor
from mirror_policy import raw_map,ACTION_PERM,ACTION_SIGN
from head_freeze import install_head_zero,assert_head_zero
from runtime import atomic_json
R=Path(__file__).resolve().parent;torch.set_num_threads(2);torch.manual_seed(1105281);rng=np.random.default_rng(1105282)
# Source policies and physical teacher rollouts are immutable provenance.
old=R/'source_keep10_200.pt'
if not old.exists():old.write_bytes((R/'parent_walk400.pt').read_bytes())
assert hashlib.sha256(old.read_bytes()).hexdigest()=='6999becb8fffee86eab067af0d0dd6a4956c5b3710078dd56bdba25f70863511'
assert hashlib.sha256((R/'original_flex50.pt').read_bytes()).hexdigest()=='e959c81f9a362bc6c3c0a4f2cc626716c41d54fafad2ff74debe900e65458ad9'
parts=[];counts={}
for filename,scenarios in [('teacher_forward_trace.npz',[(0,0),(2,0),(3,0)]),('teacher_original_trace.npz',[(1,1),(4,1),(5,1),(6,2),(7,2)])]:
 with np.load(R/filename) as z:
  obs=z['obs'];actions=z['raw_action'];q=z['qpos'];v=z['local_velocity'];w=z['yaw_rate'];cmd=z['requested'];B=8
  for scenario,pool in scenarios:
   ids=np.arange(scenario*B,(scenario+1)*B);tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,ids,4]**2+q[:,ids,5]**2),-1,1)))
   startup=np.arange(len(obs))[:,None]<100
   correct=v[:,ids,0]<-.01 if pool==1 else np.sign(cmd[:,ids,2])*w[:,ids]>.06
   if pool==0:correct=np.ones_like(tilt,bool)
   good=(tilt<15)&(q[:,ids,2]>.26)&(startup|correct)
   o=obs[:,ids][good];t=actions[:,ids][good];assert len(o)>100
   chosen=rng.choice(len(o),min(len(o),6000),replace=False);o=o[chosen];t=t[chosen]
   parts.append((o,t,np.full(len(o),pool)));counts[f'{filename}:{scenario}']=len(o)
o=np.concatenate([v[0] for v in parts]);t=np.concatenate([v[1] for v in parts]);labels=np.concatenate([v[2] for v in parts]);t[:,5:9]=0
student=NativeActor(old).to('cuda');student.train();install_head_zero(student,.15);student.obs_normalizer.eval();student.mlp.blend.fill_(1.)
# Explicitly reflect raw observations and action targets with the audited map.
p,s,b=raw_map(student.obs_normalizer._mean.reshape(-1)[[59,60]].cpu().numpy());o=np.r_[o,o[:,p]*s+b];t=np.r_[t,t[:,ACTION_PERM]*ACTION_SIGN];labels=np.r_[labels,labels]
mask=np.ones_like(t);mask[:,5:9]=0
np.savez_compressed(R/'motion_anchor.npz',obs=o,mean=t,mask=mask,phase=labels)
train=rng.random(len(o))>.1;ot=torch.tensor(o,device='cuda',dtype=torch.float32);tt=torch.tensor(t,device='cuda',dtype=torch.float32);leg=torch.tensor([0,1,2,3,4,9,10,11,12,13],device='cuda');pools=[np.flatnonzero(train&(labels==i)) for i in range(3)];hold=[np.flatnonzero((~train)&(labels==i)) for i in range(3)];optimizer=torch.optim.Adam(student.mlp.parameters(),lr=7e-5)
for step in range(1800):
 losses=[]
 for i,pool in enumerate(pools):
  idx=torch.tensor(rng.choice(pool,256),device='cuda');prediction=student(ot[idx]);losses.append(((prediction[:,leg]-tt[idx][:,leg])/.35).square().mean())
 loss=3*losses[0]+losses[1]+1.5*losses[2];optimizer.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(student.mlp.parameters(),2.);optimizer.step();assert_head_zero(student)
 if step%300==0:print('DISTILL',step,float(loss),flush=True)
with torch.inference_mode():rms=[float((student(ot[idx])[:,leg]-tt[idx][:,leg]).square().mean().sqrt()) for idx in hold]
assert rms[0]<.25 and max(rms)<.45,rms
ck=torch.load(old,map_location='cpu',weights_only=False);sd=ck['actor_state_dict'];new=student.state_dict()
for k in sd:
 if k.startswith('mlp.'):sd[k]=new[k].detach().cpu()
ck['actor_state_dict']=sd
# Optimizer state from the old run is never used by formal training.
ck['distillation_provenance']=dict(sources=['source_keep10_200.pt','original_flex50.pt'],steps=1800,teacher_cases_per_scenario=8,head_zero=True)
torch.save(ck,R/'parent_walk400.pt');seedsha=hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest()
atomic_json(R/'PARENT.json',dict(seed_sha256=seedsha,keep10_source_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),original_source_sha256=hashlib.sha256((R/'original_flex50.pt').read_bytes()).hexdigest(),failed_policy_used_as_parent=False))
atomic_json(R/'DISTILLATION.json',dict(status='PASS',seed_sha256=seedsha,holdout_leg_raw_rms_by_pool=rms,counts=counts,pools=['keep10_forward','original_backward','original_inplace_turn'],steps=1800,not_physical_acceptance=True))
print('SEED_READY',seedsha,rms,flush=True)

import torch
from head_freeze import install_head_zero,assert_head_zero
from mirror_policy import MirrorMLP
PHASE=[59,60]
def initialize(actor):
 f=actor.mlp[0];normal=actor.obs_normalizer
 with torch.no_grad():
  z0=-normal._mean.reshape(-1)[PHASE]/(normal._std.reshape(-1)[PHASE]+.01);f.bias.add_(f.weight[:,PHASE]@z0);f.weight[:,PHASE]=0
 install_head_zero(actor,.15);actor.mlp=MirrorMLP(actor.mlp,normal._mean,normal._std,0.)
def set_update(actor,update):actor.mlp.set_update(update,200)

from common import *
from scipy.optimize import least_squares
from task_adapter import reference
from runtime import atomic_json
m,qi,vi,names,local=metadata();bank=np.load(R/'train_rigid_bank.npz');q=bank['qpos'][0].copy();q[:2]=0;q[3:7]=[1,0,0,0];q[qi[5:9]]=0;d=mujoco.MjData(m);d.qpos[:]=q;mujoco.mj_forward(m,d);sites=np.array([m.site(s+'_foot').id for s in ['left','right']]);bids=[m.site_bodyid[i] for i in sites];normal=np.array([d.xmat[i].reshape(3,3).T@np.array([0.,0.,1.]) for i in bids]);base=d.site_xpos[sites].copy();center=base[:,0].mean();legs=np.array([0,1,2,3,4,9,10,11,12,13]);lo=m.jnt_range[m.actuator_trnid[legs,0],0]+1e-4;hi=m.jnt_range[m.actuator_trnid[legs,0],1]-1e-4;records=[]
goal=float(OmegaConf.load(R/'TRAINING_CONFIG.yaml').env.step_goal_m)
for t in np.linspace(2,3,25):
 x,h,_,_=reference(np.array([t]),np.array([t%1]),np.array([center]),goal);target=base.copy();target[:,0]=x[0];target[:,2]=.003+h[0];best=None
 for z in [.30,.31,.32]:
  def residual(a):
   d.qpos[:]=q;d.qpos[2]=z;d.qpos[qi[legs]]=a;mujoco.mj_forward(m,d);n=np.array([d.xmat[i].reshape(3,3)@v for i,v in zip(bids,normal)]);return np.r_[(d.site_xpos[sites]-target).ravel()/.01,n[:,:2].ravel()/.1]
  result=least_squares(residual,np.clip(q[qi[legs]],lo,hi),bounds=(lo,hi),max_nfev=250);residual(result.x);err=float(np.linalg.norm(d.site_xpos[sites]-target,axis=1).max());n=np.array([d.xmat[i].reshape(3,3)@v for i,v in zip(bids,normal)]);tilt=float(np.degrees(np.arccos(np.clip(n[:,2],-1,1))).max());item=dict(phase=float(t-2),root_height_m=z,foot_error_mm=1000*err,sole_tilt_deg=tilt,within_joint_limits=True,geometry_pass=err<.002 and tilt<2)
  if best is None or err<best['foot_error_mm']/1000:best=item
 records.append(best)
report=dict(status='PASS_GEOMETRY_ONLY' if all(r['geometry_pass'] for r in records) else 'GEOMETRY_NEEDS_REVIEW',phases=records,all_phases_reachable=all(r['geometry_pass'] for r in records),dynamic_teacher_validated=False,root_balance_trajectory_not_specified=True,reference_is_soft_training_guidance=True)
atomic_json(R/'GEOMETRY_CHECK.json',report);print(json.dumps(report,indent=2));assert report['all_phases_reachable']

"""mirror-phase61-v3 input adapter, required for these specialist policies.
obs59,60 encode sin/cos phase (old body-pose fields unsupported). Reset on Walk
entry; first adapt call dt=0, then actual control dt (~.02s). BODY yaw required.
"""
import numpy as np
from heading_adapter import HeadingAdapter
class TaskAdapter:
 def __init__(self,n,mean,scale,goal=.15,variable=False):
  self.age=np.zeros(n);self.phase=np.zeros(n);self.mean=np.asarray(mean);self.scale=np.asarray(scale);self.goal=goal;self.variable=variable;self.heading=HeadingAdapter(n)
 def reset(self,ids,yaw,offset=0.):
  ids=np.asarray(ids,int);self.age[ids]=0;self.phase[ids]=offset;self.heading.reset(ids,yaw)
 def encode(self):return self.mean+self.scale*np.c_[np.sin(2*np.pi*self.phase),np.cos(2*np.pi*self.phase)]
 def advance(self,yaw,requested,dt=.02,feedback=True):
  requested=np.asarray(requested);interval=np.where(requested[:,0]>.05,np.clip(self.goal/np.maximum(requested[:,0],.05),.35,.65),.5) if self.variable else .5
  self.age+=dt;self.phase=(self.phase+dt/(2*interval))%1
  effective,error=self.heading.step(yaw,requested[:,2],dt,feedback);return effective,error
 def adapt_observation(self,obs,body_yaw,requested,dt=.02,heading_hold=True):
  effective,error=self.advance(body_yaw,requested,dt,heading_hold);out=np.array(obs,copy=True);out[:,48:51]=requested;out[:,51:59]=0;out[:,50]=effective;out[:,59:61]=self.encode();return out

def reference(age,phase,center,length):
 phi=(np.asarray(phase)[:,None]+np.array([0.,.5]))%1;swing=phi>=.5;u=np.clip(2*phi-1,0,1);blend=u**3*(10+u*(-15+6*u));length=np.broadcast_to(np.asarray(length),(len(phi),))[:,None]
 x=np.where(swing,-length/2+2*length*blend-length*u,length/2-2*length*phi)
 ramp=np.clip(np.asarray(age)/2,0,1);ramp=ramp**3*(10+ramp*(-15+6*ramp));return center[:,None]+ramp[:,None]*x,ramp[:,None]*np.where(swing,.035*np.sin(np.pi*u)**2,0),swing,ramp

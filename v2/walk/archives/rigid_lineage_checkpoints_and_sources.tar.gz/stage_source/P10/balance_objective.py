import numpy as np
GAMMA=.995
class FixedGoal:
 def __init__(self,goal):self.goal=goal
 stage=0
 def record(self,passed):pass
 def advance(self,update):return False
 def snapshot(self):return dict(mode='balanced_phase',target_step_m=self.goal,randomized_start_foot=True,mirror_mean_at_final=True)

def terms(valid,lengths,peak,foot_x,height,contact,target_x,target_h,swing,ramp,speed2s,yaw_rate,command,presence,lateral_net,goal,headturn):
 moving=command[:,0]>.05;size=np.clip(lengths/goal,0,1)**2;hq=np.exp(-((np.maximum(.025-peak,0)+np.maximum(peak-.085,0))/.025)**2)
 short=np.maximum(.9*goal-lengths,0)/(.25*goal)
 short_cost=4*(np.sqrt(1+short**2)-1)
 overshoot=4*np.maximum(lengths-1.1*goal,0)/(.2*goal)
 credit=np.where(moving[:,None],6*size*hq-short_cost-overshoot,1.5*hq)
 landing=np.sum(valid*credit,axis=1)
 gap=np.abs(lengths[:,0]-lengths[:,1])/(.2*goal);pair_cost=2*(np.sqrt(1+gap**2)-1)*presence*ramp*moving
 xerr=np.where(moving[:,None],((foot_x-target_x)/.055)**2,0)
 tracking=np.exp(-xerr-((height-target_h)/.025)**2).mean(1);contact_match=np.where(swing,~contact,contact).mean(1);refcredit=ramp*(4*tracking+contact_match)
 over=np.maximum(speed2s-.32,0);speedcost=120*over+240*over**2
 yawerror=yaw_rate-command[:,2];yawcost=.6*(np.sqrt(1+(yawerror/.15)**2)-1)
 lateralexcess=np.maximum(abs(lateral_net)-.06,0);lateralcost=(10*lateralexcess+20*lateralexcess**2)*(np.abs(command[:,2])<.05)
 coverage=np.clip(lengths,0,goal).mean(1)/goal
 # Short walking may not collect full velocity/yaw reward in the200 branch.
 turnquality=np.exp(-(yawerror/.18)**2);velocity_quality=np.where(moving,np.exp(-((speed2s-command[:,0])/.15)**2),1/(1+(speed2s/.06)**2));gaitcoverage=np.where(moving,coverage**2,1.)
 locomotion=6*turnquality*velocity_quality*gaitcoverage*presence if headturn else np.zeros_like(speed2s)
 inplace_cost=4*(np.sqrt(1+(speed2s/.06)**2)-1)*(~moving)*ramp
 idle=4*(1-presence)*ramp
 return dict(landing=landing,inplace_cost=inplace_cost,pair_cost=pair_cost,reference_credit=refcredit,speed_cost=speedcost,yaw_cost=yawcost,lateral_cost=lateralcost,idle=idle,reference_tracking=tracking,contact_match=contact_match,locomotion_credit=locomotion,coverage=coverage)

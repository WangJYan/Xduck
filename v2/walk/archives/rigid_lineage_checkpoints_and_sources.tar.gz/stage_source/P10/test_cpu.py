from pathlib import Path
import json,ast,numpy as np,torch
from torch import nn
from mirror_policy import MirrorMLP,ACTION_PERM,ACTION_SIGN,raw_map
from task_adapter import TaskAdapter,reference
from balance_objective import terms
from policy_setup import initialize,set_update
from head_freeze import assert_head_zero
from curriculum import ExactCheckpointFilter
R=Path(__file__).resolve().parent
class Actor(nn.Module):
 def __init__(self):
  super().__init__();self.mlp=nn.Sequential(nn.Linear(61,32),nn.ELU(),nn.Linear(32,14));self.obs_normalizer=nn.Module();self.obs_normalizer.register_buffer('_mean',torch.randn(61)*.1);self.obs_normalizer.register_buffer('_std',torch.rand(61)+.05);self.distribution=nn.Module();self.distribution.std_param=nn.Parameter(torch.ones(14))
a=Actor();x=torch.randn(200,61);oldz=x.clone();oldz[:,59:61]=-a.obs_normalizer._mean[59:61]/(a.obs_normalizer._std[59:61]+.01);old=a.mlp(oldz).detach();initialize(a);new=a.mlp(oldz);leg=[0,1,2,3,4,9,10,11,12,13];torch.testing.assert_close(old[:,leg],new[:,leg],atol=2e-6,rtol=2e-6)
wrap=a.mlp;torch.testing.assert_close(wrap.mirror_input(wrap.mirror_input(x)),x,atol=2e-5,rtol=2e-5);set_update(a,200)
with torch.no_grad():torch.testing.assert_close(a.mlp(wrap.mirror_input(x)),wrap.mirror_action(a.mlp(x)),atol=2e-5,rtol=2e-5)
opt=torch.optim.Adam(a.parameters(),lr=.001)
for _ in range(3):opt.zero_grad();a.mlp(torch.randn(100,61)).square().mean().backward();opt.step();assert_head_zero(a)
p=TaskAdapter(4,[.01,-.02],[.04,.05],.10,True);p.reset(np.arange(4),np.zeros(4),np.array([0,.5,0,.5]));enc=(p.encode()-p.mean)/p.scale;np.testing.assert_allclose(enc[0],-enc[1],atol=1e-10);before=p.phase.copy();p.advance(np.zeros(4),np.tile([.24,0,0],(4,1)));assert np.allclose((p.phase-before)%1,.02/(2*(.1/.24)))
# Startup ramp is unchanged by mirror: swap phase byhalf a cycle, not age.
ages=np.array([.2,1.,3.]);phase=np.array([.1,.3,.7]);x,h,_,r=reference(ages,phase,np.zeros(3),.15);xx,hh,_,rr=reference(ages,(phase+.5)%1,np.zeros(3),.15);np.testing.assert_allclose(x,xx[:,::-1],atol=1e-10);np.testing.assert_allclose(h,hh[:,::-1],atol=1e-10);np.testing.assert_equal(r,rr)
def reward(length,other,goal=.1,headturn=True):
 return terms(np.array([[1,0]],bool),np.array([[length,other]]),np.full((1,2),.04),np.zeros((1,2)),np.zeros((1,2)),np.ones((1,2),bool),np.zeros((1,2)),np.zeros((1,2)),np.array([[0,1]],bool),np.ones(1),np.array([.24]),np.zeros(1),np.array([[.24,0,0]]),np.ones(1),np.zeros(1),goal,headturn)
assert reward(.10,.10)['landing'][0]>reward(.05,.10)['landing'][0]
assert reward(.05,.05)['locomotion_credit'][0]<reward(.10,.10)['locomotion_credit'][0]/2
assert reward(.05,.10)['pair_cost'][0]>reward(.10,.10)['pair_cost'][0]
assert reward(.10,.03)['landing'][0]==reward(.10,.10)['landing'][0]
for path in R.glob('*.py'):ast.parse(path.read_text())
assert (R/'balanced_env.py').read_bytes()==(R/'project/src/unilab/envs/locomotion/xduck_gf43x40/balanced_env.py').read_bytes()
report=dict(status='PASS',mirror_involution=True,mirror_mean_equivariance_at_final=True,initial_body_mean_preserved_at_blend0=True,head_zero_through_optimizer=True,random_phase_swap_does_not_change_startup_ramp=True,below_target_steps_penalized=True,unequal_pair_penalized=True,short_steps_cannot_collect_full_locomotion_reward=True,individual_improvement_not_blocked_by_other_foot=True)
(R/'CPU_TESTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

from pathlib import Path
import os,subprocess,time,json,fcntl,traceback
from omegaconf import OmegaConf
from runtime import atomic_json
R=Path(__file__).resolve().parent;lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);P=['/home/xingchen/.local/bin/uv','run','--python',str(R/'project/.venv/bin/python'),'--no-project'];TOTAL=int(OmegaConf.load(R/'TRAINING_CONFIG.yaml').algo.max_iterations);TURN=TOTAL==200
def status(s,**kw):atomic_json(R/'RUN_STATUS.json',dict(status=s,controller_pid=os.getpid(),updated_unix=time.time(),requested_updates=TOTAL,**kw));print(s,kw,flush=True)
def free():return int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).splitlines()[0])
def wait_gpu():
 while free()<14336:status('WAITING_FOR_GPU',free_mib=free());time.sleep(20)
def run(script,args=(),log=None):
 with (R/(log or script.replace('.py','.log'))).open('a') as f:subprocess.run(P+[str(R/script),*map(str,args)],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
def evaluate(n,final=False):
 status('EVALUATING',checkpoint_updates=n,training_continues=not final);run('evaluate.py',['--checkpoint',f'ppo_run/model_{n-1}.pt','--prefix',f'probe_{n}'])
 if not TURN:run('report_phase.py',['--updates',n])
 run('export.py',['--updates',n])
 if final:
  run('collect_bank.py',['--prefix','fresh_final_bank','--seed',1104991 if TURN else 1104891,'--n',32]);run('evaluate.py',['--checkpoint',f'ppo_run/model_{n-1}.pt','--prefix','final32','--bank','fresh_final_bank.npz','--n',32],'final32.log')
  if not TURN:run('report_phase.py',['--updates',n,'--prefix','final32'])
try:
 status('CPU_AUDIT');run('test_cpu.py');run('geometry_check.py');run('audit.py');wait_gpu();status('SMOKE_SMALL');run('train.py',['--smoke','--smoke-envs',16],'smoke_small.log')
 wait_gpu();status('INITIAL_CLOSED_LOOP_CHECK');run('evaluate.py',['--preflight','--prefix','preflight'],'preflight.log');wait_gpu();status('SMOKE_4096');run('train.py',['--smoke','--smoke-envs',4096],'smoke_4096.log');run('audit.py',['--final']);wait_gpu();status('TRAINING_RUNNING')
 with (R/'train.log').open('a') as f:
  child=subprocess.Popen(P+[str(R/'train.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT);checked200=False
  while child.poll() is None:
   if TOTAL==400 and not checked200 and (R/'CHECKPOINT_200.json').exists() and free()>=10000:evaluate(200);checked200=True;status('TRAINING_RUNNING',checkpoint200_evaluated=True)
   time.sleep(15)
  assert child.returncode==0,child.returncode
 if TOTAL==400 and not checked200:wait_gpu();evaluate(200)
 wait_gpu();evaluate(TOTAL,True)
 report=json.loads((R/'final32_summary.json').read_text())
 if TURN:
  rs=report['summary']['candidate']['True'];straight=rs['straight'];accepted=all(v['joint_pass']==v['cases'] for v in rs.values());gait_ok=straight['gait_pass']==straight['cases']
  outcome='ALL_MET' if accepted else 'GAIT_NOT_RETAINED' if not gait_ok else 'NEEDS_REVIEW'
 else:outcome=report['status']
 atomic_json(R/'ACCEPTANCE.json',dict(status=outcome,final_report='final32_summary.json',straight_step_min_m=.09 if TURN else .135))
 import zipfile
 export=json.loads((R/f'EXPORT_{TOTAL}.json').read_text());bundle=R/(Path(export['onnx']).stem+'_bundle.zip')
 with zipfile.ZipFile(bundle,'a',zipfile.ZIP_DEFLATED) as z:
  for file in [R/'ACCEPTANCE.json',R/'final32_summary.json']:z.write(file,file.name)
 status('COMPLETE',completed_updates=TOTAL,final_report='final32_summary.json',result=outcome)
except BaseException as ex:status('FAILED',error=repr(ex),traceback=traceback.format_exc());raise

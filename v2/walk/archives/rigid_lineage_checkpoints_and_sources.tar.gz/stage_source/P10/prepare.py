from pathlib import Path
import shutil,json,hashlib,ast
from omegaconf import OmegaConf
R=Path(__file__).resolve().parent;S=R.parent/'step15_phase_independent400_20261104';is_turn='keep10' in R.name;assert not (R/'project').exists()
shutil.copytree(S/'project',R/'project',symlinks=True,ignore=shutil.ignore_patterns('.venv','__pycache__','.git','outputs','logs'));(R/'project/.venv').symlink_to((S/'project/.venv').resolve());(R/'physics').symlink_to((S/'physics').resolve())
for n in ['parent_walk400.pt','parent_walk400.onnx','direction_anchor.npz','train_rigid_bank.npz','heldout_rigid_bank.npz','NEW_STANDING_TARGET.json','xc_walking_v3_policy.py','common.py','metrics.py','collect_bank.py','speed_history.py','curriculum.py','runtime.py','head_freeze.py','heading_adapter.py']:
 shutil.copy2(S/n,R/n)
assert hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest()=='e0dccfa8f7b1cd3f17f5e56ec78a3a3764f2fdc448681f672a1567acecc182b5'
s=(S/'phase_step15.py').read_text().replace('PhaseStep15','BalancedPhase').replace('XDuckBalancedPhase_400','XDuckBalancedPhase')
s=s.replace('from phase_objective import FixedGoal,terms as phase_terms,GAMMA','from balance_objective import FixedGoal,terms as phase_terms,GAMMA').replace('from phase_adapter import PhaseAdapter,reference','from task_adapter import TaskAdapter,reference')
s=s.replace('class BalancedPhaseCfg(NewStandSmoothCfg):','class BalancedPhaseCfg(NewStandSmoothCfg):\n    task_mode: str="stride"\n    step_goal_m: float=.15')
s=s.replace('self._phase=PhaseAdapter(num_envs,cfg.phase_mean,cfg.phase_scale)','self._phase=TaskAdapter(num_envs,cfg.phase_mean,cfg.phase_scale,cfg.step_goal_m,cfg.task_mode=="headturn")\n        self._phase_rng=np.random.default_rng(cfg.direction_seed+777)').replace('self.curriculum = FixedGoal()','self.curriculum = FixedGoal(cfg.step_goal_m)')
a=s.index('    def _set_direction(');b=s.index('    def _reset_episode_history',a)
s=s[:a]+'''    def _set_direction(self,ids,initial=False):
        ids=np.asarray(ids,int);n=len(ids);self._dir_commands[ids]=0
        if self.cfg.task_mode=='headturn':
            kind=self._dir_rng.choice(5,size=n,p=[.4,.2,.2,.1,.1]);v=self._dir_rng.uniform(.20,.28,n);w=self._dir_rng.uniform(.25,.45,n)
            self._requested[ids,0]=np.where(kind>=3,0,v);self._requested[ids,1]=0;self._requested[ids,2]=np.where((kind==1)|(kind==3),w,np.where((kind==2)|(kind==4),-w,0));self._feedback[ids]=self._dir_rng.random(n)<.5
            self._next_switch[ids]=(0. if initial else self._smooth_age[ids]*self.cfg.ctrl_dt)+self._dir_rng.uniform(4,8,n)
        else:self._requested[ids]=[.3,0,0];self._feedback[ids]=True;self._next_switch[ids]=1e12
        self._dir_commands[ids,:3]=self._requested[ids]
        if initial:self._dir_age[ids]=0

    def _maybe_resample_commands(self,state):
        ids=np.flatnonzero(self._smooth_age*self.cfg.ctrl_dt>=self._next_switch)
        if len(ids):self._set_direction(ids)
        q=self._backend.get_base_quat();w,x,y,z=q.T;yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))
        effective,error=self._phase.advance(yaw,self._requested,self.cfg.ctrl_dt,self._feedback);self._reference_error[:]=error
        self._dir_commands[:]=0;self._dir_commands[:,:3]=self._requested;self._dir_commands[:,2]=effective;self._dir_commands[:,11:13]=self._phase.encode();state.info['commands'][:]=self._dir_commands

''' + s[b:]
s=s.replace('reference(self._phase.age,self._phase_center)','reference(self._phase.age,self._phase.phase,self._phase_center,self.cfg.step_goal_m if self.cfg.task_mode=="stride" else np.where(self._requested[:,0]>.05,self.cfg.step_goal_m,0.))')
s=s.replace('speed2s,yaw_rate_filtered,cmd[:,2],presence,lateral_net)','speed2s,yaw_rate_filtered,cmd,presence,lateral_net,self.cfg.step_goal_m,self.cfg.task_mode=="headturn")')
s=s.replace("terms['reference_credit']-terms['speed_cost']", "terms['reference_credit']+terms['locomotion_credit']-terms['pair_cost']-terms['inplace_cost']-terms['speed_cost']")
s=s.replace('speed2s=speed2s.copy(),head_q=', 'requested=self._requested.copy(),effective=cmd.copy(),local_velocity=linvel.copy(),yaw_rate_filtered=yaw_rate_filtered.copy(),head_qd=self.get_dof_vel()[:,5:9].copy(),speed2s=speed2s.copy(),head_q=')
s=s.replace("'gait/left_cached_step_m':", "'task/pair_gap_cost_per_s':float(terms['pair_cost'].mean()),'task/coverage':float(terms['coverage'].mean()),'gait/left_cached_step_m':")
s=s.replace('env._phase.reset(ids,env._dir_heading0[ids])','env._phase.reset(ids,env._dir_heading0[ids],env._phase_rng.integers(0,2,len(ids))*.5)')
ast.parse(s);(R/'balanced_env.py').write_text(s);(R/'project/src/unilab/envs/locomotion/xduck_gf43x40/balanced_env.py').write_text(s)
for n in ['TRAINING_CONFIG.yaml','COLLECT_CONFIG.yaml']:
 c=OmegaConf.load(S/n);c=OmegaConf.create(OmegaConf.to_yaml(c).replace(str(S),str(R)).replace('XDuckPhaseStep15_400','XDuckBalancedPhase'))
 if n=='TRAINING_CONFIG.yaml':
  c.env.task_mode='headturn' if is_turn else 'stride';c.env.step_goal_m=.10 if is_turn else .15;c.algo.max_iterations=200 if is_turn else 400;c.algo.seed=1104901 if is_turn else 1104801;c.env.newstand_seed=c.algo.seed+1;c.env.direction_seed=c.algo.seed+2
 OmegaConf.save(c,R/n)
io=json.loads((S/'IO_CONTRACT.json').read_text());io.update(version='mirror-phase61-v3',step_goal_m=.10 if is_turn else .15,variable_phase_interval=is_turn,mirror_blend_ramp_updates=200,adapter='task_adapter.py',phase_reset_offset='0 or0.5; raw observation mirror shifts phase bypi',head_fixed_zero=True)
(R/'IO_CONTRACT.json').write_text(json.dumps(io,indent=2));(R/'DESIGN.json').write_text(json.dumps(dict(parent='video400 e0dccfa8',updates=200 if is_turn else 400,goal_m=.10 if is_turn else .15,mode='headturn_keep10' if is_turn else 'stride15',dr_multiplier=2.5,num_envs=4096,rollout_steps=24,save_interval=50,phase_start_randomized=True,short_side_penalty=True,pair_gap_penalty=True,mirror_equivariance_final=True,mirror_ramp_updates=200,straight_stride_acceptance_min_m=.09 if is_turn else .135),indent=2))

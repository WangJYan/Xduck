from common import *
from unilab.envs.locomotion.xduck_gf43x40.balanced_env import BalancedPhaseEnv
from metrics import alternating_step_statistics
from heading_adapter import wrap
from runtime import atomic_json
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--checkpoint',default='parent_walk400.pt');ap.add_argument('--prefix',default='preflight');ap.add_argument('--bank',default='heldout_rigid_bank.npz');ap.add_argument('--n',type=int,default=8);ap.add_argument('--preflight',action='store_true');a=ap.parse_args();B=a.n;scenarios=['straight','forward_left','forward_right','inplace_left','inplace_right','switch'];K=len(scenarios);groups=2*2*K;N=groups*B;seconds=20;torch.set_num_threads(2)
from model_io import NativeActor
actors=[NativeActor(R/'parent_walk400.pt').eval(),NativeActor(R/a.checkpoint,adapt=a.preflight).eval()]
assert not actors[1].mlp[-1].weight[5:9].any() and not actors[1].mlp[-1].bias[5:9].any()
c=OmegaConf.load(R/'TRAINING_CONFIG.yaml');c.env.newstand_bank_path=str(R/a.bank);E.ensure_registries();e=E.create_env(c,num_envs=N,env_cfg_override=E.build_ppo_env_cfg_override(c));m,qi,vi,names,local=metadata()
class Rows:
 def __init__(self):self.rng=np.random.default_rng(1104699)
 def integers(self,high,size):assert size==N;return np.tile(np.arange(B),groups)
 def uniform(self,*a,**kw):return self.rng.uniform(*a,**kw)
 def random(self,*a,**kw):return self.rng.random(*a,**kw)
e._newstand_rng=Rows();rng=np.random.default_rng(1104698);drng=np.random.default_rng(1104697)
def noise(data,scale):
 z=rng.uniform(-1,1,(B,data.shape[1])).astype(data.dtype);return data+np.tile(z,(groups,1))*float(e.cfg.noise_config.level)*scale
def delay(ids=None):
 lo,hi=e._imu_delay_bounds;x=drng.integers(lo,hi+1,B)
 if ids is None:e._imu_delay_lag[:]=np.tile(x,groups)
 else:e._imu_delay_lag[ids]=x[np.asarray(ids)%B]
e._obs_noise=noise;e._sample_imu_delay=delay
feedback=np.array([bool((j//K)%2) for j in range(groups) for _ in range(B)])
def desired(t):
 commands=[]
 for j in range(groups):
  case=scenarios[j%K];vx=.24;w=0.
  if case in ['forward_left','inplace_left']:w=.35
  if case in ['forward_right','inplace_right']:w=-.35
  if case.startswith('inplace'):vx=0.
  if case=='switch':w=.35 if 4<=t<8 else -.35 if 12<=t<16 else 0.
  commands.extend([[vx,0,w]]*B)
 return np.array(commands)
def fixed(ids,initial=False):
 ids=np.asarray(ids,int);e._requested[ids]=desired(0)[ids];e._dir_commands[ids]=0;e._dir_commands[ids,:3]=e._requested[ids];e._feedback[ids]=feedback[ids];e._next_switch[ids]=1e9
e._set_direction=fixed
original_phase_reset=e._phase.reset
def paired_phase_reset(ids,yaw,offset=0):return original_phase_reset(ids,yaw,(np.asarray(ids)%B%2)*.5)
e._phase.reset=paired_phase_reset
bodyids=np.array([e._backend.get_body_id(n) for n in names],np.int32);trace=[];head_output_max=0.
try:
 e.init_state();e.set_autoreset(False);initial,_=state(e,m)
 for tick in range(1000):
  e._requested[:]=desired(tick*.02);q=e._backend.get_base_quat();w,x,y,z=q.T;yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z));effective=e._requested.copy();effective[:,2]=np.clip(effective[:,2]-.8*feedback*wrap(yaw-e._phase.heading.reference),-.6,.6)
  obs=e.state.obs['obs'].copy();obs[:,48:51]=effective;obs[:N//2,59:61]=0
  with torch.inference_mode():raw=np.concatenate([actor(torch.tensor(v,dtype=torch.float32)).numpy() for actor,v in zip(actors,np.split(obs,2))])
  head_output_max=max(head_output_max,float(abs(raw[N//2:,5:9]).max()));assert np.isfinite(raw).all()
  s=e.step(raw);cap=e._audit_task;q,v=state(e,m);assert np.isfinite(q).all() and np.isfinite(s.reward).all()
  pos,quat=e._backend.get_body_pose_w(bodyids);foot_world=pos+rotate(quat,np.broadcast_to(local,pos.shape))
  trace.append(dict(feet_world=foot_world,qpos=q,head_q=cap['head_q'],head_qd=cap['head_qd'],yaw_rate=cap['yaw_rate'],yaw_rate_filtered=cap['yaw_rate_filtered'],requested=cap['requested'],effective=cap['effective'],heading_error=cap['heading_error'],speed2s=cap['speed2s'],local_velocity=cap['local_velocity'],foot_velocity=e._foot_vel.copy(),contact=e._contact.copy(),clearance=e._foot_height.copy()))
  if (tick+1)%200==0:print('HEAD_TURN_EVAL',tick+1,flush=True)
 z={k:np.asarray([r[k] for r in trace]) for k in trace[0]};bank=np.load(R/a.bank);ids=np.tile(np.arange(B),groups);np.savez_compressed(R/(a.prefix+'_trace.npz'),**z,initial=initial,**{k:bank[k][ids] for k in FIELDS});records=[]
 for j in range(N):
  q=z['qpos'][:,j];tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,4]**2+q[:,5]**2),-1,1)));group=j//B;scenario=scenarios[group%K];stable=bool(tilt.max()<20 and q[:,2].min()>.25);start=100
  head_p95=np.percentile(np.degrees(abs(z['head_q'][start:,j])),95,axis=0);head_rms=np.sqrt(np.mean(np.degrees(z['head_q'][start:,j])**2,axis=0));head_velocity_rms=np.sqrt(np.mean(np.degrees(z['head_qd'][start:,j])**2,axis=0));head_pass=bool(head_p95.max()<=5)
  requested=z['requested'][start:,j,2];actual=z['yaw_rate_filtered'][start:,j];error=abs(actual-requested);headingmax=float(np.degrees(abs(z['heading_error'][start:,j])).max());speedmax=float(z['speed2s'][start:,j].max());speedmean=float(z['speed2s'][start:,j].mean());moving=abs(requested)>.1;signfraction=float(np.mean(np.sign(actual[moving])==np.sign(requested[moving]))) if moving.any() else None
  delta=q[-1,:2]-initial[j,:2];q0=initial[j,3:7];h0=np.arctan2(2*(q0[0]*q0[3]+q0[1]*q0[2]),1-2*(q0[2]**2+q0[3]**2));f=np.array([np.cos(h0),np.sin(h0)]);l=np.array([-f[1],f[0]]);pathangle=float(np.degrees(np.arctan2(abs(delta@l),delta@f)));drift=float(np.linalg.norm(delta))
  turnpass=bool(error.mean()<.15 and headingmax<20 and (signfraction is None or signfraction>=.8))
  if scenario=='straight':turnpass=turnpass and pathangle<20 and delta@f>.2
  if scenario.startswith('inplace'):turnpass=turnpass and drift<.5
  air=np.zeros(2,bool);peak=np.zeros(2);events=[]
  for ti,h in enumerate(z['clearance'][:,j]):
   peak=np.maximum(peak,h);leaving=(~air)&(h>.0015);landing=air&z['contact'][ti,j]&(h<.003)
   for side in np.flatnonzero(landing):
    if peak[side]>=.008 and (ti+1)*.02>=4:
     pose=q[ti];w,x,y,zz=pose[3:7];bodyyaw=np.arctan2(2*(w*zz+x*y),1-2*(y*y+zz*zz));events.append(dict(time=(ti+1)*.02,side=int(side),point=z['feet_world'][ti,j,side],peak=float(peak[side]),yaw=float(bodyyaw)))
   peak[landing]=0;air=(air|leaving)&(~landing)
  steps=alternating_step_statistics(events,np.array([1,0,0]),body_frame=True)
  gait_required=not scenario.startswith('inplace')
  lower=.09 if scenario=='straight' else .08
  gait_pass=(not gait_required) or (steps['left_step_median_m'] is not None and steps['right_step_median_m'] is not None and lower<=steps['left_step_median_m']<=.12 and lower<=steps['right_step_median_m']<=.12 and steps['alternating_fraction']>=.9)
  records.append(dict(model='parent_walk400' if j<N//2 else 'candidate',scenario=scenario,feedback=bool(feedback[j]),case=j%B,trace_index=j,stable=stable,head_p95_abs_deg=head_p95.tolist(),head_rms_deg=head_rms.tolist(),head_velocity_rms_deg_s=head_velocity_rms.tolist(),head_pass=head_pass,yaw_rate_mae_rad_s=float(error.mean()),instant_yaw_rate_mae_diagnostic_rad_s=float(abs(z['yaw_rate'][start:,j]-requested).mean()),turn_sign_fraction=signfraction,max_reference_heading_error_deg=headingmax,net_path_angle_deg=pathangle,net_displacement_m=drift,speed2s_mean_m_s=speedmean,speed2s_max_m_s=speedmax,speed_pass=speedmax<=.35,turn_pass=bool(turnpass),gait_required=gait_required,gait_pass=bool(gait_pass),left_step_median_m=steps['left_step_median_m'],right_step_median_m=steps['right_step_median_m'],joint_pass=bool(stable and head_pass and turnpass and gait_pass and speedmax<=.35),max_tilt_deg=float(tilt.max())))
 summary={}
 for name in ['parent_walk400','candidate']:
  summary[name]={}
  for fb in [False,True]:
   summary[name][str(fb)]={}
   for scenario in scenarios:
    rs=[r for r in records if r['model']==name and r['feedback']==fb and r['scenario']==scenario]
    summary[name][str(fb)][scenario]=dict(gait_pass=sum(r['gait_pass'] for r in rs) if not scenario.startswith('inplace') else None,left_step_median_m=float(np.median([r['left_step_median_m'] for r in rs if r['left_step_median_m'] is not None])) if any(r['left_step_median_m'] is not None for r in rs) else None,right_step_median_m=float(np.median([r['right_step_median_m'] for r in rs if r['right_step_median_m'] is not None])) if any(r['right_step_median_m'] is not None for r in rs) else None,cases=len(rs),stable=sum(r['stable'] for r in rs),head_pass=sum(r['head_pass'] for r in rs),turn_pass=sum(r['turn_pass'] for r in rs),speed_pass=sum(r['speed_pass'] for r in rs),joint_pass=sum(r['joint_pass'] for r in rs),median_head_p95_max_deg=float(np.median([max(r['head_p95_abs_deg']) for r in rs])),median_yaw_rate_mae_rad_s=float(np.median([r['yaw_rate_mae_rad_s'] for r in rs])),median_heading_error_max_deg=float(np.median([r['max_reference_heading_error_deg'] for r in rs])))
 assert head_output_max==0
 report=dict(status='EVALUATED',preflight=a.preflight,checkpoint=a.checkpoint,seconds=seconds,cases_per_scenario=B,head_output_max_abs_raw=head_output_max,dr_multiplier=e._dr_multiplier,head_joint_order=['neck_pitch','head_pitch','head_yaw','head_roll'],feedback_modes=[False,True],summary=summary,records=records)
 atomic_json(R/(a.prefix+'_results.json'),report);atomic_json(R/(a.prefix+'_summary.json'),{k:v for k,v in report.items() if k!='records'})
 if a.preflight:
  rs=[r for r in records if r['model']=='candidate' and r['scenario']=='straight'];assert all(r['stable'] for r in rs);assert np.median([max(r['head_p95_abs_deg']) for r in rs])<5
  atomic_json(R/'LIVE_REGRESSION.json',dict(status='PASS',head_zero_outputs_exact=True,straight_stability_preserved=True,commanded_left_right_and_inplace_executed=True,feedback_and_raw_modes_tested=True,source_report=a.prefix+'_results.json',dr_multiplier=e._dr_multiplier))
 print('HEAD_TURN_RESULTS',json.dumps(summary),flush=True)
finally:e.close()

"""Fix physical head targets at zero without changing native actor I/O."""
import torch
HEAD=slice(5,9)
def install_head_zero(actor,body_std=.15):
 layer=actor.mlp[-1];assert isinstance(layer,torch.nn.Linear) and layer.out_features==14
 with torch.no_grad():
  layer.weight[HEAD].zero_();layer.bias[HEAD].zero_();actor.distribution.std_param.fill_(body_std);actor.distribution.std_param[HEAD].fill_(1e-4)
 actor.distribution.std_param.requires_grad_(False)
 def weight_hook(g):g=g.clone();g[HEAD]=0;return g
 layer.weight.register_hook(weight_hook);layer.bias.register_hook(weight_hook)
 return layer

def assert_head_zero(actor):
 layer=actor.mlp[-1];assert torch.count_nonzero(layer.weight[HEAD])==0 and torch.count_nonzero(layer.bias[HEAD])==0

from pathlib import Path
import os,json,hashlib,subprocess,argparse,math
os.environ.setdefault('MUJOCO_GL','egl')
import numpy as np,mujoco,imageio_ffmpeg
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--kind',choices=['stride','turn'],required=True);a=ap.parse_args();prefix='final32';source=R/(prefix+'_trace.npz');rs=json.loads((R/(prefix+'_results.json')).read_text())['records'];entries=[]
if a.kind=='stride':
 W,H=640,360;cols,rows=2,1;out='stride400_comparison_1x'
 for model,label in [('parent_walk400','Parent400 + heading hold'),('candidate','Phase step15 / 400 updates + heading hold')]:
  r=next(r for r in rs if r['model']==model and r['case']==0 and r['scenario']=='forward');entries.append(dict(index=r['trace_index'],label=label,feedback=True,scenario='straight'))
else:
 W,H=480,300;cols,rows=2,2;out='headturn200_inplace_comparison_1x'
 for fb in [False,True]:
  for scenario,label in [('inplace_left','IN-PLACE LEFT'),('inplace_right','IN-PLACE RIGHT')]:
   r=next(r for r in rs if r['model']=='candidate' and r['case']==0 and r['scenario']==scenario and r['feedback']==fb);entries.append(dict(index=r['trace_index'],label=f'{label} | heading hold {"ON" if fb else "OFF"}',feedback=fb,scenario=scenario))
ids=[e['index'] for e in entries];z=np.load(source)
# Decompress each array ONCE; rendering does not run a different simulation.
qtrace=z['qpos'][:,ids].copy();initial=z['initial'][ids].copy();gp=z['geom_pos'][ids].copy();gq=z['geom_quat'][ids].copy();heading_errors=z['heading_error'][:,ids].copy() if a.kind=='turn' else None;z.close()
m=mujoco.MjModel.from_binary_path(str(R/'physics/effective_training.mjb'));d=mujoco.MjData(m);ji=m.actuator_trnid[:,0];qi=m.jnt_qposadr[ji];m.vis.global_.offwidth=W;m.vis.global_.offheight=H;m.mat_rgba[:,3]=1;m.geom_rgba[:,3]=1;m.geom_group[:]=0
renderer=mujoco.Renderer(m,height=H,width=W);opt=mujoco.MjvOption();cam=mujoco.MjvCamera();fps=20;seconds=20

def pose(j,t):
 u=max(0,min(t/.02,len(qtrace)));i=min(int(u),len(qtrace));f=u-int(u);p0=initial[j] if i==0 else qtrace[i-1,j];p1=qtrace[min(i,len(qtrace)-1),j];q=(1-f)*p0+f*p1;q[3:7]/=np.linalg.norm(q[3:7]);return q

def yaw(q):
 w,x,y,z=q[3:7];return math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))

def panel(j,t):
 q=pose(j,t);d.qpos[:]=q;m.geom_pos[:]=gp[j];m.geom_quat[:]=gq[j];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d);h0=yaw(initial[j]);cam.azimuth=math.degrees(h0)+90;cam.elevation=-10;cam.distance=1.35 if a.kind=='stride' else 1.25;cam.lookat[:]=q[:3];cam.lookat[2]=.31
 renderer.update_scene(d,camera=cam,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,W,61),fill=(15,25,36));draw.text((8,5),entries[j]['label'],fill='white');draw.text((8,22),f't={t:.2f}s | 1x | fixed case0 | actual closed-loop trace',fill='white')
 head=float(np.degrees(abs(q[qi[5:9]])).max());text=f'head max abs={head:.2f} deg'
 if t>=2:
  speed=np.linalg.norm(q[:2]-pose(j,t-2)[:2])/2;text+=f' | 2s speed={speed:.3f} m/s'
 draw.text((8,40),text,fill='white')
 i=min(max(round(t/.02)-1,0),len(qtrace)-1);body=yaw(q)-h0;target=body-float(heading_errors[i,j]) if heading_errors is not None else 0.;cx,cy=W-51,H-51;radius=29;draw.ellipse((cx-radius,cy-radius,cx+radius,cy+radius),outline=(190,190,190),width=1)
 for theta,color in [(target,(80,240,110)),(body,(70,190,255))]:
  ex=cx+radius*math.sin(theta);ey=cy-radius*math.cos(theta);draw.line((cx,cy,ex,ey),fill=color,width=3)
 draw.text((W-128,H-15),'green=target blue=body',fill='white');return im
ff=subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-v','error','-f','rawvideo','-s',f'{W*cols}x{H*rows}','-pix_fmt','rgb24','-r',str(fps),'-i','-','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p',str(R/(out+'.mp4'))],stdin=subprocess.PIPE)
try:
 for frame in range(round(seconds*fps)):
  im=Image.new('RGB',(W*cols,H*rows))
  for j in range(len(entries)):im.paste(panel(j,frame/fps),((j%cols)*W,(j//cols)*H))
  if frame==fps*3:im.save(R/(out+'_preview.png'))
  ff.stdin.write(np.asarray(im).tobytes())
finally:ff.stdin.close();assert ff.wait()==0;renderer.close()
report=dict(source_trace=source.name,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),panels=entries,selection='case0 fixed before visual inspection; no failure trimming',seconds=seconds,fps=fps,speed=1,not_a_new_simulation=True)
(R/(out+'_binding.json')).write_text(json.dumps(report,indent=2));print('VIDEO_READY',out,flush=True)

"""Command adapter: yaw reference integrates USER yaw rate, not feedback rate.
All angles/rates in rad/rad/s. Call once per control step; reset at Walk entry.
The ONNX still takes61 native observations; put effective yaw rate in obs[50].
Use estimated BODY yaw (IMU/odometry), never the head-yaw joint angle.
"""
import numpy as np

def wrap(x):return np.arctan2(np.sin(x),np.cos(x))
class HeadingAdapter:
 def __init__(self,n,kp=.8,rate_limit=.6):
  self.reference=np.zeros(n);self.kp=kp;self.rate_limit=rate_limit
 def reset(self,ids,body_yaw):self.reference[np.asarray(ids,dtype=int)]=body_yaw
 def step(self,body_yaw,user_yaw_rate,dt=.02,enabled=True):
  self.reference=wrap(self.reference+np.asarray(user_yaw_rate)*dt)
  error=wrap(np.asarray(body_yaw)-self.reference)
  effective=np.asarray(user_yaw_rate)-np.asarray(enabled)*self.kp*error
  return np.clip(effective,-self.rate_limit,self.rate_limit),error

class YawRateHistory:
 def __init__(self,n,dt=.02,window=.5):
  self.dt=dt;self.lag=round(window/dt);self.history=np.zeros((n,self.lag+1));self.last=np.zeros(n);self.unwrapped=np.zeros(n);self.cursor=0
 def reset(self,ids,yaw):
  ids=np.asarray(ids,int);self.last[ids]=yaw;self.unwrapped[ids]=yaw;self.history[ids,:]=np.asarray(yaw)[:,None]
 def update(self,yaw,age_steps):
  self.unwrapped+=wrap(np.asarray(yaw)-self.last);self.last[:]=yaw;self.history[:,self.cursor]=self.unwrapped;old=(self.cursor+1)%(self.lag+1);elapsed=np.maximum(np.minimum(age_steps,self.lag)*self.dt,self.dt);rate=(self.unwrapped-self.history[:,old])/elapsed;self.cursor=old;return rate

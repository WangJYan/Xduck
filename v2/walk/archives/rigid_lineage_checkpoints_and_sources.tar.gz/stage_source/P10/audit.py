from pathlib import Path
import json,hashlib,ast,argparse
from runtime import atomic_json
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--final',action='store_true');a=ap.parse_args();expected='e0dccfa8f7b1cd3f17f5e56ec78a3a3764f2fdc448681f672a1567acecc182b5';assert hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest()==expected
for p in R.glob('*.py'):ast.parse(p.read_text())
assert json.loads((R/'CPU_TESTS.json').read_text())['status']=='PASS';assert json.loads((R/'GEOMETRY_CHECK.json').read_text())['status']=='PASS_GEOMETRY_ONLY';assert (R/'balanced_env.py').read_bytes()==(R/'project/src/unilab/envs/locomotion/xduck_gf43x40/balanced_env.py').read_bytes()
inputs=['train_rigid_bank.npz','heldout_rigid_bank.npz','direction_anchor.npz','parent_walk400.pt','parent_walk400.onnx','IO_CONTRACT.json','physics/effective_training.mjb'];paths=list(R.glob('*.py'))+list(R.glob('*.yaml'))+[R/n for n in inputs]+list((R/'project/src').rglob('*.py'))+list((R/'project/scripts').rglob('*.py'));frozen={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
if a.final:
 for n in ['SMOKE_SMALL.json','SMOKE_4096.json','LIVE_REGRESSION.json']:assert json.loads((R/n).read_text())['status']=='PASS',n
 for k,v in json.loads((R/'CPU_AUDIT.json').read_text())['frozen_sha256'].items():assert frozen[k]==v,k
atomic_json(R/('PRETRAIN_AUDIT.json' if a.final else 'CPU_AUDIT.json'),dict(status='PASS_READY_FOR_TRAINING' if a.final else 'PASS_CPU',parent_sha256=expected,mirror_policy_verified=True,short_step_and_gap_losses_verified=True,actor_contract='mirror-phase61-v3',frozen_sha256=frozen));print('AUDIT_PASS',a.final,flush=True)

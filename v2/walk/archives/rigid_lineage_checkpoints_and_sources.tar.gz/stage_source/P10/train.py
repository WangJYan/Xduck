from pathlib import Path
import sys,json,time,hashlib,argparse,os
import numpy as np,torch,warp as wp
from omegaconf import OmegaConf
R=Path(__file__).resolve().parent;sys.path[:0]=[str(R/'project/src'),str(R/'project/scripts')]
import train_rsl_rl as E
from unilab.training.rsl_rl import normalize_ppo_train_cfg,RslRlVecEnvWrapper,attach_checkpoint_progress
from rsl_rl.runners import OnPolicyRunner
from runtime import atomic_json,attach_exact_saves
from unilab.envs.locomotion.xduck_gf43x40.balanced_env import BalancedPhaseEnv
from policy_setup import initialize,set_update
from head_freeze import install_head_zero,assert_head_zero
ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--smoke-envs',type=int,default=4096);args=ap.parse_args();torch.set_num_threads(2);c=OmegaConf.load(R/'TRAINING_CONFIG.yaml');TOTAL=int(c.algo.max_iterations);assert c.algo.num_envs==4096 and c.algo.num_steps_per_env==24 and TOTAL in (200,400) and c.algo.save_interval==50
parent_sha=hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest();assert parent_sha=='e0dccfa8f7b1cd3f17f5e56ec78a3a3764f2fdc448681f672a1567acecc182b5'
if not args.smoke:
 audit=json.loads((R/'PRETRAIN_AUDIT.json').read_text());assert audit['status']=='PASS_READY_FOR_TRAINING'
 for n,h in audit['frozen_sha256'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h,n
wp.init();wp.set_mempool_release_threshold('cuda:0',0);torch.cuda.empty_cache();torch.manual_seed(int(c.algo.seed));np.random.seed(int(c.algo.seed));E.ensure_registries();n=args.smoke_envs if args.smoke else 4096
e=E.create_env(c,num_envs=n,env_cfg_override=E.build_ppo_env_cfg_override(c))
try:
 wrapped=RslRlVecEnvWrapper(e,device='cuda');cfg=normalize_ppo_train_cfg(OmegaConf.to_container(c.algo,resolve=True));E.apply_ppo_runtime_flags(cfg,c,training_enabled=True);cfg.setdefault('runner',{})['logger']='none' if args.smoke else 'tensorboard';cfg['logger']=cfg['runner']['logger'];runner=OnPolicyRunner(wrapped,cfg,log_dir=None if args.smoke else str(R/'ppo_run'),device='cuda')
 parent=torch.load(R/'parent_walk400.pt',map_location='cuda',weights_only=False);runner.alg.actor.load_state_dict(parent['actor_state_dict'],strict=True);runner.alg.critic.load_state_dict(parent['critic_state_dict'],strict=True);assert not runner.alg.optimizer.state;del parent
 runner.alg.actor.obs_normalizer.eval();runner.alg.actor.distribution.std_param.requires_grad_(False)
 probe=torch.randn(16,61,device='cuda')*.1;probe[:,59:61]=0
 with torch.no_grad():leg_before=runner.alg.actor.mlp(runner.alg.actor.obs_normalizer(probe))[:,[0,1,2,3,4,9,10,11,12,13]].clone()
 initialize(runner.alg.actor);assert_head_zero(runner.alg.actor)
 with torch.no_grad():leg_after=runner.alg.actor.mlp(runner.alg.actor.obs_normalizer(probe))[:,[0,1,2,3,4,9,10,11,12,13]]
 torch.testing.assert_close(leg_before,leg_after,atol=2e-5,rtol=2e-5)
 normalizer={k:v.clone() for k,v in runner.alg.actor.obs_normalizer.state_dict().items()};obs,_=wrapped.reset();assert obs['actor'].shape==(n,61)
 binding=dict(status='SMOKE' if args.smoke else 'TRAINING_RUNNING',training_pid=os.getpid(),parent='direct_step20_400 video model',parent_sha256=parent_sha,actual_num_envs=n,rollout_steps=24,requested_updates=TOTAL,save_interval=50,evaluation_interval=200,actor_contract="mirror-phase61-v3",phase_obs_indices=[59,60],target_alternating_step_m=float(c.env.step_goal_m),preferred_interval_s=.5,continuous_process=True,speed_upper_m_s=.35,speed_lower_m_s=None,speed_definition='2s horizontal displacement /2s',head_target_rad=[0,0,0,0],exploration_std_body=.15,exploration_std_head=.0001,heading_feedback_fraction=float(e._feedback.mean()),dr_multiplier=e._dr_multiplier,parent_completed_updates=400,curriculum=e.curriculum.snapshot(),normalizer_frozen=True)
 atomic_json(R/('SMOKE_BINDING.json' if args.smoke else 'RUNTIME_BINDING.json'),binding);print('RUNTIME_BINDING',json.dumps(binding),flush=True)
 attach_checkpoint_progress(e,runner)
 if not args.smoke:attach_exact_saves(runner,e,R,TOTAL)
 update_count=0;original_update=runner.alg.update
 def update():
  global update_count
  out=original_update();assert_head_zero(runner.alg.actor);update_count+=1;set_update(runner.alg.actor,update_count)
  if not args.smoke:
   changed=e.maybe_advance_curriculum(update_count)
   if changed:print('CURRICULUM_ADVANCE',json.dumps(e.curriculum.snapshot()),flush=True)
   atomic_json(R/'TRAIN_STATUS.json',dict(status='TRAINING_RUNNING',completed_updates=update_count,requested_updates=TOTAL,parent_completed_updates=400,cumulative_new_updates_from_flex50=400+update_count,training_pid=os.getpid(),environment_identity=id(e),rollout_steps=24,num_envs=n,mirror_blend=float(runner.alg.actor.mlp.blend),curriculum=e.curriculum.snapshot(),updated_unix=time.time()))
  torch.cuda.synchronize();torch.cuda.empty_cache();wp.synchronize_device();return out
 runner.alg.update=update
 if args.smoke:
  for tick in range(64):
   with torch.inference_mode():a=runner.alg.actor.mlp(runner.alg.actor.obs_normalizer(obs['actor']))
   obs,r,d,_=wrapped.step(a);assert torch.isfinite(r).all() and torch.isfinite(obs['actor']).all()
  np.testing.assert_allclose(e.state.obs['obs'][:,59:61],e._phase.encode(),atol=1e-6)
  with torch.no_grad():decoded=runner.alg.actor.obs_normalizer(torch.tensor(e.state.obs['obs'],device='cuda'))[:,59:61].cpu().numpy()
  angle=2*np.pi*e._phase.phase;np.testing.assert_allclose(decoded,np.c_[np.sin(angle),np.cos(angle)],atol=2e-5)
  runner.learn(num_learning_iterations=2,init_at_random_ep_len=False);assert update_count==2 and runner.alg.optimizer.state;assert_head_zero(runner.alg.actor)
  for k,v in runner.alg.actor.obs_normalizer.state_dict().items():assert torch.equal(v,normalizer[k]),k
  rows=np.unique(np.array([0,min(3,n-1),n-1]));other=np.setdiff1d(np.arange(n),rows);e._pair_valid[:]=True;e._walk_last_interval[:]=1.;e.reset(rows);assert not e._pair_valid[rows].any() and not e._walk_last_interval[rows].any();assert e._pair_valid[other].all()
  q=e._backend.get_base_quat()[rows];yaw=np.arctan2(2*(q[:,0]*q[:,3]+q[:,1]*q[:,2]),1-2*(q[:,2]**2+q[:,3]**2));np.testing.assert_allclose(e._heading_adapter.reference[rows],yaw,atol=1e-6)
  xy=e._backend.get_base_pos()[rows,:2];np.testing.assert_allclose(e._speed_xy_history[rows],np.broadcast_to(xy[:,None,:],(len(rows),101,2)),atol=1e-6)
  assert e.curriculum.goal==float(c.env.step_goal_m) and not e.maybe_advance_curriculum(25);assert not e._stride_potential[rows].any();assert not e._phase.age[rows].any();assert np.all(np.isin(e._phase.phase[rows],[0,.5]))
  report=dict(status='PASS',actual_num_envs=n,finite_control_steps=64,ppo_updates=2,normalizer_unchanged=True,partial_reset_pair_and_speed_history_verified=True,head_output_zero=True,phase_encoding_verified=True,mirror_graph_PPO_backward_verified=True,contact_capacities=[e._backend._nconmax,e._backend._njmax]);assert report['contact_capacities']==[128,256];atomic_json(R/('SMOKE_4096.json' if n==4096 else 'SMOKE_SMALL.json'),report);print('SMOKE_PASS',json.dumps(report),flush=True)
 else:
  start=time.time();runner.learn(num_learning_iterations=TOTAL,init_at_random_ep_len=False);assert update_count==TOTAL and runner.current_learning_iteration==TOTAL-1
  for k,v in runner.alg.actor.obs_normalizer.state_dict().items():assert torch.equal(v,normalizer[k]),k
  assert all((R/f'CHECKPOINT_{i}.json').exists() for i in range(50,TOTAL+1,50));report=dict(status='TRAINING_COMPLETE',completed_updates=TOTAL,parent_completed_updates=400,cumulative_new_updates_from_flex50=400+TOTAL,training_pid=os.getpid(),environment_identity=id(e),continuous_single_process=True,elapsed_seconds=time.time()-start,curriculum=e.curriculum.snapshot());atomic_json(R/'TRAIN_STATUS.json',report);print('TRAINING_COMPLETE',json.dumps(report),flush=True)
finally:e.close()

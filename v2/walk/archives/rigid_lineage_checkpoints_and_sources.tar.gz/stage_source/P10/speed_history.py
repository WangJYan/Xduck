import numpy as np
class TranslationSpeedHistory:
 def __init__(self,num_envs,dt=.02,window_s=2.):
  self.dt=dt;self.window_s=window_s;self.length=round(window_s/dt)+1;self.positions=np.zeros((num_envs,self.length,2));self.cursor=0
 def reset(self,ids,positions):self.positions[np.asarray(ids),:,:]=np.asarray(positions)[:,None,:]
 def update(self,positions,age_steps):
  self.positions[:,self.cursor]=positions;old=(self.cursor+1)%self.length
  elapsed=np.minimum(np.asarray(age_steps)*self.dt,self.window_s)
  self.velocity=(np.asarray(positions)-self.positions[:,old])/np.maximum(elapsed,self.dt)[:,None]
  speed=np.linalg.norm(self.velocity,axis=1)
  self.cursor=old;return speed

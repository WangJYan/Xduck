from pathlib import Path
import json,hashlib,numpy as np,torch
from model_io import NativeActor
from mirror_policy import MirrorMLP,raw_map,ACTION_PERM,ACTION_SIGN
from head_freeze import install_head_zero
from runtime import atomic_json
R=Path(__file__).resolve().parent;torch.set_num_threads(2)
source=R/'source_motion400.pt';sha=hashlib.sha256(source.read_bytes()).hexdigest();assert sha=='13bdeecf9730dc9553fbdc5f61ac21f7d250ab198451ecbd67b8571a4cb51abd'
a=NativeActor(source).eval();normal=a.obs_normalizer;mean=normal._mean.reshape(-1);scale=normal._std.reshape(-1)+.01;means=mean.numpy();scales=scale.numpy();base=a.mlp.base
with torch.no_grad():base[0].bias.add_(base[0].weight[:,[56,57,58]]@(-mean[[56,57,58]]/scale[[56,57,58]]));base[0].weight[:,[56,57,58]]=0
# Bake the demonstrated heading controller into the actor graph; caller supplies
# body heading error observations, and does NOT also correct command omega.
a.mlp=MirrorMLP(base,normal._mean,normal._std,1.,heading_gain=.8);install_head_zero(a,.15)
with np.load(R/'feedback_default_trace.npz') as z:
 obs=z['obs'].copy();error=z['input_error'];target=z['raw_action'];T,N,_=obs.shape
 obs[:,:,56]=means[56]+scales[56]*np.minimum((np.arange(T)+1)*.02/.5,1)[:,None];obs[:,:,57]=means[57]+scales[57]*np.cos(error);obs[:,:,58]=means[58]+scales[58]*np.sin(error)
 idx=np.arange(0,T,10);x=obs[idx].reshape(-1,61);expected=target[idx].reshape(-1,14)
 with torch.inference_mode():actual=a(torch.tensor(x,dtype=torch.float32)).numpy()
 parity=float(abs(actual-expected).max());assert parity<3e-5,parity
 # Retain only a weak sagittal walking anchor at zero heading error, so old turn
 # overshoot cannot be preserved by imitation.
 keep=(abs(obs[:,:,50])<.01)&(abs(obs[:,:,48])>.05);o=obs[keep];t=target[keep];
 mask=np.zeros_like(t);mask[:,[2,3,4,11,12,13]]=1
 np.savez_compressed(R/'motion_anchor.npz',obs=o,mean=t,mask=mask,phase=np.zeros(len(o),int))
ck=torch.load(source,map_location='cpu',weights_only=False);sd=ck['actor_state_dict'];new=a.state_dict()
for k in list(sd):
 if k.startswith('mlp.'):del sd[k]
for k,v in new.items():
 if k.startswith('mlp.'):sd[k]=v.detach().cpu()
ck['actor_state_dict']=sd;ck['heading_start_contract']='heading-start-phase61-v6';torch.save(ck,R/'parent_walk400.pt');h=hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest()
atomic_json(R/'PARENT.json',dict(seed_sha256=h,source_sha256=sha,source='previous motion repair400',heading_features=[57,58],startup_feature=56))
atomic_json(R/'SEED_INITIALIZATION.json',dict(status='PASS',seed_sha256=h,heading_controller_baked_into_actor=True,heading_gain=.8,teacher_trace_action_parity_error=parity,no_external_command_correction=True,not_full_acceptance=True))
print('SEED_READY',h,parity,flush=True)

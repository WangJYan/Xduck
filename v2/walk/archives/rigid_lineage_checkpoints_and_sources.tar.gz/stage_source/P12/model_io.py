from pathlib import Path
import torch
from torch import nn
from mirror_policy import MirrorMLP
from policy_setup import initialize
class Norm(nn.Module):
 def __init__(self,mean,std):super().__init__();self.register_buffer('_mean',mean);self.register_buffer('_std',std)
 def forward(self,x):return (x-self._mean)/(self._std+.01)
class NativeActor(nn.Module):
 def __init__(self,path,adapt=False):
  super().__init__();sd=torch.load(path,map_location='cpu',weights_only=False)['actor_state_dict'];self.obs_normalizer=Norm(sd['obs_normalizer._mean'],sd['obs_normalizer._std']);base=nn.Sequential(nn.Linear(61,512),nn.ELU(),nn.Linear(512,256),nn.ELU(),nn.Linear(256,128),nn.ELU(),nn.Linear(128,14));self.distribution=nn.Module();self.distribution.std_param=nn.Parameter(torch.ones(14))
  if 'mlp.blend' in sd:
   self.mlp=MirrorMLP(base,self.obs_normalizer._mean,self.obs_normalizer._std,float(sd['mlp.blend']));missing=self.mlp.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')},strict=False);assert not missing.unexpected_keys;assert set(missing.missing_keys)<= {'heading_gain','yaw_obs_mean','yaw_obs_scale'}
  else:
   self.mlp=base;self.mlp.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')},strict=True)
   if adapt:initialize(self)
 def forward(self,x):return self.mlp(self.obs_normalizer(x))

from pathlib import Path
import argparse,json,hashlib,zipfile,numpy as np,torch,onnxruntime as ort
from model_io import NativeActor
from mirror_policy import raw_map,ACTION_PERM,ACTION_SIGN
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--updates',type=int,required=True);a=ap.parse_args();p=R/'ppo_run'/f'model_{a.updates-1}.pt';ck=torch.load(p,map_location='cpu',weights_only=False);sd=ck['actor_state_dict'];parent=torch.load(R/'parent_walk400.pt',map_location='cpu',weights_only=False)
assert ck['infos']['unilab_progress']['next_iteration']==a.updates
for k,v in sd.items():
 assert torch.isfinite(v).all()
 if k.startswith('obs_normalizer.'):assert torch.equal(v,parent['actor_state_dict'][k]),k
actor=NativeActor(p).eval();assert not actor.mlp[-1].weight[5:9].any() and not actor.mlp[-1].bias[5:9].any();out=R/f'heading_start_{a.updates}.onnx';torch.set_num_threads(2);torch.onnx.export(actor,torch.zeros(1,61),str(out),input_names=['obs'],output_names=['actions'],opset_version=17,dynamo=False);op=ort.SessionOptions();op.intra_op_num_threads=1;s=ort.InferenceSession(str(out),sess_options=op,providers=['CPUExecutionProvider']);x=np.random.default_rng(1104801).normal(0,.2,(256,61)).astype(np.float32)
with torch.inference_mode():expected=actor(torch.tensor(x)).numpy()
actual=np.concatenate([s.run(None,{'obs':v[None]})[0] for v in x]);error=float(abs(actual-expected).max());assert error<3e-5 and not actual[:,5:9].any()
perm,sign,bias=raw_map(actor.obs_normalizer._mean.reshape(-1)[[59,60]].numpy());mx=x[:,perm]*sign+bias
with torch.inference_mode():equiv=float(abs(actor(torch.tensor(mx)).numpy()-expected[:,ACTION_PERM]*ACTION_SIGN).max())
blend=float(actor.mlp.blend)
if a.updates>=200:assert blend==1 and equiv<3e-5
report=dict(status='PASS',updates=a.updates,parent_sha256=hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest(),checkpoint_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),onnx=out.name,onnx_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),input_shape=[1,61],output_shape=[1,14],actor_contract='heading-start-phase61-v6',task_adapter_required=True,heading_correction_inside_onnx=True,external_yaw_command_correction=False,new_input_indices=[56,57,58],body_yaw_heading_hold_supported=True,normalizer_frozen=True,head_mean_outputs_exact_zero=True,mirror_blend=blend,mirror_max_raw_action_error=equiv,max_torch_onnx_error=error,validation_report='final32_summary.json')
(R/f'EXPORT_{a.updates}.json').write_text(json.dumps(report,indent=2))
with zipfile.ZipFile(R/(out.stem+'_bundle.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for f in [out,R/'task_adapter.py',R/'heading_adapter.py',R/'IO_CONTRACT.json',R/'TRAINING_CONFIG.yaml',R/f'EXPORT_{a.updates}.json']:z.write(f,f.name)
print(json.dumps(report,indent=2))

from pathlib import Path
import json,hashlib,numpy as np,torch
from model_io import NativeActor
from mirror_policy import MirrorMLP,raw_map,ACTION_PERM,ACTION_SIGN
from head_freeze import install_head_zero,assert_head_zero
from runtime import atomic_json
R=Path(__file__).resolve().parent;torch.set_num_threads(2);torch.manual_seed(1105601);rng=np.random.default_rng(1105602)
source=R/'source_motion400.pt';sha=hashlib.sha256(source.read_bytes()).hexdigest();assert sha=='13bdeecf9730dc9553fbdc5f61ac21f7d250ab198451ecbd67b8571a4cb51abd'
student=NativeActor(source).to('cuda');normal=student.obs_normalizer;mean=normal._mean.reshape(-1);scale=normal._std.reshape(-1)+.01
# Preserve the old actor exactly before training the new observable fields.
base=student.mlp.base;new_ids=[56,57,58]
with torch.no_grad():base[0].bias.add_(base[0].weight[:,new_ids]@(-mean[new_ids]/scale[new_ids]));base[0].weight[:,new_ids]=0
student.mlp=MirrorMLP(base,normal._mean,normal._std,1.);install_head_zero(student,.15);student.obs_normalizer.eval()
means=mean.detach().cpu().numpy();scales=scale.detach().cpu().numpy();parts=[];counts={}
for prefix in ['feedback_default','feedback_quarter']:
 with np.load(R/(prefix+'_trace.npz')) as z:
  o=z['obs'];a=z['raw_action'];q=z['qpos'];err=z['input_error'];T,N,_=o.shape
  for scenario in range(8):
   idx=np.arange(scenario*8,(scenario+1)*8);obs=o[:,idx].copy();target=a[:,idx].copy()
   obs[:,:,56]=means[56]+scales[56]*np.minimum((np.arange(T)+1)*.02/.5,1)[:,None]
   obs[:,:,57]=means[57]+scales[57]*np.cos(err[:,idx]);obs[:,:,58]=means[58]+scales[58]*np.sin(err[:,idx])
   tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,idx,4]**2+q[:,idx,5]**2),-1,1)));good=(tilt<15)&(q[:,idx,2]>.26)&(np.abs(err[:,idx])<.7)
   obs=obs[good];target=target[good];assert len(obs)>200
   choose=rng.choice(len(obs),min(len(obs),4500),replace=False);obs=obs[choose];target=target[choose]
   pool=2 if scenario>=6 else 1 if scenario in [1,4,5] else 0
   parts.append((obs,target,np.full(len(obs),pool)));counts[f'{prefix}:{scenario}']=len(obs)
o=np.concatenate([v[0] for v in parts]);t=np.concatenate([v[1] for v in parts]);labels=np.concatenate([v[2] for v in parts]);t[:,5:9]=0
p,s,b=raw_map(means[[59,60]],float(means[58]));o=np.r_[o,o[:,p]*s+b];t=np.r_[t,t[:,ACTION_PERM]*ACTION_SIGN];labels=np.r_[labels,labels]
# Only weak sagittal walking anchors remain; no imitation of old over-fast turns.
keep=(np.abs(o[:,50])<.01)&(np.abs(o[:,48])>.05);mask=np.zeros_like(t[keep]);mask[:,[2,3,4,11,12,13]]=1
np.savez_compressed(R/'motion_anchor.npz',obs=o[keep],mean=t[keep],mask=mask,phase=np.zeros(keep.sum(),int))
train=rng.random(len(o))>.1;ot=torch.tensor(o,device='cuda',dtype=torch.float32);tt=torch.tensor(t,device='cuda',dtype=torch.float32);leg=torch.tensor([0,1,2,3,4,9,10,11,12,13],device='cuda');pools=[np.flatnonzero(train&(labels==i)) for i in range(3)];hold=[np.flatnonzero((~train)&(labels==i)) for i in range(3)];optimizer=torch.optim.Adam(student.mlp.parameters(),lr=7e-5)
for step in range(1800):
 losses=[]
 for pool in pools:
  ids=torch.tensor(rng.choice(pool,256),device='cuda');losses.append(((student(ot[ids])[:,leg]-tt[ids][:,leg])/.35).square().mean())
 loss=3*losses[0]+losses[1]+2*losses[2];optimizer.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(student.mlp.parameters(),2);optimizer.step();assert_head_zero(student)
 if step%300==0:print('DISTILL',step,float(loss),flush=True)
with torch.inference_mode():rms=[float((student(ot[ids])[:,leg]-tt[ids][:,leg]).square().mean().sqrt()) for ids in hold]
assert max(rms)<.20,rms
ck=torch.load(source,map_location='cpu',weights_only=False);sd=ck['actor_state_dict'];new=student.state_dict()
for k in sd:
 if k.startswith('mlp.'):sd[k]=new[k].detach().cpu()
ck['actor_state_dict']=sd;ck['heading_start_contract']='heading-start-phase61-v6';torch.save(ck,R/'parent_walk400.pt');seed_sha=hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest()
atomic_json(R/'PARENT.json',dict(seed_sha256=seed_sha,source_sha256=sha,source='previous motion repair400',heading_features=[57,58],startup_feature=56))
atomic_json(R/'DISTILLATION.json',dict(status='PASS',seed_sha256=seed_sha,holdout_leg_raw_rms_by_pool=rms,counts=counts,steps=1800,teacher='same motion400 with closed-loop heading correction',not_physical_acceptance=True))
print('SEED_READY',rms,seed_sha,flush=True)

"""heading-start-phase61-v6 input adapter, required for these specialist policies.
obs56=start progress; obs57/58=cos/sin heading error; obs59/60=phase.
Heading command correction is INSIDE ONNX. Do not also correct command omega. Reset on Walk
entry; first adapt call dt=0, then actual control dt (~.02s). BODY yaw required.
"""
import numpy as np
from heading_adapter import HeadingAdapter
class TaskAdapter:
 def __init__(self,n,mean,scale,goal=.15,variable=False):
  self.age=np.zeros(n);self.phase=np.zeros(n);self.mean=np.asarray(mean);self.scale=np.asarray(scale);self.goal=goal;self.variable=variable;self.heading=HeadingAdapter(n);self.side_age=np.zeros(n);self.was_side=np.zeros(n,bool);self.heading_error=np.zeros(n);self.last_requested=np.zeros((n,3));self.start_mean=-9.551364200888202e-06;self.start_scale=.012883138600736857;self.heading_mean=np.array([1.4711259836985846e-06,2.4759025109233335e-05]);self.heading_scale=np.array([.01288898404687643,.03884611673653126])
 def reset(self,ids,yaw,offset=0.):
  ids=np.asarray(ids,int);self.age[ids]=0;self.phase[ids]=offset;self.heading.reset(ids,yaw);self.side_age[ids]=0;self.was_side[ids]=False;self.heading_error[ids]=0;self.last_requested[ids]=0
 def encode(self):return self.mean+self.scale*np.c_[np.sin(2*np.pi*self.phase),np.cos(2*np.pi*self.phase)]
 def encode_task(self):return np.c_[self.start_mean+self.start_scale*np.clip(self.age/.5,0,1),self.heading_mean+self.heading_scale*np.c_[np.cos(self.heading_error),np.sin(self.heading_error)]]
 def advance(self,yaw,requested,dt=.02,feedback=False):
  requested=np.asarray(requested)
  old_key=np.where(np.abs(self.last_requested)>.05,np.sign(self.last_requested),0);new_key=np.where(np.abs(requested)>.05,np.sign(requested),0)
  active=np.any(new_key!=0,axis=1);was_active=np.any(old_key!=0,axis=1);start=active&np.any(old_key!=new_key,axis=1)
  self.age[start]=0;fresh=np.flatnonzero(active&(~was_active))
  if len(fresh):self.heading.reset(fresh,np.asarray(yaw)[fresh])
  self.last_requested[:]=requested
  interval=np.where(np.abs(requested[:,0])>.05,np.clip(self.goal/np.maximum(np.abs(requested[:,0]),.05),.35,.65),.5) if self.variable else .5
  self.age+=dt
  side=np.abs(requested[:,1])>.05;new=side&(~self.was_side);self.side_age[new]=0;self.phase[new]=np.where(requested[new,1]>0,.5,0.)
  self.side_age[side]+=dt;self.was_side=side
  moving=(np.linalg.norm(requested[:,:2],axis=1)>.05)|(np.abs(requested[:,2])>.05)
  self.phase=(self.phase+moving*dt/(2*interval))%1
  effective,error=self.heading.step(yaw,requested[:,2],dt,feedback);self.heading_error[:]=error;return effective,error
 def adapt_observation(self,obs,body_yaw,requested,dt=.02,heading_hold=False):
  if heading_hold:raise ValueError('Heading correction is inside this ONNX; use heading_hold=False')
  effective,error=self.advance(body_yaw,requested,dt,False);out=np.array(obs,copy=True);out[:,48:51]=requested;out[:,51:56]=0;out[:,56:59]=self.encode_task();out[:,50]=effective;out[:,59:61]=self.encode();return out

def reference(age,phase,center,length):
 phi=(np.asarray(phase)[:,None]+np.array([0.,.5]))%1;swing=phi>=.5;u=np.clip(2*phi-1,0,1);blend=u**3*(10+u*(-15+6*u));length=np.asarray(length);length=np.broadcast_to(length[:,None] if length.ndim==1 else length,(len(phi),2))
 x=np.where(swing,-length/2+2*length*blend-length*u,length/2-2*length*phi)
 ramp=np.clip(np.asarray(age)/.45,0,1);ramp=ramp**3*(10+ramp*(-15+6*ramp));return center[:,None]+ramp[:,None]*x,ramp[:,None]*np.where(swing,.035*np.sin(np.pi*u)**2,0),swing,ramp

from pathlib import Path
import ast,json,numpy as np,torch
from balance_objective import terms
from task_adapter import TaskAdapter,reference
from mirror_policy import raw_map,ACTION_PERM,ACTION_SIGN
from model_io import NativeActor
R=Path(__file__).resolve().parent
for p in R.glob('*.py'):ast.parse(p.read_text())
n=8;zero=np.zeros(n);one=np.ones(n);length=np.full((n,2),.1);valid=np.ones((n,2),bool)
cmd=np.array([[.24,0,0],[-.24,0,0],[0,0,.35],[0,0,-.35],[0,.1,0],[0,-.1,0],[.24,0,.35],[-.24,0,-.35]])
def calc(v,yaw,age=one*5,started=None):
 if started is None:started=np.ones(n,bool)
 return terms(valid,length,np.full((n,2),.035),np.zeros((n,2)),np.zeros((n,2)),valid,np.zeros((n,2)),np.zeros((n,2)),~valid,one,np.linalg.norm(v[:,:2],axis=1),yaw,cmd,zero,zero,.1,True,local_velocity=v,requested=cmd,heading_error=zero,side=np.isin(np.arange(n),[4,5]),side_displacement=zero,forward_displacement=zero,segment_age=age,side_lands=np.zeros((n,2),int),side_tracking=zero,extra_events=zero,net_velocity=v[:,:2],has_started=started,first_step_event=np.zeros(n,bool),step_interval=np.ones((n,2))*.4,loss_update=200)
a=calc(cmd,cmd[:,2]);over=calc(cmd,cmd[:,2]*1.5);standing=calc(np.zeros_like(cmd),zero,age=one*.8,started=np.zeros(n,bool))
assert np.all(a['yaw_cost'][[2,3]]<over['yaw_cost'][[2,3]])
assert standing['startup_cost'][2]>=4-1e-8 and standing['idle'][2]>=4
ad=TaskAdapter(n,[0,0],[.04,.04],.1,True);ad.reset(np.arange(n),zero);ad.advance(zero,cmd,dt=.02);assert abs(ad.phase[0]-ad.phase[1])<1e-12
encoded=ad.encode_task();assert encoded.shape==(n,3)
try:ad.adapt_observation(np.zeros((n,61)),zero,cmd,heading_hold=True);raise AssertionError('double correction accepted')
except ValueError:pass
# A short ramp still begins continuously and reaches full amplitude at.45s.
x,h,sw,ramp=reference(np.array([0.,.225,.45]),np.array([.25,.25,.25]),np.zeros(3),np.ones((3,2))*.1);assert ramp[0]==0 and .49<ramp[1]<.51 and ramp[2]==1
actor=NativeActor(R/'parent_walk400.pt').eval();mean=actor.obs_normalizer._mean.reshape(-1).numpy();scale=actor.obs_normalizer._std.reshape(-1).numpy()+.01
assert float(actor.mlp.heading_gain)==float(torch.tensor(.8))
rng=np.random.default_rng(1105609);o=rng.normal(0,.1,(64,61)).astype(np.float32);o[:,56]=mean[56]+scale[56];angles=rng.uniform(-.5,.5,64);o[:,57]=mean[57]+scale[57]*np.cos(angles);o[:,58]=mean[58]+scale[58]*np.sin(angles)
p,s,b=raw_map(mean[[59,60]],float(mean[58]));mo=o[:,p]*s+b
with torch.inference_mode():out=actor(torch.tensor(o));ref=actor(torch.tensor(mo));assert torch.isfinite(out).all();assert not out[:,5:9].any();err=float(abs(ref-out[:,ACTION_PERM]*torch.tensor(ACTION_SIGN)).max())
assert err<3e-5,err
(R/'CPU_TESTS.json').write_text(json.dumps(dict(status='PASS',checks=['parse','overshoot_loses_reward','startup_cost_active_by_.8s','short_ramp_continuous','heading_and_startup_observations','double_heading_correction_rejected','head_zero','whole_graph_mirror_equivariance'],mirror_error=err),indent=2));print('CPU_TEST_PASS',err,flush=True)

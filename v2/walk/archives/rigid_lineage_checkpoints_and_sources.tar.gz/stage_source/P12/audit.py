from pathlib import Path
import json,hashlib,argparse,ast
from runtime import atomic_json
from omegaconf import OmegaConf
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--final',action='store_true');a=ap.parse_args()
sha=hashlib.sha256((R/'parent_walk400.pt').read_bytes()).hexdigest();assert sha==json.loads((R/'PARENT.json').read_text())['seed_sha256']
assert json.loads((R/'CPU_TESTS.json').read_text())['status']=='PASS'
c=OmegaConf.load(R/'TRAINING_CONFIG.yaml');assert c.algo.num_envs==4096 and c.algo.num_steps_per_env==24 and c.algo.max_iterations==400 and c.algo.save_interval==50
assert json.loads((R/'ADJUSTMENT_AUDIT.json').read_text())['status']=='PASS_ADJUSTMENT_AUDIT'
assert json.loads((R/'SEED_INITIALIZATION.json').read_text())['status']=='PASS'
assert not c.env.flexible_dr_enabled
assert (R/'balanced_env.py').read_bytes()==(R/'project/src/unilab/envs/locomotion/xduck_gf43x40/balanced_env.py').read_bytes()
inputs=['train_rigid_bank.npz','heldout_rigid_bank.npz','parent_walk400.pt','parent_walk400.onnx','IO_CONTRACT.json','physics/effective_training.mjb','PARENT.json','motion_anchor.npz','SEED_INITIALIZATION.json','ADJUSTMENT_AUDIT.json']
paths=list(R.glob('*.py'))+list(R.glob('*.yaml'))+[R/n for n in inputs]+list((R/'project/src').rglob('*.py'))+list((R/'project/scripts').rglob('*.py'))
frozen={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
if a.final:
 for name in ['SMOKE_SMALL.json','SMOKE_4096.json','LIVE_REGRESSION.json']:assert json.loads((R/name).read_text())['status']=='PASS',name
 for key,value in json.loads((R/'CPU_AUDIT.json').read_text())['frozen_sha256'].items():assert frozen[key]==value,key
atomic_json(R/('PRETRAIN_AUDIT.json' if a.final else 'CPU_AUDIT.json'),dict(status='PASS_READY_FOR_TRAINING' if a.final else 'PASS_CPU',parent_sha256=sha,frozen_sha256=frozen,requirements='DESIGN.json',no_external_heading_feedback_required=True))
print('AUDIT_PASS',a.final,flush=True)

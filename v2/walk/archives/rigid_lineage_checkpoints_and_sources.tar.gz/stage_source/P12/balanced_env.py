"""Command-aligned locomotion with accepted gait and speed across DR."""
from dataclasses import dataclass
from balance_objective import FixedGoal,terms as phase_terms,GAMMA
from task_adapter import TaskAdapter,reference
from heading_adapter import HeadingAdapter, YawRateHistory
from speed_history import TranslationSpeedHistory
import numpy as np
from step_measurement import update_env as measured_placement
from unilab.base import registry
from .new_stand_smooth import NewStandSmoothCfg, NewStandSmoothEnv, NewStandBankReset
from .startup_flex import StartupFlexEnv
from .rigid_startcourse import RigidStartCourseEnv
import mujoco
from .startup_flex import rotate
COMMANDS = np.array([[0.3, 0, 0], [-0.3, 0, 0], [0, 0, 0.4], [0, 0, -0.4], [0.3, 0, 0.4], [0.3, 0, -0.4]])

def motion_metrics(command, velocity, yaw_rate, gain=0.65):
    norm = np.linalg.norm(command[:, :2], axis=1)
    translating = norm > 0.05
    axis = command[:, :2] / np.maximum(norm[:, None], 1e-06)
    signed_speed = np.sum(velocity[:, :2] * axis, axis=1)
    signed_turn = np.sign(command[:, 2]) * yaw_rate
    return (translating, axis, signed_speed, signed_turn, gain * command[:, :2])

def midpoint_step_axes(current_yaw, other_touchdown_yaw):
    delta = np.arctan2(np.sin(current_yaw[:, None] - other_touchdown_yaw), np.cos(current_yaw[:, None] - other_touchdown_yaw))
    middle = current_yaw[:, None] - 0.5 * delta
    return np.stack([np.cos(middle), np.sin(middle), np.zeros_like(middle)], axis=2)

def opposite_step_lengths(world, last_touchdown, forward_axis):
    axis = forward_axis[:, None, :] if forward_axis.ndim == 2 else forward_axis
    return np.sum((world - last_touchdown[:, ::-1, :]) * axis, axis=2)

def pseudo_huber(x):
    return np.sqrt(1.0 + np.asarray(x) ** 2) - 1.0

def pair_step_terms(lengths, goal=0.2, error_scale=0.05, symmetry_scale=0.04):
    error = lengths - goal
    worst = np.max(np.abs(error), axis=1)
    quality = 1.0 / (1.0 + (worst / (2.0 * error_scale)) ** 2)
    target_cost = pseudo_huber(error / error_scale).mean(1)
    asymmetry = pseudo_huber((lengths[:, 0] - lengths[:, 1]) / symmetry_scale)
    return (quality, 1.2 * target_cost + 0.8 * asymmetry)

def paired_step_reward(landed, known_other, interval, step_length, peak, goal_step, alternating, pair_lengths, pair_valid, error_scale=0.05, symmetry_scale=0.04):
    duration = np.maximum(interval, 0.0)
    active = landed & known_other & alternating
    (quality, pair_loss) = pair_step_terms(pair_lengths, goal_step, error_scale, symmetry_scale)
    pair_ready = pair_valid.all(1)
    elapsed = (duration * active).sum(1)
    peak_score = np.exp(-((np.maximum(0.025 - peak, 0) + np.maximum(peak - 0.085, 0)) / 0.025) ** 2)
    event_height = (peak_score * active).sum(1) / np.maximum(active.sum(1), 1)
    events = pair_ready * 6 * quality * event_height * elapsed
    cost = pair_ready * pair_loss * elapsed
    cost += (landed * known_other * 0.35 * pseudo_huber((step_length - goal_step) / error_scale) * duration).sum(1)
    cost += (landed * known_other * ~alternating * 0.5 * duration).sum(1)
    return (events, cost, quality, pair_loss)

def speed_band_terms(speed, age, low=0.0, high=0.35, std=0.07):
    u = np.clip(age / 1.2, 0, 1)
    shape = u * u * u * (10 + u * (-15 + 6 * u))
    distance = np.maximum(low * shape - speed, 0) + np.maximum(speed - high, 0)
    scaled = distance / std
    return (1.0 / (1.0 + scaled ** 2), pseudo_huber(scaled))

def cycle_heading_cost(current_yaw, previous_yaw, period, valid, scale=0.04):
    delta = np.arctan2(np.sin(current_yaw[:, None] - previous_yaw), np.cos(current_yaw[:, None] - previous_yaw))
    rate = delta / np.maximum(period, 0.02)
    return 0.5 * np.sum(pseudo_huber(rate / scale) * np.maximum(period, 0.0) * valid, axis=1)

def slow_speed_upper(update, ramp_updates=1, start=0.35, goal=0.35):
    u = np.clip(update / ramp_updates, 0.0, 1.0)
    blend = u * u * u * (10 + u * (-15 + 6 * u))
    return start + (goal - start) * blend

def slow_step_terms(period, active, upper_speed, step_goal=0.2, low_speed=0.0, timing_scale=0.1):
    low_interval = step_goal / upper_speed
    high_interval = np.inf if low_speed <= 0 else step_goal / low_speed
    error = np.maximum(low_interval - period, 0) + np.maximum(period - high_interval, 0)
    q = 1.0 / (1.0 + (error / timing_scale) ** 2)
    score = (q * active).sum(1) / np.maximum(active.sum(1), 1)
    cost = (pseudo_huber(error / timing_scale) * np.maximum(period, 0.0) * active).sum(1)
    return (score, cost)

def short_step_floor(pair_lengths, pair_valid, floor=0.18, scale=0.02):
    short = np.maximum(floor - np.min(pair_lengths, axis=1), 0.0)
    return pseudo_huber(short / scale) * pair_valid.all(1)

def gait_evidence_floor(lengths, valid, time_since, intervals, goal, age, weight=2.0):
    grace = np.maximum(3.0, 2.5 * np.maximum(intervals, 0.0))
    decay = np.exp(-np.maximum(time_since - grace, 0.0) / np.maximum(1.0, 0.5 * intervals))
    evidence = np.where(valid, lengths * decay, 0.0)
    startup = np.clip(age / 1.2, 0.0, 1.0)
    startup = startup * startup * startup * (10 + startup * (-15 + 6 * startup))
    deficit = pseudo_huber(np.maximum(0.9 * goal - np.min(evidence, axis=1), 0.0) / (0.1 * goal)) * startup
    freshness = np.min(np.where(valid, decay, 0.0), axis=1)
    return (deficit, freshness)

def fall_remaining_task_cost(age, episode_seconds=20.0, weight=2.0, terminal=10.0):
    return weight * pseudo_huber(9.0) * np.maximum(episode_seconds - age, 0.0) + terminal

@registry.envcfg('XDuckBalancedPhase')
@dataclass
class BalancedPhaseCfg(NewStandSmoothCfg):
    task_mode: str="stride"
    step_goal_m: float=.15
    phase_mean: tuple[float,float]=(0.,0.)
    phase_scale: tuple[float,float]=(1.,1.)
    direction_speed_gain: float = 0.65
    direction_seed: int = 1490091
    direction_switch_fraction: float = 0.6
    smooth_width_target_m: float = 0.212
    smooth_width_weight: float = 2.0
    smooth_height_weight: float = 0.0
    smooth_head_target: tuple[float, float] = (0.018978888, 0.059834011)
    direction_stall_seconds: float = 3.0
    fast_ramp_updates: int = 80
    fast_command_start: float = 0.3
    fast_command_low: float = 0.3
    fast_command_high: float = 0.3
    fast_step_start_m: float = 0.06
    fast_step_goal_m: float = 0.2
    fast_step_minimum_m: float = 0.18
    fast_step_maximum_m: float = 0.22
    fast_step_sigma_m: float = 0.03
    fast_speed_min_m_s: float = 0.2
    fast_speed_max_m_s: float = 0.4
    fast_speed_band_std_m_s: float = 0.07
    fast_start_allowed_drop_m: float = 0.02
    repair_error_scale_m: float = 0.05
    repair_symmetry_scale_m: float = 0.04
    repair_heading_scale_rad: float = 0.17
    repair_heading_gate_rad: float = 0.26
    speed_objective_enabled: bool = True
    slow_speed_low_m_s: float = 0.0
    slow_speed_high_m_s: float = 0.35
    slow_speed_start_high_m_s: float = 0.35
    slow_ramp_updates: int = 1
    slow_speed_weight: float = 3.0
    slow_instant_speed_weight: float = 3.0
    slow_timing_weight: float = 2.0
    slow_short_floor_weight: float = 2.0
    walk_progress_weight: float = 8.0
    walk_fall_penalty: float = 10.0
    slow_stall_penalty: float = 20.0
    repair_heading_weight: float = 4.0
    repair_cycle_yaw_weight: float = 4.0
    repair_cycle_yaw_scale_rad_s: float = 0.04
    repair_yawrate_scale_rad_s: float = 0.04
    repair_yawrate_weight: float = 1.0
    repair_angular_std_rad_s: float = 0.12
    repair_yaw_ema_retention: float = 0.985
    repair_instant_yaw_scale_rad_s: float = 0.2
    repair_instant_yaw_weight: float = 0.1
    repair_pair_objective_weight: float = 3.0
    repair_lateral_scale_m: float = 0.1
    repair_lateral_weight: float = 0.5

@registry.env('XDuckBalancedPhase', sim_backend='mjwarp')
class BalancedPhaseEnv(RigidStartCourseEnv):

    def __init__(self, cfg, num_envs=1, backend_type='mjwarp'):
        self._heading_adapter=HeadingAdapter(num_envs)
        self._yaw_rate_meter=YawRateHistory(num_envs)
        self._requested=np.zeros((num_envs,3))
        self._feedback=np.ones(num_envs,dtype=bool)
        self._next_switch=np.full(num_envs,6.)
        self._reference_error=np.zeros(num_envs)
        self._phase=TaskAdapter(num_envs,cfg.phase_mean,cfg.phase_scale,cfg.step_goal_m,cfg.task_mode=="headturn")
        self._phase_rng=np.random.default_rng(cfg.direction_seed+777)
        self._phase_center=np.zeros(num_envs)
        self.curriculum = FixedGoal(cfg.step_goal_m)
        self._stride_potential = np.zeros(num_envs)
        self._speed_meter = TranslationSpeedHistory(num_envs, cfg.ctrl_dt)
        self._speed_xy_history = self._speed_meter.positions
        self._speed_cursor = 0
        self._chunk_steps = np.zeros(num_envs, int)
        self._chunk_counts = np.zeros((num_envs, 2), int)
        self._chunk_lengths = np.zeros((num_envs, 2))
        self._chunk_inband = np.zeros((num_envs, 2), int)
        self._chunk_attempts = np.zeros(num_envs, int)
        self._chunk_valid = np.zeros(num_envs, int)
        self._chunk_speed_max = np.zeros(num_envs)
        self._chunk_heading_max = np.zeros(num_envs)
        self._chunk_tilt_max = np.zeros(num_envs)
        self._chunk_origin = np.zeros((num_envs, 2))
        self._task_kind=np.zeros(num_envs,int)
        self._segment_origin=np.zeros((num_envs,2))
        self._segment_yaw=np.zeros(num_envs)
        self._segment_start=np.zeros(num_envs)
        self._side_lands=np.zeros((num_envs,2),int)
        self._segment_foot0=np.zeros((num_envs,2,3));self._segment_fresh=np.ones(num_envs,bool)
        self._loss_update=0;self._first_step_done=np.zeros(num_envs,bool);self._first_step_time=np.full(num_envs,np.nan)
        self._dir_rng = np.random.default_rng(cfg.direction_seed)
        self._dir_commands = np.zeros((num_envs, 13))
        self._dir_old_commands = np.zeros((num_envs, 3))
        self._dir_kind = np.zeros(num_envs, int)
        self._fast_command_targets = np.zeros(num_envs)
        self._dir_age = np.zeros(num_envs, int)
        self._dir_next_switch = np.full(num_envs, np.inf)
        self._dir_mean_v = np.zeros((num_envs, 2))
        self._dir_mean_w = np.zeros(num_envs)
        self._dir_land_time = np.full((num_envs, 2), -1.0)
        self._dir_land_position = np.zeros((num_envs, 2, 3))
        self._step_last_side = np.full(num_envs, -1, np.int8)
        self._pair_lengths = np.zeros((num_envs, 2))
        self._walk_last_interval = np.zeros((num_envs, 2))
        self._touchdown_yaw = np.zeros((num_envs, 2))
        self._pair_valid = np.zeros((num_envs, 2), bool)
        self._repair_origin_xy = np.zeros((num_envs, 2))
        self._step_mean_forward = np.zeros(num_envs)
        self._step_mean_body_speed = np.zeros(num_envs)
        self._step_mean_lateral = np.zeros(num_envs)
        self._dir_land_axis = np.zeros((num_envs, 2, 3))
        self._dir_last_full = np.full(num_envs, -1.0)
        self._dir_stall_at = np.full(num_envs, 3.0)
        self._dir_heading0 = np.zeros(num_envs)
        if cfg.newstand_bank_path is None:
            raise ValueError('A physically collected new-standing bank is required')
        with np.load(cfg.newstand_bank_path) as z:
            self._newstand_bank = {k: z[k].copy() for k in z.files}
        self._newstand_rng = np.random.default_rng(cfg.newstand_seed)
        self._smooth_age = np.zeros(num_envs, int)
        self._smooth_z0 = np.zeros(num_envs)
        self._smooth_heading0 = np.zeros(num_envs)
        self._smooth_width0 = np.zeros(num_envs)
        self._smooth_previous_v = np.zeros(num_envs)
        self._smooth_air = np.zeros((num_envs, 2), bool)
        self._smooth_peak = np.zeros((num_envs, 2))
        self._smooth_liftoff = np.zeros((num_envs, 2, 3))
        self._smooth_axis = np.zeros((num_envs, 2, 3))
        self._smooth_landings = np.zeros(num_envs, int)
        m = mujoco.MjModel.from_binary_path(cfg.warp_compiled_model_file)
        self._smooth_site_local = np.array([m.site(s + '_foot').pos.copy() for s in ['left', 'right']])
        names = [m.body(int(m.site(s + '_foot').bodyid[0])).name for s in ['left', 'right']]
        super().__init__(cfg, num_envs=num_envs, backend_type=backend_type)
        self._smooth_body_ids = np.array([self._backend.get_body_id(n) for n in names], np.int32)
        assert len(self._passive_qpos_indices) == 0 and (not cfg.flexible_dr_enabled) and (cfg.physics_microsteps == 1)

    def _make_dr_provider(self):
        return BalancedPhaseReset()

    def _fast_ramp(self):
        u = float(np.clip((self.step_counter - self.cfg.startup_initial_step) / self.cfg.rollout_steps / self.cfg.fast_ramp_updates, 0.0, 1.0))
        return u * u * u * (10 + u * (-15 + 6 * u))

    def set_loss_update(self,update):self._loss_update=int(update)

    def _set_direction(self,ids,initial=False):
        ids=np.asarray(ids,int);n=len(ids)
        kind=self._dir_rng.choice(10,size=n,p=[.10,.10,.075,.075,.075,.075,.20,.20,.05,.05])
        self._task_kind[ids]=kind
        v=self._dir_rng.uniform(.18,.28,n);w=self._dir_rng.uniform(.20,.50,n)
        self._requested[ids]=0
        self._requested[ids,0]=np.where(kind<6,np.where(np.isin(kind,[1,4,5]),-v,v),0)
        self._requested[ids,1]=np.where(kind==8,.10,np.where(kind==9,-.10,0))
        self._requested[ids,2]=np.where(np.isin(kind,[2,4,6]),w,np.where(np.isin(kind,[3,5,7]),-w,0))
        self._feedback[ids]=False
        age=self._smooth_age[ids]*self.cfg.ctrl_dt
        self._first_step_done[ids]=False;self._first_step_time[ids]=np.nan;self._phase.age[ids]=0;self._segment_start[ids]=age;self._side_lands[ids]=0;self._segment_fresh[ids]=True
        self._segment_origin[ids]=self._backend.get_base_pos()[ids,:2]
        q=self._backend.get_base_quat()[ids];self._segment_yaw[ids]=np.arctan2(2*(q[:,0]*q[:,3]+q[:,1]*q[:,2]),1-2*(q[:,2]**2+q[:,3]**2))
        # Heading reference stays continuous across direction changes.
        # TaskAdapter resets it only when entering motion from idle.
        self._pair_valid[ids]=False;self._pair_lengths[ids]=0;self._step_last_side[ids]=-1;self._dir_land_time[ids]=-1
        self._dir_commands[ids]=0;self._dir_commands[ids,:3]=self._requested[ids]
        self._next_switch[ids]=age+np.where(kind>=8,4.,self._dir_rng.uniform(4,8,n))
        if initial:self._dir_age[ids]=0

    def _maybe_resample_commands(self,state):
        ids=np.flatnonzero(self._smooth_age*self.cfg.ctrl_dt>=self._next_switch)
        if len(ids):self._set_direction(ids)
        elapsed=self._smooth_age*self.cfg.ctrl_dt-self._segment_start
        side=self._task_kind>=8
        self._requested[side,1]=np.where(elapsed[side]<1.2,np.where(self._task_kind[side]==8,.10,-.10),0.)
        q=self._backend.get_base_quat();w,x,y,z=q.T;yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))
        effective,error=self._phase.advance(yaw,self._requested,self.cfg.ctrl_dt,self._feedback);self._reference_error[:]=error
        self._dir_commands[:]=0;self._dir_commands[:,:3]=self._requested;self._dir_commands[:,2]=effective;self._dir_commands[:,8:11]=self._phase.encode_task();self._dir_commands[:,11:13]=self._phase.encode();state.info['commands'][:]=self._dir_commands

    def _reset_episode_history(self, ids):
        super()._reset_episode_history(ids)
        if hasattr(self,'_step_measurement'):self._step_measurement.reset(ids)
        self._smooth_age[ids] = 0
        self._smooth_air[ids] = False
        self._smooth_peak[ids] = 0
        self._smooth_landings[ids] = 0
        self._dir_mean_v[ids] = 0
        self._dir_mean_w[ids] = 0
        self._dir_land_time[ids] = -1
        self._dir_last_full[ids] = -1
        self._dir_age[ids] = 0
        self._step_last_side[ids] = -1
        self._reset_chunks(ids)
        self._stride_potential[ids] = 0
        self._walk_last_interval[ids] = 0
        self._pair_lengths[ids] = 0
        self._pair_valid[ids] = False
        self._touchdown_yaw[ids] = 0
        self._step_mean_forward[ids] = 0
        self._step_mean_lateral[ids] = 0
        self._step_mean_body_speed[ids] = 0

    def _compute_reward(self, state, linvel, gyro, upvector, dof_pos):
        reward = StartupFlexEnv._compute_reward(self, state, linvel, gyro, upvector, dof_pos)
        dt = self.cfg.ctrl_dt
        episode_age = self._smooth_age * dt
        age = self._dir_age * dt
        cmd = state.info['commands'][:, :3]
        q = self._backend.get_base_quat()
        (w, x, y, z) = q.T
        roll = np.arctan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
        pitch = np.arcsin(np.clip(2 * (w * y - z * x), -1, 1))
        yaw = np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
        yaw_rate = (gyro[:, 1] * np.sin(roll) + gyro[:, 2] * np.cos(roll)) / np.maximum(np.cos(pitch), 0.5)
        (translating, axis, speed, turn, target) = motion_metrics(cmd, linvel, yaw_rate, self.cfg.direction_speed_gain)
        self._dir_mean_v = 0.95 * self._dir_mean_v + 0.05 * linvel[:, :2]
        self._dir_mean_w = .9*self._dir_mean_w+.1*yaw_rate
        world_velocity = rotate(q, linvel)
        forward_axis = np.c_[np.cos(yaw), np.sin(yaw), np.zeros(self.num_envs)]
        lateral_axis = np.c_[-np.sin(yaw), np.cos(yaw), np.zeros(self.num_envs)]
        forward_speed = np.sum(world_velocity * forward_axis, axis=1)
        lateral_speed = np.sum(world_velocity * lateral_axis, axis=1)
        self._step_mean_forward = 0.95 * self._step_mean_forward + 0.05 * forward_speed
        self._step_mean_lateral = 0.95 * self._step_mean_lateral + 0.05 * lateral_speed
        self._step_mean_body_speed = 0.95 * self._step_mean_body_speed + 0.05 * np.linalg.norm(world_velocity[:, :2], axis=1)
        instantaneous_speed = np.linalg.norm(world_velocity[:, :2], axis=1)
        rootxy = self._backend.get_base_pos()[:, :2]
        speed2s = self._speed_meter.update(rootxy, self._smooth_age + 1)
        (pos, quat) = self._backend.get_body_pose_w(self._smooth_body_ids)
        world = pos + rotate(quat, np.broadcast_to(self._smooth_site_local, pos.shape))
        inverse = q.copy()
        inverse[:, 1:] *= -1
        width = np.abs(rotate(inverse, world[:, 0] - world[:, 1])[:, 1])
        width_cost = np.minimum(((width - 0.212) / np.where(translating, 0.03, 0.045)) ** 2, 9.0)
        height = self._backend.get_base_pos()[:, 2]
        down_cost = np.minimum((np.maximum(self._smooth_z0 - height - self.cfg.fast_start_allowed_drop_m, 0) / 0.012) ** 2, 9.0) * (episode_age < 2.0)
        world_velocity = rotate(q, linvel)
        vertical_cost = np.minimum((np.maximum(abs(world_velocity[:, 2]) - 0.14, 0) / 0.1) ** 2, 9.0) * (episode_age < 2.0)
        initial_roll_cost = np.minimum((np.maximum(abs(roll) - np.deg2rad(6), 0) / 0.08) ** 2, 9.0) * (episode_age < 1.0)
        h = self._foot_height
        measured = measured_placement(self, world, h, yaw, rootxy, cmd)
        leaving = measured['leaving'];self._smooth_peak = measured['peak'].copy()
        landing = measured['landing'];touchdown = landing
        known_other = measured['known_other'];step_length = measured['length'];interval = measured['interval']
        times = np.broadcast_to(episode_age[:, None], (self.num_envs, 2));yaw_rows = np.broadcast_to(yaw[:, None], (self.num_envs, 2))
        seed = (self._dir_land_time < 0) & measured['contact']
        self._dir_land_position[seed]=world[seed];self._dir_land_time[seed]=times[seed];self._touchdown_yaw[seed]=yaw_rows[seed]
        one = touchdown.sum(1) == 1;side = np.argmax(touchdown, axis=1)
        alternate_row = measured['alternating'];alternating = touchdown & alternate_row[:, None]
        goal_step = self.curriculum.goal
        proper = touchdown
        valid_step = measured['valid']
        self._pair_valid[touchdown & ~valid_step] = False
        invalid_transition = touchdown.any(1) & ~alternate_row
        self._pair_valid[invalid_transition] = False
        self._pair_lengths[valid_step] = step_length[valid_step]
        self._pair_valid[valid_step] = True
        (events, gait_cost, pair_quality, pair_loss) = paired_step_reward(proper, known_other, interval, step_length, self._smooth_peak, goal_step, alternating, self._pair_lengths, self._pair_valid, self.cfg.repair_error_scale_m, self.cfg.repair_symmetry_scale_m)
        raw_step_credit = events.copy()
        self._walk_last_interval[valid_step] = interval[valid_step]
        time_since = np.where(touchdown, 0.0, episode_age[:, None] - self._dir_land_time)
        (_, evidence_freshness) = gait_evidence_floor(self._pair_lengths, self._pair_valid, time_since, self._walk_last_interval, goal_step, episode_age)
        self._fast_step_goal = goal_step
        short_cost = (landing & (self._smooth_peak < 0.014)).sum(1) * 0.5
        overheight = (landing * np.minimum((np.maximum(self._smooth_peak - 0.085, 0) / 0.025) ** 2, 4.0)).sum(1) * 0.8
        self._dir_land_position[touchdown] = world[touchdown]
        self._dir_land_time[touchdown] = times[touchdown]
        self._touchdown_yaw[touchdown] = yaw_rows[touchdown]
        self._step_last_side[one] = side[one]
        self._step_last_side[touchdown.sum(1) > 1] = -1
        self._dir_last_full[valid_step.any(1)] = episode_age[valid_step.any(1)]
        self._smooth_peak_before_landing = self._smooth_peak.copy()
        self._smooth_peak[landing] = 0
        self._smooth_air = (self._smooth_air | leaving) & ~landing
        straight = (np.abs(cmd[:, 2]) < 0.05) & translating
        unwanted_turn = np.minimum((np.maximum(abs(self._dir_mean_w) - 0.1, 0) / 0.15) ** 2, 4.0) * straight
        heading_error = self._reference_error.copy()
        heading_gate = 1.0 / (1.0 + (heading_error / self.cfg.repair_heading_gate_rad) ** 2)
        yawrate_cost = pseudo_huber(self._dir_mean_w / self.cfg.repair_yawrate_scale_rad_s)
        instant_yawrate_cost = pseudo_huber(yaw_rate / self.cfg.repair_instant_yaw_scale_rad_s)
        normal = rotate(quat, rotate(self._sole_delta_quat, np.broadcast_to(np.array(self._sole_normals), pos.shape)))
        ground = self._contact & (h < 0.003) & (np.linalg.norm(normal[:, :, :2], axis=2) < 0.15)
        slip_speed = np.linalg.norm(self._foot_vel[:, :, :2], axis=2)
        slip_cost = (np.minimum((np.maximum(slip_speed - 0.08, 0) / 0.2) ** 2, 4.0) * ground).sum(1) / np.maximum(ground.sum(1), 1)
        signed_progress = np.clip(forward_speed, -0.35, 0.35)
        root=self._backend.get_base_pos();delta=world-root[:,None,:]
        foot_x=delta[:,:,0]*np.cos(yaw[:,None])+delta[:,:,1]*np.sin(yaw[:,None])
        fresh=self._smooth_age==0;self._phase_center[fresh]=foot_x[fresh].mean(1)
        walking=np.abs(self._requested[:,0])>.05
        interval_ref=np.where(walking,np.clip(self.cfg.step_goal_m/np.maximum(np.abs(self._requested[:,0]),.05),.35,.65),.5)
        reference_length=np.where(walking,self.cfg.step_goal_m*np.sign(self._requested[:,0]),0.)[:,None]+np.array([-1.,1.])[None,:]*np.where(walking,.212,.16)[:,None]*self._requested[:,2,None]*interval_ref[:,None]
        target_x,target_h,swing,ramp=reference(self._phase.age,self._phase.phase,self._phase_center,reference_length)
        yaw_rate_filtered=self._yaw_rate_meter.update(yaw,self._smooth_age+1)
        presence=evidence_freshness*self._pair_valid.all(1)
        net_xy=self._speed_meter.velocity;lateral_net=-np.sin(yaw)*net_xy[:,0]+np.cos(yaw)*net_xy[:,1]
        side=self._task_kind>=8;old_extra=np.maximum(self._side_lands.sum(1)-2,0);self._side_lands+=touchdown*side[:,None];extra_events=np.maximum(self._side_lands.sum(1)-2,0)-old_extra
        segment_age=episode_age-self._segment_start
        first_step_event=valid_step.any(1)&(~self._first_step_done)
        self._first_step_time[first_step_event]=segment_age[first_step_event];self._first_step_done|=first_step_event
        delta=root[:,:2]-self._segment_origin
        side_sign=np.where(self._task_kind==8,1.,-1.)
        side_displacement=side_sign*(-np.sin(self._segment_yaw)*delta[:,0]+np.cos(self._segment_yaw)*delta[:,1])
        forward_displacement=np.cos(self._segment_yaw)*delta[:,0]+np.sin(self._segment_yaw)*delta[:,1]
        self._segment_foot0[self._segment_fresh]=world[self._segment_fresh];self._segment_fresh[:]=False
        lead=np.where(self._task_kind==8,0,1)
        start=np.where(np.arange(2)[None,:]==lead[:,None],0.,.6)
        u=np.clip((segment_age[:,None]-start)/.6,0,1);smooth=u**3*(10+u*(-15+6*u))
        footdelta=world-self._segment_foot0
        foot_lateral=(-np.sin(self._segment_yaw[:,None])*footdelta[:,:,0]+np.cos(self._segment_yaw[:,None])*footdelta[:,:,1])*side_sign[:,None]
        side_h=.025*np.sin(np.pi*u)**2
        side_tracking=np.exp(-((foot_lateral-.10*smooth)/.04)**2-((h-side_h)/.025)**2).mean(1)

        terms=phase_terms(valid_step,self._pair_lengths,self._smooth_peak_before_landing,foot_x,h,self._contact,target_x,target_h,swing,ramp,speed2s,yaw_rate_filtered,cmd,presence,lateral_net,self.cfg.step_goal_m,True,local_velocity=linvel,requested=self._requested,heading_error=heading_error,side=side,side_displacement=side_displacement,forward_displacement=forward_displacement,segment_age=segment_age,side_lands=self._side_lands,side_tracking=side_tracking,extra_events=extra_events,net_velocity=np.c_[np.cos(yaw)*net_xy[:,0]+np.sin(yaw)*net_xy[:,1],lateral_net],has_started=self._first_step_done,first_step_event=first_step_event,step_interval=interval,loss_update=self._loss_update)
        gate=terms['posture_gate'];step_credit=terms['landing']+terms['startup_event'];self._stride_potential[:]=0
        width_out=np.maximum(.16-width,0)+np.maximum(width-np.where(side,.34,.24),0)
        width_cost=np.minimum((width_out/.03)**2,9.)
        height_out=np.maximum(.26-height,0)+np.maximum(height-.34,0)
        height_cost=np.minimum((height_out/.02)**2,9.)
        physical_extra=-2*width_cost-2*height_cost-.5*(h>.003).all(1)-3*slip_cost
        ancestor_extra = reward - self._task_base_reward_dt
        # Reduce the exploration barrier only during acquisition of new actions;
        # restore the original action-rate cost by update200.
        action_rate_factor=np.where(self._task_kind==0,1.,.25+.75*np.clip(self._loss_update/200,0,1))
        ancestor_extra-=self._task_base_terms_dt['action_rate_l2']*(1-action_rate_factor)
        gated_posture = self._task_base_positive_dt * gate
        for (name, term) in self._task_base_terms_dt.items():
            self._episode_reward_sums[name] -= (1 - gate) * np.maximum(term, 0.0)
        reward=(self._task_base_negative_dt+gated_posture+ancestor_extra+physical_extra*dt-short_cost-overheight+step_credit+(terms['reference_credit']+terms['locomotion_credit']-terms['pair_cost']-terms['inplace_cost']-terms['speed_cost']-terms['yaw_cost']-terms['idle']-terms['startup_cost']-terms['lateral_cost']+terms['side_credit']-terms['side_cost'])*dt).astype(reward.dtype)
        self._gait_events=step_credit.copy();self._gait_cost=np.zeros(self.num_envs)
        self._audit_task=dict(task_kind=self._task_kind.copy(),side_displacement=side_displacement.copy(),requested=self._requested.copy(),effective=cmd.copy(),local_velocity=linvel.copy(),yaw_rate_filtered=yaw_rate_filtered.copy(),head_qd=self.get_dof_vel()[:,5:9].copy(),speed2s=speed2s.copy(),head_q=dof_pos[:,5:9].copy(),yaw=yaw.copy(),yaw_rate=yaw_rate_filtered.copy(),heading_error=heading_error.copy(),phase=self._phase.age.copy(),foot_x=foot_x.copy(),target_x=target_x.copy(),target_h=target_h.copy(),pair_lengths=self._pair_lengths.copy(),**{k:v.copy() for k,v in terms.items()})
        state.info.setdefault('log',{}).update({'task/landing_per_s':float((step_credit/dt).mean()),'task/reference_per_s':float(terms['reference_credit'].mean()),'task/speed_cost_per_s':float(terms['speed_cost'].mean()),'task/reference_tracking':float(terms['reference_tracking'].mean()),'head/abs_mean_deg':float(np.degrees(abs(dof_pos[:,5:9])).mean()),'motion/speed2s_mean_m_s':float(speed2s.mean()),'motion/heading_error_mean_deg':float(np.degrees(abs(heading_error)).mean()),'task/pair_gap_cost_per_s':float(terms['pair_cost'].mean()),'task/coverage':float(terms['coverage'].mean()),'gait/left_cached_step_m':float(self._pair_lengths[:,0].mean()),'gait/right_cached_step_m':float(self._pair_lengths[:,1].mean())})
        self._smooth_age += 1
        self._dir_age += 1
        return reward

    def _reset_chunks(self, ids):
        for a in [self._chunk_steps, self._chunk_counts, self._chunk_lengths, self._chunk_inband, self._chunk_attempts, self._chunk_valid, self._chunk_speed_max, self._chunk_heading_max, self._chunk_tilt_max]:
            a[ids] = 0

    def _record_chunk(self, valid, attempt, lengths, goal, speed, heading, upvector, rootxy):
        self._chunk_steps += 1
        self._chunk_counts += valid
        self._chunk_lengths += np.where(valid, lengths, 0.0)
        self._chunk_inband += valid & (lengths >= 0.9 * goal) & (lengths <= 1.1 * goal)
        self._chunk_attempts += attempt.any(1)
        self._chunk_valid += valid.any(1)
        self._chunk_speed_max = np.maximum(self._chunk_speed_max, np.where(self._smooth_age * self.cfg.ctrl_dt >= 2.0, speed, 0.0))
        self._chunk_heading_max = np.maximum(self._chunk_heading_max, np.degrees(abs(heading)))
        self._chunk_tilt_max = np.maximum(self._chunk_tilt_max, np.degrees(np.arccos(np.clip(upvector[:, 2], -1, 1))))

    def update_state(self, state):
        result = super().update_state(state)
        ready = (self._chunk_steps >= 400) | result.terminated
        if ready.any():
            ids = np.flatnonzero(ready)
            mean = self._chunk_lengths[ids] / np.maximum(self._chunk_counts[ids], 1)
            delta = self._backend.get_base_pos()[ids, :2] - self._chunk_origin[ids]
            f = np.c_[np.cos(self._dir_heading0[ids]), np.sin(self._dir_heading0[ids])]
            l = np.c_[-f[:, 1], f[:, 0]]
            forward = np.sum(delta * f, axis=1)
            angle = np.degrees(np.arctan2(abs(np.sum(delta * l, axis=1)), forward))
            goal = self.curriculum.goal
            good = ~result.terminated[ids] & (self._chunk_counts[ids].min(1) >= 2) & (abs(mean - goal).max(1) <= 0.1 * goal) & ((self._chunk_inband[ids] / np.maximum(self._chunk_counts[ids], 1)).min(1) >= 0.8) & (self._chunk_valid[ids] / np.maximum(self._chunk_attempts[ids], 1) >= 0.9) & (self._chunk_speed_max[ids] <= 0.35) & (self._chunk_heading_max[ids] < 30) & (self._chunk_tilt_max[ids] < 20) & (angle < 20) & (forward > 0.5 * goal)
            self.curriculum.record(good)
            self._reset_chunks(ids)
            self._chunk_origin[ids] = self._backend.get_base_pos()[ids, :2]
        remaining = np.maximum(self.cfg.max_episode_seconds - self._smooth_age * self.cfg.ctrl_dt, 0.0)
        penalty = result.terminated * (4 * remaining + 20)
        result.info.setdefault('log', {})['task/fall_cost_per_s'] = float(penalty.mean() / self.cfg.ctrl_dt)
        ended = result.terminated | (state.info['steps']+1 >= self.cfg.max_episode_steps)
        terminal_shaping = GAMMA*self._stride_potential*ended
        self._stride_potential[ended] = 0
        return result.replace(reward=result.reward - penalty.astype(result.reward.dtype) - terminal_shaping.astype(result.reward.dtype))

    def maybe_advance_curriculum(self, update):
        changed = self.curriculum.advance(update)
        if changed:
            self._reset_chunks(np.arange(self.num_envs))
            self._chunk_origin[:] = self._backend.get_base_pos()[:, :2]
        return changed

class BalancedPhaseReset(NewStandBankReset):

    def build_reset_plan(self, env, ids):
        plan = super().build_reset_plan(env, ids)
        env._set_direction(ids, initial=True)
        env._repair_origin_xy[np.asarray(ids, dtype=int)] = plan.qpos[:, :2]
        plan.info_updates['commands'][:] = env._dir_commands[ids]
        q = plan.qpos[:, 3:7]
        env._dir_heading0[ids] = np.arctan2(2 * (q[:, 0] * q[:, 3] + q[:, 1] * q[:, 2]), 1 - 2 * (q[:, 2] ** 2 + q[:, 3] ** 2))
        env._segment_origin[ids]=plan.qpos[:,:2]
        env._segment_yaw[ids]=env._dir_heading0[ids]
        env._phase.heading.reset(ids,env._dir_heading0[ids])
        env._heading_adapter.reset(ids,env._dir_heading0[ids])
        env._reference_error[ids]=0
        env._yaw_rate_meter.reset(ids,env._dir_heading0[ids])
        env._phase.reset(ids,env._dir_heading0[ids],env._phase_rng.integers(0,2,len(ids))*.5)
        plan.info_updates["commands"][:,8:11]=env._phase.encode_task()[ids]
        plan.info_updates["commands"][:,11:13]=env._phase.encode()[ids]
        env._speed_xy_history[np.asarray(ids, dtype=int), :, :] = plan.qpos[:, None, :2]
        env._chunk_origin[np.asarray(ids, dtype=int)] = plan.qpos[:, :2]
        return plan

from pathlib import Path
import os,json,hashlib,subprocess,math
os.environ.setdefault('MUJOCO_GL','egl')
import numpy as np,mujoco,imageio_ffmpeg
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;source=R/'final32_trace.npz';rs=json.loads((R/'final32_results.json').read_text())['records']
groups=[('walk',[('forward','FORWARD'),('backward','BACKWARD')],2,1),('walking_turn',[('forward_left','FORWARD + LEFT'),('forward_right','FORWARD + RIGHT'),('backward_left','BACKWARD + LEFT'),('backward_right','BACKWARD + RIGHT')],2,2),('inplace',[('inplace_left','IN-PLACE LEFT'),('inplace_right','IN-PLACE RIGHT')],2,1),('side',[('side_left','SIDE LEFT: one step, then stop'),('side_right','SIDE RIGHT: one step, then stop')],2,1)]
entries=[]
for kind,cases,cols,rows in groups:
 for scenario,label in cases:
  rec=next(r for r in rs if r['scenario']==scenario and r['case']==0);entries.append(dict(scenario=scenario,label=label,index=rec['trace_index']))
ids=[e['index'] for e in entries];z=np.load(source);qtrace=z['qpos'][:,ids].copy();initial=z['initial'][ids].copy();gp=z['geom_pos'][ids].copy();gq=z['geom_quat'][ids].copy();heading=z['heading_error'][:,ids].copy();requested=z['requested'][:,ids].copy();rates=z['yaw_rate'][:,ids].copy();z.close()
m=mujoco.MjModel.from_binary_path(str(R/'physics/effective_training.mjb'));d=mujoco.MjData(m);W,H=640,400;m.vis.global_.offwidth=W;m.vis.global_.offheight=H;m.mat_rgba[:,3]=1;m.geom_rgba[:,3]=1;m.geom_group[:]=0
renderer=mujoco.Renderer(m,height=H,width=W);opt=mujoco.MjvOption();cam=mujoco.MjvCamera();fps=20;seconds=20

def pose(j,t):
 u=max(0,min(t/.02,len(qtrace)));i=min(int(u),len(qtrace));f=u-int(u);p0=initial[j] if i==0 else qtrace[i-1,j];p1=qtrace[min(i,len(qtrace)-1),j];q=(1-f)*p0+f*p1;q[3:7]/=np.linalg.norm(q[3:7]);return q

def yaw(q):
 w,x,y,z=q[3:7];return math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))

def panel(j,t,kind):
 q=pose(j,t);d.qpos[:]=q;m.geom_pos[:]=gp[j];m.geom_quat[:]=gq[j];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);mujoco.mj_camlight(m,d);h0=yaw(initial[j]);cam.azimuth=math.degrees(h0)+(180 if kind=='side' else 90);cam.elevation=-13;cam.distance=1.6 if kind in ['side','inplace'] else 1.35;cam.lookat[:]=initial[j,:3] if kind=='side' else q[:3];cam.lookat[2]=.30
 renderer.update_scene(d,camera=cam,scene_option=opt);renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW]=False;im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,W,83),fill=(15,25,36));draw.text((8,5),entries[j]['label']+' | heading_start400 | heading correction INSIDE ONNX',fill='white');draw.text((8,23),f't={t:.2f}s | 1x | fixed case0 | saved closed-loop trace',fill='white')
 i=min(max(round(t/.02)-1,0),len(qtrace)-1);vx,vy,w=requested[i,j];draw.text((8,41),f'command: vx={vx:+.2f} vy={vy:+.2f} m/s  yaw={w:+.2f} rad/s',fill='white')
 text=f'actual yaw={rates[i,j]:+.3f} rad/s'
 if t>=2:text+=f' | 2s speed={np.linalg.norm(q[:2]-pose(j,t-2)[:2])/2:.3f} m/s'
 if kind=='side':
  lateral=(q[:2]-initial[j,:2])@np.array([-math.sin(h0),math.cos(h0)]);text+=f' | lateral={lateral*100:+.1f} cm (left +)'
 draw.text((8,59),text,fill='white')
 body=yaw(q)-h0;target=body-float(heading[i,j]);cx,cy=W-51,H-51;radius=29;draw.ellipse((cx-radius,cy-radius,cx+radius,cy+radius),outline=(190,190,190),width=1)
 for theta,color in [(target,(80,240,110)),(body,(70,190,255))]:draw.line((cx,cy,cx+radius*math.sin(theta),cy-radius*math.cos(theta)),fill=color,width=3)
 draw.text((W-150,H-15),'green=target blue=body',fill='white');return im
try:
 offset=0;sha=hashlib.sha256(source.read_bytes()).hexdigest()
 for kind,cases,cols,rows in groups:
  js=list(range(offset,offset+len(cases)));offset+=len(cases);out=R/f'heading_start400_{kind}_1x.mp4'
  ff=subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-v','error','-f','rawvideo','-s',f'{W*cols}x{H*rows}','-pix_fmt','rgb24','-r',str(fps),'-i','-','-an','-c:v','libx264','-threads','2','-crf','20','-pix_fmt','yuv420p',str(out)],stdin=subprocess.PIPE)
  try:
   for frame in range(round(seconds*fps)):
    im=Image.new('RGB',(W*cols,H*rows))
    for k,j in enumerate(js):im.paste(panel(j,frame/fps,kind),((k%cols)*W,(k//cols)*H))
    if frame==fps*3:im.save(out.with_name(out.stem+'_preview.png'))
    ff.stdin.write(np.asarray(im).tobytes())
  finally:ff.stdin.close();assert ff.wait()==0
  out.with_suffix('.json').write_text(json.dumps(dict(source_trace=source.name,source_sha256=sha,panels=[entries[j] for j in js],selection='case0 fixed before visual inspection; no failure trimming',seconds=20,fps=20,speed=1,not_a_new_simulation=True),indent=2));print('VIDEO_READY',out.name,flush=True)
finally:renderer.close()

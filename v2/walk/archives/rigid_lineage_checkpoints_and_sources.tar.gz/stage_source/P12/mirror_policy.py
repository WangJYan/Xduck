"""Sagittal reflection in NATIVE raw61 coordinates, conjugated by frozen RMS.
Joint axes audited from model: all five left/right leg coordinates swap AND
negate; neck/head pitch stay, head yaw/roll negate. Phases59/60 shift by pi.
"""
import torch
from torch import nn
import numpy as np
ACTION_PERM=np.array([9,10,11,12,13,5,6,7,8,0,1,2,3,4])
ACTION_SIGN=np.array([-1,-1,-1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,-1],np.float32)
def raw_map(phase_mean,heading_mean=2.4759025109233335e-05):
 perm=np.arange(61);sign=np.ones(61,np.float32);bias=np.zeros(61,np.float32)
 sign[:3]=[-1,1,-1];sign[3:6]=[1,-1,1]
 for start in [6,20,34]:perm[start:start+14]=start+ACTION_PERM;sign[start:start+14]=ACTION_SIGN
 sign[48:59]=[1,-1,-1,1,1,-1,-1,1,-1,1,-1]
 sign[56]=1;sign[57]=1;sign[58]=-1;bias[58]=2*heading_mean
 sign[59:61]=-1;bias[59:61]=2*np.asarray(phase_mean)
 return perm,sign,bias
class MirrorMLP(nn.Module):
 def __init__(self,base,mean,std,blend=0.,heading_gain=0.):
  super().__init__();self.base=base;mean=mean.reshape(-1).detach();scale=std.reshape(-1).detach()+.01;p,s,b=raw_map(mean[[59,60]].cpu().numpy(),float(mean[58]));p=torch.tensor(p,device=mean.device);s=torch.tensor(s,device=mean.device);b=torch.tensor(b,device=mean.device)
  self.register_buffer('input_perm',p);self.register_buffer('input_gain',s*scale[p]/scale);self.register_buffer('input_bias',(s*mean[p]+b-mean)/scale);self.register_buffer('action_perm',torch.tensor(ACTION_PERM,device=mean.device));self.register_buffer('action_sign',torch.tensor(ACTION_SIGN,device=mean.device));self.register_buffer('blend',torch.tensor(float(blend),device=mean.device));self.register_buffer('heading_gain',torch.tensor(float(heading_gain),device=mean.device));self.register_buffer('yaw_obs_mean',mean[50].clone());self.register_buffer('yaw_obs_scale',scale[50].clone())
 def __getitem__(self,i):return self.base[i]
 def mirror_input(self,z):return z.index_select(-1,self.input_perm)*self.input_gain+self.input_bias
 def mirror_action(self,a):return a.index_select(-1,self.action_perm)*self.action_sign
 def control_input(self,z):
  sine=z[...,58];cosine=z[...,57]
  quadrant=torch.atan(torch.abs(sine)/torch.clamp(torch.abs(cosine),min=1e-7))
  # The exact antipode has no unique signed direction; choose zero correction
  # consistently, including after float32 encoding of sin(+/-pi).
  error=torch.where(cosine>=0,quadrant,torch.pi-quadrant)*torch.sign(sine);effective=torch.clamp(z[...,50]*self.yaw_obs_scale+self.yaw_obs_mean-self.heading_gain*error,-.6,.6)
  out=z.clone();out[...,50]=torch.where(self.heading_gain>0,(effective-self.yaw_obs_mean)/self.yaw_obs_scale,z[...,50]);return out
 def forward(self,z):
  own=self.base(self.control_input(z));reflected=self.mirror_action(self.base(self.control_input(self.mirror_input(z))));return own+(self.blend*.5)*(reflected-own)
 def set_update(self,update,ramp=200):self.blend.fill_(min(max(update/ramp,0.),1.))

"""Single physical placement detector for training and measurement.
No minimum swing-height censoring. Height hysteresis separates leaving/landing.
All supported landings update history. Distances use adjacent actual contact-onset footprints, never a stale censored history.
"""
import numpy as np
REVISION='v201_route_contact_measurement_20261108'
class StepMeasurement:
 def __init__(self,n,dt=.02):
  self.n=n;self.dt=dt;self.time=np.zeros(n);self.fresh=np.ones(n,bool);self.contact=np.zeros((n,2),bool);self.on=np.zeros((n,2),int);self.off=np.zeros((n,2),int);self.armed=np.zeros((n,2),bool);self.peak=np.zeros((n,2));self.known=np.zeros((n,2),bool);self.last_time=np.zeros((n,2));self.last_root=np.zeros((n,2,2));self.last_side=np.full(n,-1);self.support_position=np.zeros((n,2,3));self.support_time=np.zeros((n,2));self.support_known=np.zeros((n,2),bool);self.placement=np.zeros((n,2,3));self.last_yaw=np.zeros((n,2))
 def reset(self,ids):
  ids=np.asarray(ids,int)
  for name in ['time','contact','on','off','armed','peak','known','last_time','last_root','support_position','support_time','support_known','placement','last_yaw']:getattr(self,name)[ids]=0
  self.fresh[ids]=True;self.last_side[ids]=-1
 def update(self,feet,height,yaw,root_xy,vx_command):
  n=self.n;dt=self.dt;self.time+=dt
  # Disjoint thresholds eliminate the old1.5-3mm overlapping-state chatter.
  self.contact=np.where(height<=.001,True,np.where(height>=.002,False,self.contact))
  self.on=np.where(self.contact,self.on+1,0);self.off=np.where(self.contact,0,self.off+1)
  initial=(self.on>=3)&~self.known
  for side in [0,1]:
   rows=np.flatnonzero(initial[:,side]);self.last_root[rows,side]=root_xy[rows];self.placement[rows,side]=feet[rows,side];self.last_yaw[rows,side]=yaw[rows]
  self.known|=initial
  self.peak=np.maximum(self.peak,np.maximum(height,0));leaving=self.off==2;self.armed|=leaving
  landing=(self.on==1)&self.armed
  peak=self.peak.copy();single=landing.sum(1)==1;side=landing.argmax(1);alternate=single&((self.last_side<0)|(side!=self.last_side))
  known_other=self.known[:,::-1].copy();interval=self.time[:,None]-self.last_time[:,::-1]
  # Adjacent true footprint positions, not a stance point that rolls/slides.
  # ALL debounced landings update placement, including shallow contacts.
  reference=self.placement[:,::-1].copy()
  support_age=self.time[:,None]-self.last_time[:,::-1]
  supported=known_other&(support_age<=1.5000001)
  valid=landing&alternate[:,None]&known_other&supported&(interval>0)
  sign=np.where(vx_command<-.05,-1.,1.)
  delta=yaw[:,None]-self.last_yaw[:,::-1]
  middle=yaw[:,None]-.5*np.arctan2(np.sin(delta),np.cos(delta))
  axis=np.stack([np.cos(middle),np.sin(middle)],axis=2)
  length=np.sum((feet[:,:,:2]-reference[:,:,:2])*axis,axis=2)*sign[:,None]
  length=np.where(supported,length,0.)
  root_progress=np.sum((root_xy[:,None,:]-self.last_root[:,::-1])*axis,axis=2)*sign[:,None]
  for j in [0,1]:
   rows=np.flatnonzero(landing[:,j]);self.last_time[rows,j]=self.time[rows];self.last_root[rows,j]=root_xy[rows];self.placement[rows,j]=feet[rows,j];self.last_yaw[rows,j]=yaw[rows];self.known[rows,j]=True
  self.last_side[single]=side[single];self.last_side[landing.sum(1)>1]=-1
  self.support_position[self.contact]=feet[self.contact]
  self.support_time[self.contact]=np.broadcast_to(self.time[:,None],(n,2))[self.contact]
  self.support_known|=self.contact
  self.armed[landing]=False;self.peak[landing]=0
  # Grounded feet cannot keep an earlier swing peak across shallow contacts.
  self.peak[(self.on>=3)&~self.armed]=0;self.fresh[:]=False
  return dict(landing=landing,valid=valid,projection_yaw=middle.copy(),reference_point=reference.copy(),reference_age_s=support_age.copy(),alternating=alternate,known_other=known_other,interval=interval,length=length,root_progress=root_progress,peak=peak,contact=self.contact.copy(),air=self.armed.copy(),leaving=leaving,low_lift=landing&(peak<.008),revision=REVISION)

def update_env(env,feet,height,yaw,root_xy,command):
 if not hasattr(env,'_step_measurement'):env._step_measurement=StepMeasurement(env.num_envs,env.cfg.ctrl_dt)
 r=env._step_measurement.update(feet,height,yaw,root_xy,command[:,0]);r.update(feet_world=feet.copy(),height=height.copy(),yaw=yaw.copy(),root_xy=root_xy.copy());env._step_measurement_audit=r
 return r

def summarize(events):
 vals=np.array([e['length'] for e in events]);left=[e['length'] for e in events if e['side']==0];right=[e['length'] for e in events if e['side']==1]
 def median(v):return float(np.median(v)) if len(v) else None
 transitions=[events[i]['side']!=events[i-1]['side'] for i in range(1,len(events))]
 fraction=float(np.mean(transitions)) if transitions else 0.
 invalid=int(sum(not x for x in transitions))
 return dict(step_count=len(events),left_step_count=len(left),right_step_count=len(right),left_step_median_m=median(left),right_step_median_m=median(right),step_median_m=median(vals),step_min_m=float(vals.min()) if len(vals) else None,step_p10_m=float(np.percentile(vals,10)) if len(vals) else None,step_p90_m=float(np.percentile(vals,90)) if len(vals) else None,step_interval_median_s=median([e['interval'] for e in events]),invalid_transitions=invalid,alternating_fraction=fraction,root_progress_median_m=median([e['root_progress'] for e in events]))

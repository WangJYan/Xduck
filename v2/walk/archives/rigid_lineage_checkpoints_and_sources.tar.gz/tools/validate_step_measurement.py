from pathlib import Path
import json
import numpy as np
from step_measurement import StepMeasurement as ContactSteps,REVISION
B=Path(__file__).resolve().parents[1]
def gait(step=.13,lift=.03):
 d=ContactSteps(1);ev=[];feet=np.array([[0.,.1,0],[-step,-.1,0]])
 for tick in range(251):
  t=tick*.02;contact=np.ones((1,2),bool);h=np.zeros((1,2));p=feet.copy()
  for side in [0,1]:
   landings=np.arange(1 if side==0 else .5,5.01,1.)
   for land in landings:
    dest=(round(land/.5))*step-step
    if t>=land:p[side,0]=dest;feet[side,0]=dest
    elif land-.32<t<land:
     u=(t-(land-.32))/.32;blend=min(u/.8,1.);p[side,0]=(dest-2*step)*(1-blend)+dest*blend;contact[0,side]=False;h[0,side]=lift*np.sin(np.pi*u)
     break
  r=d.update(p[None],h,np.array([0.]),np.array([[2*step*t-step/2,0]]),np.array([2*step]))
  for side in np.flatnonzero(r['landing'][0]):ev.append({k:float(r[k][0,side]) if r[k].dtype.kind not in 'b' else bool(r[k][0,side]) for k in ['valid','length','root_progress','peak']})
 return ev
normal=gait();good=[e for e in normal if e['valid']];assert len(good)>=5,(len(good),normal);np.testing.assert_allclose([e['length'] for e in good[1:]],.13,atol=1e-9);np.testing.assert_allclose([e['root_progress'] for e in good[1:]],.13,atol=1e-9)
small=gait(.03,.003);small_m=[e for e in small if e['valid']];assert len(small_m)>=5;np.testing.assert_allclose([e['length'] for e in small_m[1:]],.03,atol=1e-9)
d=ContactSteps(1);bounce=0
for t in range(100):
 r=d.update(np.array([[[0.,.1,0],[0.,-.1,0]]]),np.full((1,2),.0005 if t%2==0 else .003),np.array([0.]),np.array([[.01*t,0.]]),np.array([.24]));bounce+=r['landing'].sum()
assert bounce==0
slide=ContactSteps(1);count=0
for t in range(200):
 r=slide.update(np.array([[[t*.005,.1,0],[t*.005,-.1,0]]]),np.zeros((1,2)),np.array([0.]),np.array([[t*.005,0.]]),np.array([.24]));count+=r['valid'].sum()
assert count==0
partial=ContactSteps(2);partial.time[:]=[1,2];partial.reset([0]);assert partial.time[0]==0 and partial.time[1]==2
assert abs(good[0]['length'])<1e-9
report=dict(status='PASS',startup_partial_placement_zero_is_recorded=True,revision=REVISION,analytic13cm_events=len(good),analytic13cm_measured_median_m=float(np.median([e['length'] for e in good])),analytic13cm_root_progress_median_m=float(np.median([e['root_progress'] for e in good])),analytic3cm_shallow_measurements=len(small_m),analytic3cm_measured_median_m=float(np.median([e['length'] for e in small_m])),shallow_events_measured_without_censoring=True,contact_bounce_events=int(bounce),sliding_genuine_events=int(count),partial_reset_isolated=True)
(B/'audit/STEP_MEASUREMENT_VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

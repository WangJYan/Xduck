"""Signed foot-heading retention from the user's frozen walking reference.

Reward only: does not alter observations, actions, joint zeros, HOME or limits.
"""
from pathlib import Path
import json
import numpy as np
import mujoco

def rotate(q,v):
    return v+2*np.cross(q[...,1:],np.cross(q[...,1:],v)+q[...,:1]*v)

def wrap(x):return np.arctan2(np.sin(x),np.cos(x))

class GaitStyle:
    def __init__(self,env,contract):
        self.contract=contract
        m=mujoco.MjModel.from_binary_path(env.cfg.warp_compiled_model_file)
        d=mujoco.MjData(m);mujoco.mj_resetDataKeyframe(m,d,m.key('STAND').id);mujoco.mj_forward(m,d)
        bodies=[m.geom(side+'_foot_collision').bodyid[0] for side in ['left','right']]
        self.ids=np.asarray([env._backend.get_body_id(m.body(int(b)).name) for b in bodies],np.int32)
        base=m.body(env.cfg.asset.base_name).id
        self.axes=np.asarray([d.xmat[b].reshape(3,3).T@d.xmat[base].reshape(3,3)[:,0] for b in bodies])
        self.low=np.radians(contract['heading_p05_deg']);self.high=np.radians(contract['heading_p95_deg'])
        self.target=np.radians(contract['heading_target_deg']);self.sigma=np.radians(contract['heading_scale_deg'])

    def heading(self,env):
        _,q=env._backend.get_body_pose_w(self.ids)
        vectors=rotate(q,np.broadcast_to(self.axes,q.shape[:-1]+(3,)))
        inverse=env._backend.get_base_quat().copy();inverse[:,1:]*=-1
        local=rotate(inverse[:,None,:],vectors)
        return np.arctan2(local[:,:,1],local[:,:,0])

    def penalty(self,heading,commands,contact):
        # Preserve straight forward/backward style; turning and side steps have
        # their own tasks and must retain freedom to steer.
        enabled=(abs(commands[:,0])>.05)&(abs(commands[:,1])<.05)&(abs(commands[:,2])<.1)
        error=wrap(heading-self.target)
        outside=np.maximum(self.low-heading,0.)+np.maximum(heading-self.high,0.)
        x=(outside+.15*abs(error))/self.sigma
        # Smooth, unbounded penalty: a 40-degree splay must not score the same
        # as a 20-degree splay because of a clipped cost plateau.
        cost=np.sqrt(1+x*x)-1
        support=.5+.5*np.asarray(contact,dtype=float)
        density=-self.contract['weight']*(cost*support).sum(1)/support.sum(1)
        return density*enabled,enabled

def install(env,path):
    contract=json.loads(Path(path).read_text());assert contract['status']=='VALIDATED_REFERENCE'
    if hasattr(env,'_gait_style'):
        assert env._gait_style.contract['revision']==contract['revision']
        return env._gait_style
    style=GaitStyle(env,contract);env._gait_style=style
    # Replace the old unsigned, clock-gated, clipped toe reward.
    if hasattr(env.cfg,'toe_heading_reward'):env.cfg.toe_heading_reward=False
    original=env._compute_reward
    def reward(state,linvel,gyro,upvector,dof_pos):
        base=original(state,linvel,gyro,upvector,dof_pos)
        heading=style.heading(env);density,enabled=style.penalty(heading,state.info['commands'][:,:3],env._contact)
        assert np.isfinite(density).all()
        log=state.info.setdefault('log',{})
        log['gait_style/enabled_fraction']=float(enabled.mean())
        log['gait_style/density']=float(density.mean())
        if enabled.any():
            log['gait_style/left_heading_deg']=float(np.degrees(heading[enabled,0]).mean())
            log['gait_style/right_heading_deg']=float(np.degrees(heading[enabled,1]).mean())
        return base+(density*env.cfg.ctrl_dt).astype(base.dtype)
    env._compute_reward=reward
    return style

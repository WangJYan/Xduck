"""Exercise the actual patched guard's fast path, pressure wait and OOM fallback."""
from pathlib import Path
import ast,json,types
B=Path(__file__).resolve().parents[1]
p=B/'workspace/stable_step_side400_20261105/project/src/unilab/base/backend/mjwarp/xduck_gf.py'
tree=ast.parse(p.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='XDuckGF43X40WarpBackend');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_execute_device_forward')
node=ast.ClassDef(name='Worker',bases=[ast.Name(id='Base',ctx=ast.Load())],keywords=[],body=[method],decorator_list=[]);module=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]))
def case(free,timeout=0,error=None):
    counts=dict(cache=0,gc=0,forward=0);clock=types.SimpleNamespace(value=0);values=iter(free);last=free[-1]
    def memory():return next(values,last),32*1024**3
    def cache():counts['cache']+=1
    def collect():counts['gc']+=1
    def sleep(_):clock.value+=360
    class Base:
        def _execute_device_forward(self):
            counts['forward']+=1
            if error and counts['forward']==1:raise RuntimeError(error)
            return 'FORWARD_EXECUTED'
    ns=dict(Base=Base,os=types.SimpleNamespace(environ={'XDUCK_RESET_WAIT_TIMEOUT_S':str(timeout)}),time=types.SimpleNamespace(monotonic=lambda:clock.value,sleep=sleep),torch=types.SimpleNamespace(cuda=types.SimpleNamespace(mem_get_info=memory,empty_cache=cache)),gc=types.SimpleNamespace(collect=collect),print=lambda *a,**k:None)
    exec(compile(module,'actual_optimized_backend','exec'),ns);worker=ns['Worker']();worker._warp=types.SimpleNamespace(synchronize_device=lambda:None)
    try:result=worker._execute_device_forward()
    except RuntimeError as e:result=str(e)
    return dict(result=result,counts=counts,elapsed_s=clock.value,profile=worker._reset_guard_profile)
G=1024**3
normal=case([8*G]);assert normal['result']=='FORWARD_EXECUTED' and normal['counts']==dict(cache=0,gc=0,forward=1)
pressure=case([0,0,0,0,8*G]);assert pressure['result']=='FORWARD_EXECUTED' and pressure['elapsed_s']>=1080 and pressure['counts']['gc']==1
bounded=case([0]*10,timeout=600);assert 'GPU reset workspace unavailable' in bounded['result']
oom=case([8*G],error='CUDA out of memory');assert oom['result']=='FORWARD_EXECUTED' and oom['counts']==dict(cache=1,gc=1,forward=2)
fault=case([8*G],error='invalid model');assert fault['result']=='invalid model' and fault['counts']['forward']==1
report=dict(status='PASS',normal_fast_path=normal,low_memory_wait=pressure,explicit_timeout=bounded,OOM_retry=oom,unrelated_error_not_hidden=fault)
(B/'audit/RESET_OPTIMIZATION_REGRESSION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

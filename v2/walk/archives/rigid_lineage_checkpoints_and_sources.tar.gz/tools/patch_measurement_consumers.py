from pathlib import Path
B=Path(__file__).resolve().parents[1]
p=B/'tools/policy_validation.py';s=p.read_text();s=s.replace('from execution_policy import performance_gates_enabled','from execution_policy import performance_gates_enabled\nfrom step_measurement import StepMeasurement,summarize')
s=s.replace('        alive=np.ones(n,bool);','        detector=StepMeasurement(n,e.cfg.ctrl_dt)\n        alive=np.ones(n,bool);')
a=s.index('            h=e._foot_height;peak=');b=s.index('            if tick>=100:\n                velocities',a)
s=s[:a]+'''            h=e._foot_height
            feet=np.stack([e._backend.get_sensor_data(name) for name in e.cfg.sensor.feet_pos],axis=1)
            yaw=np.arctan2(2*(q[:,3]*q[:,6]+q[:,4]*q[:,5]),1-2*(q[:,5]**2+q[:,6]**2))
            placement=detector.update(feet,h,yaw,q[:,:2],np.full(n,.3))
            steps+=placement['valid']
            if tick>=100:
                for case,side in zip(*np.nonzero(placement['valid'])):
                    events[case].append(dict(time=(tick+1)*.02,side=int(side),length=float(placement['length'][case,side]),root_progress=float(placement['root_progress'][case,side]),interval=float(placement['interval'][case,side])))
            if target_contract is not None:positions.append(q[:,:2].copy())
''' +s[b:]
s=s.replace('step_stats=[measure(case) for case in events]','step_stats=[summarize(case) for case in events]').replace("performance_gate_enforced']=performance_gates_enabled(B)","performance_gate_enforced']=performance_gates_enabled(B)\n        report['measurement_revision']='v201_route_contact_measurement_20261108'\n        if step_stats is not None:report['step_count_per_case']=[s['step_count'] for s in step_stats]")
s=s.replace('additionally15cm','additionally13cm');compile(s,str(p),'exec');p.write_text(s)
p=B/'tools/evaluation.py';s=p.read_text();s=s.replace('import torch','import torch\nfrom step_measurement import StepMeasurement,summarize',1);s=s.replace('        frames=[];','        detector=StepMeasurement(n,e.cfg.ctrl_dt)\n        frames=[];')
a=s.index('            leaving=(~air)');b=s.index('            frames.append',a)
s=s[:a]+'''            feet=np.stack([e._backend.get_sensor_data(s) for s in e.cfg.sensor.feet_pos],axis=1)
            yaw=np.arctan2(2*(q[:,3]*q[:,6]+q[:,4]*q[:,5]),1-2*(q[:,5]**2+q[:,6]**2))
            placement=detector.update(feet,h,yaw,q[:,:2],cmd[:,0])
            for case,side in zip(*np.nonzero(placement['valid'])):
                lands[case].append((tick*.02,int(side)))
                if tick>=200:events[case].append(dict(time=(tick+1)*.02,side=int(side),length=float(placement['length'][case,side]),root_progress=float(placement['root_progress'][case,side]),interval=float(placement['interval'][case,side])))
''' +s[b:]
s=s.replace("stats=alternating_step_statistics(events[j],np.array([1,0,0]),body_frame=True)","stats=summarize(events[j])").replace('turn_pass=turn,','turn_pass=bool(turn),')
s=s.replace('cases_per_scenario=K,seconds=',"measurement_revision='v201_route_contact_measurement_20261108',cases_per_scenario=K,seconds=");compile(s,str(p),'exec');p.write_text(s)
p=B/'tools/supervised.py';s=p.read_text();s=s.replace('from execution_policy import performance_gates_enabled','from execution_policy import performance_gates_enabled\nfrom step_measurement import StepMeasurement')
s=s.replace('            records=[];','            detector=StepMeasurement(n,e.cfg.ctrl_dt)\n            records=[];',1)
a=s.index('                h=e._foot_height;peaks=');b=s.index('                # BC needs',a)
s=s[:a]+'''                h=e._foot_height;feet=np.stack([e._backend.get_sensor_data(s) for s in e.cfg.sensor.feet_pos],axis=1)
                yaw=np.arctan2(2*(q[:,3]*q[:,6]+q[:,4]*q[:,5]),1-2*(q[:,5]**2+q[:,6]**2))
                placement=detector.update(feet,h,yaw,q[:,:2],cmd[:,0]);step_count+=placement['valid'].sum(1)
''' +s[b:];compile(s,str(p),'exec');p.write_text(s)
# Label the deployment goal only; actuator/phase/mirror graph is the baseline graph.
p=B/'tools/stage_entry.py';s=p.read_text();s=s.replace("float(config(ck).env.get('step_goal_m',.1))","float(config(ck).env.get('step_goal_m',config(ck).env.get('fast_step_goal_m',.1)))")
s=s.replace("    atomic(dest/f'{ID}_IO_CONTRACT.json',contract)","    contract.update(model_version='2.0.2',measurement_revision='v201_route_contact_measurement_20261108',IMU_body_position_m=CONTRACT['imu_body_position_m'],IMU_physical_to_body_quaternion_wxyz=[0,0,0,1])\n    atomic(dest/f'{ID}_IO_CONTRACT.json',contract)")
p.write_text(s)
print('MEASUREMENT_CONSUMERS_PATCHED_ONLY')

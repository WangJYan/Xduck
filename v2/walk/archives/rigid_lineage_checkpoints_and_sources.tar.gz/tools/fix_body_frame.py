"""Correct post-P03 body poses without changing model, observations or dynamics."""
from pathlib import Path
import hashlib
import json

B = Path(__file__).resolve().parents[1]

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def apply():
    changes = {}
    for p in sorted((B/'workspace').glob('*/project/src/unilab/base/backend/mjwarp/xduck_gf.py')):
        before = p.read_text()
        if '_body_xpos_cache' in before:
            continue
        source = before.replace(
            "        self._site_xpos_cache=np.asarray(self._device_data.site_xpos.numpy(),dtype=np.float32)",
            "        self._site_xpos_cache=np.asarray(self._device_data.site_xpos.numpy(),dtype=np.float32)\n"
            "        # MuJoCo frame sensors with objtype=body report the INERTIAL frame.\n"
            "        # Collision vertices and foot sites use the body frame (xpos/xquat).\n"
            "        self._body_xpos_cache=np.asarray(self._device_data.xpos.numpy(),dtype=np.float32)\n"
            "        self._body_xquat_cache=np.asarray(self._device_data.xquat.numpy(),dtype=np.float32)"
        ).replace(
            "return np.stack([self.get_sensor_data('track_pos_w_'+self._body_pose_names[int(i)]) for i in body_ids],axis=1)",
            "return self._body_xpos_cache[:,np.asarray(body_ids,dtype=np.int32)]"
        ).replace(
            "return np.stack([self.get_sensor_data('track_quat_w_'+self._body_pose_names[int(i)]) for i in body_ids],axis=1)",
            "return self._body_xquat_cache[:,np.asarray(body_ids,dtype=np.int32)]"
        )
        assert source != before and source.count('_body_xpos_cache') == 2 and source.count('_body_xquat_cache') == 2, p
        compile(source, str(p), 'exec')
        old = digest(p)
        p.write_text(source)
        changes[str(p.relative_to(B))] = {'before': old, 'after': digest(p)}
    (B / 'audit/BODY_FRAME_PREPARATION_CHANGES.json').write_text(json.dumps(changes, indent=2))
    print(json.dumps(changes, indent=2))

if __name__ == '__main__':
    apply()

from pathlib import Path
import json,hashlib
from omegaconf import OmegaConf
B=Path(__file__).resolve().parents[1];OLD=B.parent/'xduck_2_0_2_v201route_step13_20261108';late={'P09','P10','P11','P12','P13'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def flat(d,p=''):
 out={}
 if isinstance(d,dict):
  for k,v in d.items():out.update(flat(v,p+'.'+k if p else k))
 else:out[p]=d
 return out
allowed={'env.fast_step_start_m','env.fast_step_goal_m','env.fast_step_minimum_m','env.fast_step_maximum_m','env.step_goal_m'};rows=[]
plan=json.loads((B/'route_plan.json').read_text());oldplan=json.loads((OLD/'route_plan.json').read_text())
for n,old in zip(plan['nodes'],oldplan['nodes']):
 for k in ['id','parent','num_envs','rollout_steps','selected_updates_in_this_stage','optimizer','seed']:assert n.get(k)==old.get(k),(n['id'],k)
 a=flat(OmegaConf.to_container(OmegaConf.load(OLD/'runs'/n['id']/'TRAINING_CONFIG.yaml'),resolve=True));b=flat(OmegaConf.to_container(OmegaConf.load(B/'runs'/n['id']/'TRAINING_CONFIG.yaml'),resolve=True));changes=[]
 for k in set(a)|set(b):
  x=a.get(k);y=b.get(k)
  if isinstance(x,str):x=x.replace(str(OLD),'BRANCH')
  if isinstance(y,str):y=y.replace(str(B),'BRANCH')
  if x!=y:assert n['id'] in late and k in allowed,(n['id'],k,x,y);changes.append(k)
 if n['id'] in late:
  cfg=OmegaConf.load(B/'runs'/n['id']/'TRAINING_CONFIG.yaml');assert cfg.env.fast_step_goal_m==.1
  if n['id']!='P09':assert cfg.env.step_goal_m==.1
  assert not list((B/'runs'/n['id']).rglob('*.pt'))
 rows.append(dict(stage=n['id'],num_envs=n['num_envs'],updates=n['selected_updates_in_this_stage'],changes=sorted(changes),inherited=n['id'] not in late))
 for name in ['balance_objective.py','task_adapter.py','mirror_policy.py','policy_setup.py','head_freeze.py','step_measurement.py']:
  a=OLD/'workspace'/n['run']/name;b=B/'workspace'/n['run']/name
  if a.exists():assert a.read_bytes()==b.read_bytes(),(n['id'],name)
for path,g in json.loads((B/'audit/ANCESTRY_IMPORTS.json').read_text())['checkpoints'].items():assert sha(B/path)==g['sha256']==sha(Path(g['source_checkpoint']))
assert sha(B/'physics/effective_training.mjb')==sha(OLD/'physics/effective_training.mjb')
for name in ['HOME_nominal_bank.npz','new_standing_bank.npz','heldout_standing_bank.npz']:assert sha(B/'inputs'/name)==sha(OLD/'inputs'/name)
r=dict(status='PASS',start_stage='P09',parent_stage='P07',inherited_PPO_updates=1642,new_PPO_updates=1800,goal_m=.10,configuration_changes_only=sorted(allowed),physics_banks_and_detector_unchanged=True,inherited_checkpoint_bytes_unchanged=True,reward_shapes_weights_samplers_and_optimizer_unchanged=True,stages=rows)
(B/'audit/TEN_CM_RESTART_SCOPE.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))

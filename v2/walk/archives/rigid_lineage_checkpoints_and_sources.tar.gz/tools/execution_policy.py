"""User-selected handling of performance measurements, separate from data integrity."""
from pathlib import Path
import json

def performance_gates_enabled(branch):
    path=Path(branch)/'audit/EXECUTION_POLICY.json'
    return json.loads(path.read_text()).get('enforce_performance_gates',True) if path.exists() else True

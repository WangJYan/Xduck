"""Check actual GPU body frames/sole geometry against CPU FK, including COM DR."""
from pathlib import Path
import sys
import json
import numpy as np
import mujoco
import torch

B=Path(__file__).resolve().parents[1]
entry=B/'tools/stage_entry.py'
sys.path.insert(0,str(B/'tools'))
sys.argv=[str(entry),'--stage','P05','--mode','collect']
g={'__file__':str(entry),'__name__':'body_frame_validation'}
exec(compile(entry.read_text().split('torch.set_num_threads(2);')[0],str(entry),'exec'),g)
import warp as wp
torch.set_num_threads(2);torch.manual_seed(61106500);np.random.seed(61106500);wp.init()
e=g['setup_env'](g['config'](),16)
try:
    e.init_state();e.set_autoreset(False)
    backend=e._backend
    model=mujoco.MjModel.from_binary_path(str(B/'physics/effective_training.mjb'))
    data=mujoco.MjData(model)
    rng=np.random.default_rng(71107)
    q=backend.get_physics_state()[:,1:22].copy()
    q[:,7:]+=rng.uniform(-.08,.08,(16,14));q[:,2]+=.05
    backend.set_state(np.arange(16,dtype=np.int32),q,np.zeros((16,20)),None)
    e._refresh_foot_height()
    body_ids=np.arange(model.nbody,dtype=np.int32)
    pos,quat=backend.get_body_pose_w(body_ids)
    geom_pos=backend._device_model.geom_pos.numpy()
    geom_quat=backend._device_model.geom_quat.numpy()
    com=backend._device_model.body_ipos.numpy()
    max_pos=max_quat=max_clearance=old_frame_error=0.
    corners=np.array([(x,y,z) for x in (-1,1) for y in (-1,1) for z in (-1,1)])
    expected=np.zeros((16,2))
    for case in range(16):
        model.geom_pos[:]=geom_pos[case];model.geom_quat[:]=geom_quat[case];model.body_ipos[:]=com[case]
        data.qpos[:]=q[case];mujoco.mj_forward(model,data)
        max_pos=max(max_pos,float(abs(pos[case]-data.xpos).max()))
        max_quat=max(max_quat,float(np.minimum(abs(quat[case]-data.xquat).max(1),abs(quat[case]+data.xquat).max(1)).max()))
        old_frame_error=max(old_frame_error,float(abs(data.xipos[e._sole_body_ids]-data.xpos[e._sole_body_ids]).max()))
        for side,name in enumerate(['left','right']):
            heights=[]
            for suffix in ['_foot_collision','_foot_pad']:
                gid=model.geom(name+'_foot_collision').id if suffix=='_foot_collision' else model.geom('train_'+name+suffix).id
                if suffix=='_foot_collision':
                    k=model.geom_dataid[gid];vertices=model.mesh_vert[model.mesh_vertadr[k]:model.mesh_vertadr[k]+model.mesh_vertnum[k]]
                else:vertices=corners*model.geom_size[gid]
                world=vertices@data.geom_xmat[gid].reshape(3,3).T+data.geom_xpos[gid]
                heights.append(world[:,2].min())
            expected[case,side]=max(0.,min(heights)-e._ground_z)
    max_clearance=float(abs(e._foot_height-expected).max())
    assert max_pos<2e-6 and max_quat<2e-6 and max_clearance<2e-6,(max_pos,max_quat,max_clearance)
    assert old_frame_error>.01,old_frame_error
    before=e._foot_height.copy();q[:,2]+=.03
    backend.set_state(np.arange(16,dtype=np.int32),q,np.zeros((16,20)),None);e._refresh_foot_height()
    lift_error=float(abs(e._foot_height-before-.03).max());assert lift_error<2e-6,lift_error
    report=dict(status='PASS',worlds=16,COM_randomization_checked=True,body_position_max_error_m=max_pos,body_quaternion_max_error=max_quat,sole_clearance_max_error_m=max_clearance,three_cm_lift_max_error_m=lift_error,old_inertial_frame_position_error_m=old_frame_error,model_sha256=g['sha'](B/'physics/effective_training.mjb'))
    g['atomic'](B/'audit/BODY_FRAME_VALIDATION.json',report);print(json.dumps(report,indent=2),flush=True)
finally:e.close()

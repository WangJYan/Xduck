"""New-lineage training worker. Historical checkpoints are never loaded here."""
from pathlib import Path
import argparse, json, os, sys, time, hashlib, inspect, copy
import numpy as np
import torch
from torch import nn
from omegaconf import OmegaConf

B=Path(__file__).resolve().parents[1]
PLAN=json.loads((B/'route_plan.json').read_text())
CONTRACT=json.loads((B/'audit/MODEL_CONTRACT.json').read_text())
NODES={n['id']:n for n in PLAN['nodes']}
ap=argparse.ArgumentParser();ap.add_argument('--stage',required=True,choices=list(NODES));ap.add_argument('--mode',choices=['smoke','train','bank','collect','bootstrap','bc','export','evaluate','qualify'],required=True);ap.add_argument('--envs',type=int);ap.add_argument('--checkpoint');ap.add_argument('--teacher');ap.add_argument('--dataset');ap.add_argument('--fixture',action='store_true');ap.add_argument('--bank-dr',action='store_true');ap.add_argument('--seed',type=int);ap.add_argument('--resume');args=ap.parse_args()
ID=args.stage;NODE=NODES[ID];R=B/'runs'/ID;S=B/'workspace'/NODE['run']
# The final archived rigid owner includes the audited 300/600/900 schedule.
# Its rigid mechanics/rewards also cover P00; the earliest snapshot lacks that schema.
PROJECT=(B/'workspace'/NODES['P13']['run']/'project') if ID in ['P00','P01','P02','P03'] else S/'project'
sys.path[:0]=[str(PROJECT/'src'),str(PROJECT/'scripts'),str(S)]
import train_rsl_rl as E
from unilab.training.rsl_rl import normalize_ppo_train_cfg,RslRlVecEnvWrapper
from rsl_rl.runners import OnPolicyRunner
import warp as wp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def atomic(p,obj):
    p=Path(p);t=p.with_name(p.name+'.tmp');t.write_text(json.dumps(obj,indent=2));os.replace(t,p)
def load_new(path,fixture=False):
    p=Path(path).resolve()
    assert p.is_relative_to(B/'runs') or (fixture and p.is_relative_to(B/'audit')),p
    ck=torch.load(p,map_location='cpu',weights_only=False)
    meta=ck.get('infos',{}).get('new_lineage',{})
    if meta.get('branch')!=B.name:
        ledger=json.loads((B/'audit/ANCESTRY_IMPORTS.json').read_text())['checkpoints']
        grant=ledger.get(str(p.relative_to(B)))
        assert grant and grant['stage'] in ['P00','P01','P02','P03','P05','P06','P07'],meta
        assert meta.get('branch')==grant['source_branch'] and sha(p)==grant['sha256'],meta
    assert meta.get('model_sha256')==CONTRACT['model_sha256'],meta
    if not fixture:assert meta.get('mode')=='train',meta
    if not fixture:assert meta.get('step_measurement_revision')=='v201_route_contact_measurement_20261108',meta
    revision=B/'audit/ACTIVE_REVISION.json'
    if not fixture and revision.exists() and meta.get('stage') not in ['P00','P01','P02','P03']:
        assert meta.get('body_frame_revision')==json.loads(revision.read_text())['revision'],meta
    style=B/'audit/GAIT_STYLE_CONTRACT.json'
    if not fixture and args.mode in ['train','collect','bootstrap','bc'] and style.exists():
        assert meta.get('gait_style_revision')==json.loads(style.read_text())['revision'],'Old gait checkpoints are audit references only; restart P00 with the corrected geometry and style objective.'
    step_contract=B/'audit/STEP_TARGET_CONTRACT.json'
    if not fixture and args.mode in ['train','collect','bootstrap','bc'] and step_contract.exists():
        target=json.loads(step_contract.read_text())
        if meta.get('stage') in target['validation_stages']:
            assert meta.get('step_target_revision')==target['revision'],'Wrong-step-target checkpoint cannot enter the corrected 15cm route.'
    return ck

class Norm(nn.Module):
    def __init__(self,sd):
        super().__init__();self.register_buffer('mean',sd['obs_normalizer._mean'].clone());self.register_buffer('std',sd['obs_normalizer._std'].clone())
    def forward(self,x):return (x-self.mean)/(self.std+.01)

class Decoder(nn.Module):
    def __init__(self,ck):
        super().__init__();sd=ck['actor_state_dict'];self.normal=Norm(sd)
        net=nn.Sequential(nn.Linear(61,512),nn.ELU(),nn.Linear(512,256),nn.ELU(),nn.Linear(256,128),nn.ELU(),nn.Linear(128,14))
        if 'mlp.blend' in sd:
            # Use the source graph that originally produced this NEW checkpoint.
            stage=ck['infos']['new_lineage']['stage'];source=B/'workspace'/NODES[stage]['run']/'mirror_policy.py'
            import importlib.util
            spec=importlib.util.spec_from_file_location('teacher_mirror_'+stage,source);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
            kw={'heading_gain':float(sd['mlp.heading_gain'])} if 'heading_gain' in inspect.signature(mod.MirrorMLP).parameters else {}
            self.net=mod.MirrorMLP(net,sd['obs_normalizer._mean'],sd['obs_normalizer._std'],float(sd['mlp.blend']),**kw)
            self.net.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')},strict=True)
        else:
            self.net=net;net.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')},strict=True)
    def forward(self,x):return self.net(self.normal(x))

ENCODING=None
def config(parent=None):
    global ENCODING
    c=OmegaConf.load(R/'TRAINING_CONFIG.yaml')
    if (B/'audit/GAIT_STYLE_CONTRACT.json').exists() and 'toe_heading_reward' in c.env:
        c.env.toe_heading_reward=False
    from step_target import configuration
    target_contract=configuration(B,ID,c)
    if args.mode=='train' and target_contract is not None:assert target_contract['status']=='VALIDATED'
    if args.fixture and 'anchor_dataset' in c.algo.algorithm:c.algo.algorithm.anchor_dataset=str(B/'audit'/f'{ID}_anchor_fixture.npz')
    if ID in ['P10','P11','P12','P13'] and parent is not None:
        sd=parent['actor_state_dict'];mean=sd['obs_normalizer._mean'].reshape(-1).numpy();scale=sd['obs_normalizer._std'].reshape(-1).numpy()+.01
        c.env.phase_mean=mean[[59,60]].tolist();c.env.phase_scale=scale[[59,60]].tolist()
        ENCODING=(mean,scale)
    return c

def setup_env(c,n):
    E.ensure_registries()
    if ID=='P09':from unilab.envs.locomotion.xduck_gf43x40.direct_step import DirectStepEnv
    if ID in ['P10','P11','P12','P13']:from unilab.envs.locomotion.xduck_gf43x40.balanced_env import BalancedPhaseEnv
    env=E.create_env(c,num_envs=n,env_cfg_override=E.build_ppo_env_cfg_override(c))
    if ENCODING is not None and hasattr(env,'_phase'):
        mean,scale=ENCODING;p=env._phase
        if hasattr(p,'start_mean'):p.start_mean=float(mean[56]);p.start_scale=float(scale[56]);p.heading_mean=mean[57:59].copy();p.heading_scale=scale[57:59].copy()
        if hasattr(p,'motion_mean'):p.motion_mean=mean[51:56].copy();p.motion_scale=scale[51:56].copy()
    if (style_contract:=B/'audit/GAIT_STYLE_CONTRACT.json').exists():
        from gait_style import install
        install(env,style_contract)
    from step_target import configuration
    if (target_contract:=configuration(B,ID,c)) is not None:
        goal=target_contract['stage_step_goals_m'][ID]
        assert abs(env.curriculum.goal-goal)<1e-9 and abs(env._phase.goal-goal)<1e-9
    return env

def make_runner(e,c,n,smoke=False):
    wrapped=RslRlVecEnvWrapper(e,device='cuda');tc=normalize_ppo_train_cfg(OmegaConf.to_container(c.algo,resolve=True));E.apply_ppo_runtime_flags(tc,c,training_enabled=True)
    tc['logger']='none' if smoke else 'tensorboard';tc.setdefault('runner',{})['logger']=tc['logger']
    return wrapped,OnPolicyRunner(wrapped,tc,log_dir=None if smoke else str(R/'ppo_run'),device='cuda')

def upgrade_actor(actor,sd):
    mirror='mlp.blend' in sd
    if mirror:
        from mirror_policy import MirrorMLP
        kw={'heading_gain':float(sd.get('mlp.heading_gain',torch.tensor(0.)))} if 'heading_gain' in inspect.signature(MirrorMLP).parameters else {}
        actor.mlp=MirrorMLP(actor.mlp,sd['obs_normalizer._mean'],sd['obs_normalizer._std'],float(sd['mlp.blend']),**kw).to(actor.obs_normalizer._mean.device)
    missing=actor.load_state_dict(sd,strict=False)
    allowed={'mlp.heading_gain','mlp.yaw_obs_mean','mlp.yaw_obs_scale','mlp.side_stand','mlp.side_enabled','mlp.side_action_mask','mlp.side_head.0.weight','mlp.side_head.0.bias','mlp.side_head.2.weight','mlp.side_head.2.bias'}
    assert not missing.unexpected_keys and set(missing.missing_keys)<=allowed,missing
    if ID=='P05':
        # Clean roll seed: fixed HOME hip roll, not an old model's absolute angle.
        with torch.no_grad():actor.mlp[-1].weight[[1,10]]=0;actor.mlp[-1].bias[[1,10]]=0
    if ID=='P10' and not mirror:
        from policy_setup import initialize
        initialize(actor)
    if ID=='P12':
        from mirror_policy import MirrorMLP
        base=actor.mlp.base;normal=actor.obs_normalizer;mean=normal._mean.reshape(-1);scale=normal._std.reshape(-1)+.01
        with torch.no_grad():base[0].bias.add_(base[0].weight[:,[56,57,58]]@(-mean[[56,57,58]]/scale[[56,57,58]]));base[0].weight[:,[56,57,58]]=0
        actor.mlp=MirrorMLP(base,normal._mean,normal._std,1.,heading_gain=.8)
    if ID=='P13':
        base=actor.mlp.base;normal=actor.obs_normalizer;mean=normal._mean.reshape(-1);scale=normal._std.reshape(-1)+.01
        with torch.no_grad():
            base[0].bias.add_(base[0].weight[:,51:56]@(-mean[51:56]/scale[51:56]));base[0].weight[:,51:56]=0
            actor.mlp.side_enabled.fill_(1.);actor.mlp.side_stand.zero_()
    if ID not in ['P00','P01','P02','P03']:
        actor.obs_normalizer.eval();actor.distribution.std_param.requires_grad_(False)
        exploration={'P05':.25,'P06':.25,'P07':.32,'P09':.25}.get(ID,.15)
        with torch.no_grad():actor.distribution.std_param.fill_(exploration)
    if ID in ['P10','P11','P12','P13']:
        from head_freeze import install_head_zero
        install_head_zero(actor,.15)

FIELDS=['geom_pos','geom_quat','jnt_stiffness','dof_damping','body_mass','body_inertia','body_ipos','geom_friction','dof_armature']
def collect_bank():
    assert ID=='P00'
    c=config();c.env.stage_schedule_enabled=args.bank_dr;c.env.domain_rand.velocity_pushes=False;c.env.sole_tilt_dr_enabled=args.bank_dr;c.env.noise_config.level=0.;c.env.max_episode_seconds=30.
    c.env.reference_weight_after300=0.;c.env.cadence_weight_after300=0.
    n=args.envs or 64;e=setup_env(c,n)
    try:
        if args.bank_dr:
            e.step_counter=900*24;e._apply_stage_schedule()
            e._sole_rng=np.random.default_rng((args.seed or NODE['seed'])+2)
        e.init_state();e.set_autoreset(False)
        # Collect standing states from the user's exact HOME, not the old task's
        # random pose sampler. Motor-zero remains the model's untouched qpos0.
        ids=np.arange(n,dtype=np.int32)
        e._backend.set_state(ids,np.tile(CONTRACT['home_qpos'],(n,1)),np.zeros((n,20)),None)
        e._motor.reset(ids)
        e._current_action_target[:]=e.default_angles;e._previous_action_target[:]=e.default_angles
        def hold(st):st.info['commands'][:]=0
        e._maybe_resample_commands=hold
        snapshots=[];metrics=[]
        for tick in range(250):
            result=e.step(np.zeros((n,14)))
            assert np.isfinite(result.reward).all()
            if tick not in [149,199,249]:continue
            phi=e._backend.get_physics_state();q=phi[:,1:22];v=phi[:,22:42]
            tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,4]**2+q[:,5]**2),-1,1)));vel=e.get_local_linvel()
            good=(tilt<6)&(np.linalg.norm(vel[:,:2],axis=1)<.02)&(q[:,2]>CONTRACT['fall_height_m'])
            metrics.append(dict(tick=tick+1,accepted=int(good.sum()),median_height_m=float(np.median(q[:,2])),max_tilt_deg=float(tilt.max())))
            pos=np.stack([e._backend.get_sensor_data(s) for s in e.cfg.sensor.feet_pos],axis=1)
            saved={k:getattr(e._backend._device_model,k).numpy()[good].copy() for k in FIELDS}
            saved.update(qpos=q[good].copy(),qvel=v[good].copy(),target=e._current_action_target[good].copy(),initial_width=np.abs(pos[good,0,1]-pos[good,1,1]),linvel=vel[good].copy())
            for k in ['encoder_bias','imu_rotation','sole_angles','sole_delta_quat']:saved[k]=getattr(e,'_'+k)[good].copy()
            snapshots.append(saved);print('HOME_HOLD',metrics[-1],flush=True)
        bank={k:np.concatenate([s[k] for s in snapshots]) for k in snapshots[0]}
        assert len(bank['qpos'])>=n,metrics
        path=Path(args.dataset) if args.dataset else B/'inputs/new_standing_bank.npz';np.savez_compressed(path,**bank)
        audit=B/'audit/STANDING_BANK.json' if path.name=='new_standing_bank.npz' else path.with_suffix('.json')
        atomic(audit,dict(status='PASS',model_sha256=CONTRACT['model_sha256'],bank_sha256=sha(path),frames=len(bank['qpos']),held_HOME_joint_targets=True,physically_settled=True,domain_randomized=args.bank_dr,seed=args.seed or NODE['seed'],median_height_m=float(np.median(bank['qpos'][:,2])),metrics=metrics))
    finally:e.close()

def parent_path():
    if args.checkpoint:return Path(args.checkpoint)
    if NODE['parent'] is None:return None
    s=json.loads((B/'runs'/NODE['parent']/'COMPLETE.json').read_text());p=B/s['checkpoint']
    assert sha(p)==s['sha256']
    return p

def curriculum_snapshot(e):
    snap=dict(env_steps_per_env=int(e.step_counter),iteration=int(e.step_counter//24),dr_multiplier=float(getattr(e,'_dr_multiplier',1.)),air_time_threshold_s=float(e.cfg.reward_config.air_time_threshold_min),reference_weight=float(getattr(e,'_reference_weight',0)),cadence_weight=float(getattr(e,'_cadence_weight',0)))
    if hasattr(e,'curriculum'):snap['task']=e.curriculum.snapshot()
    if hasattr(e,'_loss_update'):snap['local_loss_update']=int(e._loss_update)
    return snap

def train():
    smoke=args.mode=='smoke';path=parent_path();parent=load_new(path,args.fixture) if path else None
    incoming_parent_path=path;resume_updates=0
    if args.resume:
        assert ID in ['P00','P01','P02','P03'],'Only native early-stage resumes have been implemented and verified'
        path=Path(args.resume);parent=load_new(path,args.fixture)
        meta=parent['infos']['new_lineage'];assert meta['stage']==ID
        resume_updates=int(meta['completed_updates']);assert int(parent['iter'])+1==resume_updates
        assert 0<resume_updates<NODE['selected_updates_in_this_stage']
    # Prepared supervised seeds must have explicit current-lineage provenance.
    seed=R/'seed.pt'
    if seed.exists() and not smoke and not args.resume:parent=load_new(seed);path=seed
    c=config(parent);n=args.envs or (32 if smoke else int(c.algo.num_envs))
    if not smoke and 'anchor_dataset' in c.algo.algorithm:
        anchor=Path(c.algo.algorithm.anchor_dataset);info=json.loads(anchor.with_suffix('.json').read_text())
        assert info['status']=='PASS' and info['dataset_sha256']==sha(anchor) and info['model_sha256']==CONTRACT['model_sha256']
    if smoke:c.algo.algorithm.num_mini_batches=min(int(c.algo.algorithm.num_mini_batches),4)
    e=setup_env(c,n)
    try:
        wrapped,runner=make_runner(e,c,n,smoke)
        if parent:
            upgrade_actor(runner.alg.actor,parent['actor_state_dict']);runner.alg.critic.load_state_dict(parent['critic_state_dict'],strict=True)
            if args.resume or NODE['optimizer']=='resume':
                runner.alg.optimizer.load_state_dict(parent['optimizer_state_dict'])
                # Adaptive PPO tracks a Python scalar in addition to optimizer groups.
                runner.alg.learning_rate=float(runner.alg.optimizer.param_groups[0]['lr'])
            elif ID not in ['P13']:assert not runner.alg.optimizer.state
            if args.resume or ID in ['P01','P02','P03']:
                old=int(e.step_counter);e.step_counter=int(parent['infos']['unilab_progress']['env_steps_per_env']);e._next_push_step+=e.step_counter-old;e._update_curriculum()
            if args.resume:
                runner.current_learning_iteration=resume_updates
                for k,v in parent['actor_state_dict'].items():assert torch.equal(runner.alg.actor.state_dict()[k].cpu(),v.cpu()),k
                assert len(runner.alg.optimizer.state)==len(parent['optimizer_state_dict']['state'])>0
                assert runner.alg.optimizer.param_groups[0]['lr']==parent['optimizer_state_dict']['param_groups'][0]['lr']
                atomic(B/'audit'/f'{ID}_RESUME_{args.mode}.json',dict(status='PASS_RESTORED',checkpoint=str(path),checkpoint_sha256=sha(path),restored_updates=resume_updates,actor_exact=True,optimizer_state_entries=len(runner.alg.optimizer.state),learning_rate=runner.alg.optimizer.param_groups[0]['lr'],environment_progress=int(e.step_counter),environment_reset_on_process_resume=True))
        if ID=='P13':runner.alg.optimizer.add_param_group({'params':list(runner.alg.actor.mlp.side_head.parameters()),'task_lr_multiplier':10.})
        # Frozen normalizers must stay frozen through PPO train_mode().
        if parent and ID not in ['P00','P01','P02','P03']:
            original_mode=runner.alg.train_mode
            def frozen_mode():original_mode();runner.alg.actor.obs_normalizer.eval()
            runner.alg.train_mode=frozen_mode
        obs,_=wrapped.reset();assert obs['actor'].shape==(n,61)
        if parent and ID in ['P10','P12','P13']:
            x=obs['actor'].clone();legacy=x.clone();rows=torch.ones(n,dtype=torch.bool,device='cuda')
            if ID=='P10':legacy[:,59:61]=0
            if ID=='P12':
                normal=runner.alg.actor.obs_normalizer;mean=normal._mean.reshape(-1);scale=normal._std.reshape(-1)+.01
                error=torch.atan2((x[:,58]-mean[58])/scale[58],(x[:,57]-mean[57])/scale[57])
                legacy[:,56:59]=0;legacy[:,50]=(x[:,50]-.8*error).clamp(-.6,.6)
            if ID=='P13':
                legacy[:,51:56]=0;normal=runner.alg.actor.obs_normalizer;rows=((x[:,51]-normal._mean.reshape(-1)[51])/(normal._std.reshape(-1)[51]+.01))<.5
            teacher=Decoder(parent).to('cuda').eval()
            with torch.inference_mode():expected=teacher(legacy);actual=runner.alg.actor.mlp(runner.alg.actor.obs_normalizer(x))
            legs=[0,1,2,3,4,9,10,11,12,13];error=float(abs(actual[rows][:,legs]-expected[rows][:,legs]).max())
            assert error<3e-5,(ID,'seed transform parity',error)
            atomic(B/'audit'/f'{ID}_SEED_PARITY_{args.mode}.json',dict(status='PASS',leg_action_max_error=error,parent_sha256=sha(path),model_sha256=CONTRACT['model_sha256']))
            del teacher
        OmegaConf.save(c,B/'audit'/f'{ID}_EFFECTIVE_{args.mode}.yaml' if smoke else R/'EFFECTIVE_CONFIG.yaml')
        assert np.allclose(e.default_angles,CONTRACT['home_joint_qpos']),e.default_angles
        assert np.allclose(e._target_low,np.array(CONTRACT['joint_limits_rad'])[:,0]+1e-5)
        if ID in ['P10','P11','P12','P13']:
            assert np.allclose(e._phase.mean,c.env.phase_mean) if hasattr(e._phase,'mean') else True
        initial=curriculum_snapshot(e);total=resume_updates+2 if smoke else NODE['selected_updates_in_this_stage'];updates=resume_updates
        if smoke and ID=='P01':
            boundaries=[];restore=int(e.step_counter)
            for iteration,expected_dr,expected_air in [(299,1.,.1),(300,1.5,.14),(599,1.5,.14),(600,2.,.18),(899,2.,.18),(900,2.5,.22)]:
                e.step_counter=iteration*24;e._apply_stage_schedule();snap=curriculum_snapshot(e)
                assert abs(snap['dr_multiplier']-expected_dr)<1e-8 and abs(snap['air_time_threshold_s']-expected_air)<1e-8,snap
                assert snap['reference_weight']==(0. if iteration<300 else float(c.env.reference_weight_after300))
                boundaries.append(snap)
            e.step_counter=restore;e._apply_stage_schedule();atomic(B/'audit/EARLY_CURRICULUM_BOUNDARIES.json',dict(status='PASS',samples=boundaries))
        if smoke and ID=='P13':
            values=[]
            for u in [0,100,200,400]:
                e.set_loss_update(u);distance=float(e._phase.side_distance);assert abs(distance-(.04+.06*min(u/200,1)))<1e-8;values.append(dict(update=u,distance_m=distance))
            e.set_loss_update(0);atomic(B/'audit/LATE_CURRICULUM_BOUNDARIES.json',dict(status='PASS',samples=values))
        frozen={k:v.clone() for k,v in runner.alg.actor.obs_normalizer.state_dict().items()} if parent and ID not in ['P00','P01','P02','P03'] else None
        old_update=runner.alg.update
        def update():
            nonlocal updates
            values=old_update();updates+=1
            if hasattr(e,'set_loss_update'):e.set_loss_update(updates)
            if hasattr(e,'maybe_advance_curriculum'):e.maybe_advance_curriculum(updates)
            if ID=='P10':runner.alg.actor.mlp.set_update(updates,200)
            if ID in ['P11','P12','P13']:runner.alg.actor.mlp.blend.fill_(1.)
            if frozen:
                for k,v in runner.alg.actor.obs_normalizer.state_dict().items():assert torch.equal(v,frozen[k]),k
            if not smoke:atomic(R/'STATUS.json',dict(status='RUNNING',pid=os.getpid(),completed_updates=updates,total_updates=total,resumed_from_updates=resume_updates,curriculum=curriculum_snapshot(e),reset_guard_profile=getattr(e._backend,'_reset_guard_profile',{}),updated_unix=time.time()))
            print('NEW_LINEAGE_UPDATE',ID,updates,json.dumps(curriculum_snapshot(e)),flush=True)
            torch.cuda.synchronize();wp.synchronize_device()
            if torch.cuda.mem_get_info()[0]<7*1024**3:torch.cuda.empty_cache()
            return values
        runner.alg.update=update
        original_save=runner.save;last_saved={}
        def save(path_unused,infos=None):
            completed=updates
            if completed==0 or (completed%50 and completed!=total):return
            path=(B/'audit'/f'{ID}{"_resume" if args.resume else ""}_fixture.pt') if smoke else R/'ppo_run'/f'model_{completed-1}.pt';path.parent.mkdir(exist_ok=True)
            info=dict(infos or {});info['unilab_progress']=dict(version=1,env_steps_per_env=int(e.step_counter),next_iteration=int(runner.current_learning_iteration)+1)
            info['new_lineage']=dict(branch=B.name,model_sha256=CONTRACT['model_sha256'],stage=ID,mode='fixture' if smoke else 'train',parent_sha256=sha(path_parent) if (path_parent:=path_for_parent) else None,completed_updates=completed,cumulative_updates=NODE['planned_cumulative_ppo_updates']-NODE['selected_updates_in_this_stage']+completed)
            if args.resume:info['process_resume']=dict(checkpoint=str(args.resume),checkpoint_sha256=sha(args.resume),updates=resume_updates,environment_was_reset=True)
            info['curriculum']=curriculum_snapshot(e)
            info['new_lineage']['step_measurement_revision']='v201_route_contact_measurement_20261108'
            if (revision:=B/'audit/ACTIVE_REVISION.json').exists():
                info['new_lineage']['body_frame_revision']=json.loads(revision.read_text())['revision']
            if (style_contract:=B/'audit/GAIT_STYLE_CONTRACT.json').exists():
                info['new_lineage']['gait_style_revision']=json.loads(style_contract.read_text())['revision']
            if (target_contract:=B/'audit/STEP_TARGET_CONTRACT.json').exists() and ID in ['P10','P11','P12','P13']:
                info['new_lineage']['step_target_revision']=json.loads(target_contract.read_text())['revision']
                info['new_lineage']['step_goal_m']=float(c.env.step_goal_m)
            tmp=path.with_suffix('.pt.tmp');original_save(str(tmp),infos=info);os.replace(tmp,path);last_saved.update(checkpoint=str(path.relative_to(B)),sha256=sha(path),completed_updates=completed)
        path_for_parent=incoming_parent_path if args.resume else path
        runner.save=save;runner.cfg['save_interval']=1
        atomic(B/'audit'/f'{ID}_BINDING_{args.mode}.json',dict(mode=args.mode,pid=os.getpid(),stage=ID,model_sha256=CONTRACT['model_sha256'],parent=str(path) if path else None,parent_sha256=sha(path) if path else None,optimizer=NODE['optimizer'],num_envs=n,rollout_steps=24,updates=total,initial_curriculum=initial,HOME_reference=True))
        # Check finite observations and actions before taking optimizer steps.
        for tick in range(8 if smoke else 0):
            with torch.inference_mode():a=runner.alg.actor.mlp(runner.alg.actor.obs_normalizer(obs['actor']))
            obs,reward,done,_=wrapped.step(a)
            assert torch.isfinite(obs['actor']).all() and torch.isfinite(reward).all() and torch.isfinite(a).all()
        # Preflight steps must not shift curriculum update boundaries.
        if smoke:
            e.step_counter=initial['env_steps_per_env'];obs,_=wrapped.reset()
        runner.learn(num_learning_iterations=total-resume_updates,init_at_random_ep_len=False)
        assert updates==total,updates
        save('',{})
        if not smoke:
            atomic(R/'COMPLETE.json',dict(status='COMPLETE',**last_saved,stage=ID,curriculum=curriculum_snapshot(e),model_sha256=CONTRACT['model_sha256']))
        else:atomic(B/'audit'/f'{ID}{"_RESUME" if args.resume else ""}_SMOKE.json',dict(status='PASS',updates=updates,restored_updates=resume_updates,additional_updates=updates-resume_updates,num_envs=n,initial_curriculum=initial,final_curriculum=curriculum_snapshot(e),**last_saved))
    finally:e.close()

def export():
    dest=B/'audit/exports_fixture' if args.fixture else B/'exports';dest.mkdir(exist_ok=True)
    path=parent_path();ck=load_new(path,args.fixture);actor=Decoder(ck).eval();output=dest/f'{ID}.onnx'
    torch.onnx.export(actor,torch.zeros(1,61),str(output),input_names=['obs'],output_names=['actions'],opset_version=17,dynamo=False)
    import onnxruntime as ort
    opt=ort.SessionOptions();opt.intra_op_num_threads=1;s=ort.InferenceSession(str(output),sess_options=opt,providers=['CPUExecutionProvider'])
    x=np.random.default_rng(610).normal(0,.1,(32,61)).astype(np.float32)
    with torch.inference_mode():expect=actor(torch.tensor(x)).numpy()
    actual=np.concatenate([s.run(None,{'obs':row[None]})[0] for row in x]);err=float(abs(actual-expect).max());assert err<3e-5,err
    atomic(dest/f'{ID}.json',dict(mode='FIXTURE_ONLY' if args.fixture else 'TRAINED',checkpoint=str(path),checkpoint_sha256=sha(path),onnx_sha256=sha(output),parity_error=err,model_contract=CONTRACT))
    sd=ck['actor_state_dict'];mean=sd['obs_normalizer._mean'].reshape(-1).numpy();scale=sd['obs_normalizer._std'].reshape(-1).numpy()+.01
    contract=dict(stage=ID,observation_dim=61,action_dim=14,normalization_inside_onnx=True,external_normalization=False,observation_mean=mean.tolist(),observation_scale=scale.tolist(),policy_reference_qpos=CONTRACT['home_joint_qpos'],motor_zero_qpos=CONTRACT['motor_zero_qpos'],joint_limits_qpos_rad=CONTRACT['joint_limits_rad'],physical_action_scale_rad=CONTRACT['physical_scale_rad'],motor_position_feedback_to_qpos='motor_position_rad + motor_zero_qpos',action_to_qpos='clip(HOME + raw_action * physical_action_scale_rad, joint_limits)',qpos_to_motor_target='qpos - motor_zero_qpos',IMU_physical_to_body_rotation=CONTRACT['physical_imu_to_body_rotation'],body_yaw_required=ID in ['P12','P13'],body_xy_or_body_velocity_required=ID=='P13',heading_hold=False,phase_mean=mean[[59,60]].tolist(),phase_scale=scale[[59,60]].tolist(),step_goal_m=float(config(ck).env.get('step_goal_m',config(ck).env.get('fast_step_goal_m',.1))),task_adapter_required=ID in ['P10','P11','P12','P13'])
    contract.update(model_version='2.0.2',measurement_revision='v201_route_contact_measurement_20261108',IMU_body_position_m=CONTRACT['imu_body_position_m'],IMU_physical_to_body_quaternion_wxyz=[0,0,0,1])
    atomic(dest/f'{ID}_IO_CONTRACT.json',contract)
    if ID=='P13':
        import shutil
        for name in ['task_adapter.py','heading_adapter.py','speed_history.py']:shutil.copy2(S/name,dest/name)
        (dest/'adapter_factory.py').write_text('''import json,numpy as np
from pathlib import Path
from task_adapter import TaskAdapter
def make_adapter(n):
 c=json.loads(Path(__file__).with_name("P13_IO_CONTRACT.json").read_text());m=np.array(c["observation_mean"]);s=np.array(c["observation_scale"])
 a=TaskAdapter(n,c["phase_mean"],c["phase_scale"],goal=c["step_goal_m"],variable=True)
 a.start_mean=m[56];a.start_scale=s[56];a.heading_mean=m[57:59];a.heading_scale=s[57:59];a.motion_mean=m[51:56];a.motion_scale=s[51:56]
 return a
''')

torch.set_num_threads(2);torch.manual_seed(int(args.seed or NODE['seed']));np.random.seed(int(args.seed or NODE['seed']));wp.init();wp.set_mempool_release_threshold('cuda:0',0)
if args.mode=='bank':collect_bank()
elif args.mode in ['smoke','train']:train()
elif args.mode=='export':export()
elif args.mode=='qualify':
    from policy_validation import run
    run(globals())
elif args.mode=='evaluate':
    from evaluation import run
    run(globals())
else:
    # Dataset and supervised operations are implemented in a separately audited worker.
    from supervised import run
    run(globals())

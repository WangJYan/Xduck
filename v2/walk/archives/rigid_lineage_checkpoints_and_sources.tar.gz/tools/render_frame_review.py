from pathlib import Path
import os,csv,json,subprocess
os.environ.setdefault('MUJOCO_GL','egl')
import numpy as np,mujoco,imageio_ffmpeg
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parents[1];V=B/'videos';tag='P02_250_cum1151';old=B.parent/'xduck_2_0_2_repair13_20261108/videos';z=np.load(old/(tag+'_trace.npz'))
with (V/(tag+'_frame_review.csv')).open() as f:rows=[r for r in csv.DictReader(f) if r['scenario']=='forward']
assert len(rows)==1000
m=mujoco.MjModel.from_binary_path(str(B/'physics/effective_training.mjb'));d=mujoco.MjData(m);m.geom_pos[:]=z['geom_pos'][0];m.geom_quat[:]=z['geom_quat'][0];m.mat_rgba[:,3]=1;m.geom_rgba[:,3]=1;m.vis.global_.offwidth=960;m.vis.global_.offheight=720
renderer=mujoco.Renderer(m,height=720,width=960);opt=mujoco.MjvOption();opt.geomgroup[:]=[1,1,1,0,0,0];cam=mujoco.MjvCamera();cam.distance=1.3;cam.elevation=-12;font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
out=V/(tag+'_same_trajectory_measurement_review.mp4');ff=imageio_ffmpeg.get_ffmpeg_exe();enc=subprocess.Popen([ff,'-y','-loglevel','error','-f','rawvideo','-s','960x720','-pix_fmt','rgb24','-r','25','-i','-','-an','-c:v','libx264','-preset','veryfast','-threads','2','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
try:
 for tick in range(0,1000,2):
  d.qpos[:]=z['qpos'][tick,0];mujoco.mj_forward(m,d);w,x,y,zz=d.qpos[3:7];yaw=np.degrees(np.arctan2(2*(w*zz+x*y),1-2*(y*y+zz*zz)));cam.azimuth=yaw+135;cam.lookat[:]=d.qpos[:3];cam.lookat[2]=.31;renderer.update_scene(d,camera=cam,scene_option=opt);im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);r=rows[tick]
  draw.rectangle((0,0,960,139),fill=(15,24,35));lines=[f'SAME RECORDED TRAJECTORY | frame {tick}/999 | t={float(r["time_s"]):.2f}s | front45deg',f'Sole clearance L/R: {float(r["left_clearance_mm"]):.2f}/{float(r["right_clearance_mm"]):.2f} mm | contact: {r["left_contact"]}/{r["right_contact"]}',f'Contact-footprint span L/R: {float(r["left_length_cm"]):+.2f}/{float(r["right_length_cm"]):+.2f} cm (not a step without landing)',f'Placement flags L/R: {r["left_valid"]}/{r["right_valid"]} | P09 landing reward: {float(r["P09_landing_reward"]):+.5f}',f'13cm reference reward =12 | oracle error={float(r["oracle_error_m"]):.1e}m | CSV50Hz / video25fps']
  for i,line in enumerate(lines):draw.text((10,4+i*26),line,font=font,fill='white' if i<3 else '#ffe39b')
  enc.stdin.write(np.asarray(im).tobytes())
  if tick in [150,500,850]:im.save(V/f'frame_review_{tick:04d}.png')
finally:enc.stdin.close();rc=enc.wait();renderer.close()
assert rc==0;print(out)

from pathlib import Path
import json,re,hashlib
import numpy as np
from omegaconf import OmegaConf
B=Path(__file__).resolve().parents[1];BASE=B.parent/'xduck_2_0_1_no_flex_20261106';c=json.loads((B/'audit/MODEL_CONTRACT.json').read_text());old=json.loads((BASE/'audit/MODEL_CONTRACT.json').read_text());plan=json.loads((B/'route_plan.json').read_text());h=c['settled_standing_height_m'];oh=old['settled_standing_height_m'];edits=[]
for node in plan['nodes']:
 p=B/'runs'/node['id']/'TRAINING_CONFIG.yaml';cfg=OmegaConf.load(p)
 cfg.env.scene.model_file=str(B/'physics/scene.xml');cfg.env.scene.visual_model_file=str(B/'physics/scene.xml');cfg.env.warp_compiled_model_file=str(B/'physics/effective_training.mjb')
 target=np.array(c['home_joint_qpos']);limits=np.array(c['joint_limits_rad']);cfg.env.action_offset_low=(limits[:,0]+1e-5-target).tolist();cfg.env.action_offset_high=(limits[:,1]-1e-5-target).tolist()
 if 'smooth_head_target' in cfg.env:cfg.env.smooth_head_target=target[[5,6]].tolist()
 if 'smooth_walk_height_m' in cfg.env:cfg.env.smooth_walk_height_m=h
 for key in ['fast_step_start_m','fast_step_goal_m']:
  if key in cfg.env:cfg.env[key]=.13
 if 'fast_step_minimum_m' in cfg.env:cfg.env.fast_step_minimum_m=.117;cfg.env.fast_step_maximum_m=.143
 if node['id'] in ['P10','P11','P12','P13']:cfg.env.step_goal_m=.13
 OmegaConf.save(cfg,p)
# Only standing-height adaptation and explicit step-target constants in baseline sources.
for p in (B/'workspace').rglob('*.py'):
 if p.is_symlink():continue
 s=p.read_text();t=s
 for a,b in [(oh,h),(oh-.07,h-.07),(oh+.02,h+.02),(oh-.06,h-.06),(oh-.02,h-.02)]:t=t.replace(repr(a),repr(b))
 if p.name=='large_step_objective.py':t=t.replace('GOAL=.20','GOAL=.13').replace('lengths-.22','lengths-1.1*GOAL')
 if p.name=='balanced_env.py':t=t.replace('.10/np.maximum(np.abs(self._requested[:,0]),.05)','self.cfg.step_goal_m/np.maximum(np.abs(self._requested[:,0]),.05)').replace('.10*np.sign(self._requested[:,0])','self.cfg.step_goal_m*np.sign(self._requested[:,0])')
 if p.name in ['balanced_env.py','direct_step.py'] and '        known_other = self._dir_land_time[:, ::-1] >= 0' in t:
  t=t.replace('import numpy as np','import numpy as np\nfrom step_measurement import update_env as measured_placement',1)
  start=t.index('        leaving = ~self._smooth_air & (h > 0.0015)',t.index('    def _compute_reward('));end=t.index('        goal_step = self.curriculum.goal',start)
  t=t[:start]+'''        measured = measured_placement(self, world, h, yaw, rootxy, cmd)
        leaving = measured['leaving'];self._smooth_peak = measured['peak'].copy()
        landing = measured['landing'];touchdown = landing
        known_other = measured['known_other'];step_length = measured['length'];interval = measured['interval']
        times = np.broadcast_to(episode_age[:, None], (self.num_envs, 2));yaw_rows = np.broadcast_to(yaw[:, None], (self.num_envs, 2))
        one = touchdown.sum(1) == 1;side = np.argmax(touchdown, axis=1)
        alternate_row = measured['alternating'];alternating = touchdown & alternate_row[:, None]
''' + t[end:]
  t=t.replace('        valid_step = proper & known_other & alternating','        valid_step = measured[\'valid\']\n        self._pair_valid[touchdown & ~valid_step] = False')
  # Existing reset method remains in the baseline; add detector state isolation only.
  marker='    def _reset_episode_history(self, ids):\n        super()._reset_episode_history(ids)'
  if marker in t:t=t.replace(marker,marker+"\n        if hasattr(self,'_step_measurement'):self._step_measurement.reset(ids)")
  compile(t,str(p),'exec')
 if t!=s:p.write_text(t);edits.append(str(p.relative_to(B)))
for run in {n['run'] for n in plan['nodes']}:(B/'workspace'/run/'step_measurement.py').write_bytes((B/'tools/step_measurement.py').read_bytes())
# Baseline reward functions, optimizers, native batch sizes and samplers are unchanged.
for run in {n['run'] for n in plan['nodes']}:
 for name in ['balance_objective.py','policy_setup.py','mirror_policy.py','head_freeze.py','task_adapter.py']:
  a=BASE/'workspace'/run/name;b=B/'workspace'/run/name
  if a.exists():assert a.read_bytes()==b.read_bytes(),(run,name)
plan.update(status='BASELINE_RESTORED_MEASUREMENT_AUDIT',baseline_branch=str(BASE),model_version='2.0.2',nominal_step_goal_m=.13,added_motion_reward=False)
(B/'route_plan.json').write_text(json.dumps(plan,indent=2));(B/'audit/SCOPE_SOURCE_EDITS.json').write_text(json.dumps(edits,indent=2))
p=B/'audit/GAIT_STYLE_CONTRACT.json';x=json.loads(p.read_text());x['physical_model_sha256']=c['model_sha256'];p.write_text(json.dumps(x,indent=2))
p=B/'audit/STEP_TARGET_CONTRACT.json';x=json.loads(p.read_text());x.update(revision='v201_route_step13_contact_20261108',status='VALIDATED',stage_step_goals_m={k:.13 for k in ['P09','P10','P11','P12','P13']},restart_stage='P00',parent_checkpoint=None,model_version='2.0.2');x.pop('parent_sha256',None);x.pop('archive',None);p.write_text(json.dumps(x,indent=2))
p=B/'audit/ACTIVE_REVISION.json';p.write_text(json.dumps(dict(revision='v201_route_step13_contact_20261108',status='FRESH_RANDOM_INITIALIZATION_READY',start_stage='P00',parent_checkpoint=None,total_ppo_updates=3442,physical_model_sha256=c['model_sha256']),indent=2))
p=B/'audit/EXECUTION_POLICY.json';x=json.loads(p.read_text());x.update(continue_from_stage='P00',remaining_ppo_updates=3442,step_goal_m=.13);p.write_text(json.dumps(x,indent=2))
assert not list((B/'runs').rglob('*.pt'));assert not (B/'tools/motion_repair.py').exists()
print('RESTORED_V201_ROUTE',[(n['id'],n['num_envs'],n['selected_updates_in_this_stage']) for n in plan['nodes']])

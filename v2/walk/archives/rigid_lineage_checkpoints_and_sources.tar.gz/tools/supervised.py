"""Collect current-model teachers and perform explicitly counted supervised steps."""
from pathlib import Path
import json, copy
import numpy as np
import torch
from execution_policy import performance_gates_enabled
from step_measurement import StepMeasurement

COMMANDS=np.array([[.3,0,0],[-.3,0,0],[.3,0,.4],[.3,0,-.4],[-.3,0,.4],[-.3,0,-.4],[0,0,.4],[0,0,-.4]],float)

def run(g):
    args=g['args'];ID=g['ID'];B=g['B'];R=g['R'];NODE=g['NODE'];contract=g['CONTRACT'];atomic=g['atomic'];sha=g['sha'];load=g['load_new'];Decoder=g['Decoder']
    fixture=args.fixture
    path=g['parent_path']();parent=load(path,fixture);c=g['config'](parent)
    if args.mode=='collect':
        n=args.envs or 64
        assert n%8==0
        per=n//8;cmd=np.repeat(COMMANDS,per,axis=0);pool=np.repeat([0,1,0,0,1,1,2,2],per)
        teacher=Decoder(parent).to('cuda').eval();teacher_stage=parent['infos']['new_lineage']['stage']
        alternate=None
        if args.teacher:alternate=Decoder(load(args.teacher,fixture)).to('cuda').eval()
        e=g['setup_env'](c,n)
        try:
            e.init_state();e.set_autoreset(False)
            old_maybe=e._maybe_resample_commands
            def command(st,advance=True):
                if hasattr(e,'_requested'):
                    e._requested[:]=cmd
                    if hasattr(e,'_next_switch'):e._next_switch[:]=1e12
                    if hasattr(e,'_task_kind'):e._task_kind[:]=np.repeat(np.arange(8),per)
                    if advance:old_maybe(st)
                elif hasattr(e,'_dir_commands'):
                    e._dir_commands[:]=0;e._dir_commands[:,:3]=cmd;st.info['commands'][:]=e._dir_commands
                else:st.info['commands'][:]=0;st.info['commands'][:,:3]=cmd
            e._maybe_resample_commands=command
            detector=StepMeasurement(n,e.cfg.ctrl_dt)
            records=[];alive=np.ones(n,bool);motion_count=np.zeros(n,int);air=np.zeros((n,2),bool);peaks=np.zeros((n,2));step_count=np.zeros(n,int)
            for tick in range(160 if fixture else 400):
                command(e.state,advance=False);obs=e.state.obs['obs'].copy();obs[:,48:51]=cmd
                if hasattr(e,'_phase'):
                    obs[:,59:61]=e._phase.encode()
                    if hasattr(e._phase,'encode_task'):obs[:,56:59]=e._phase.encode_task()
                    if hasattr(e._phase,'encode_motion'):obs[:,51:56]=e._phase.encode_motion()
                inputs=obs.copy()
                # Native teachers have body-pose fields where later actors have phase/task fields.
                if teacher_stage in ['P00','P01','P02','P03','P05','P06','P07','P09'] and ID in ['P10','P11','P12','P13']:inputs[:,51:61]=0
                if ID=='P12':
                    inputs[:,56:59]=0
                    error=e._phase.heading_error
                    inputs[:,50]=np.clip(cmd[:,2]-.8*error,-.6,.6)
                if ID=='P13':inputs[:,51:56]=0
                with torch.inference_mode():
                    actions=teacher(torch.tensor(inputs,dtype=torch.float32,device='cuda')).cpu().numpy()
                    if alternate is not None:
                        other=alternate(torch.tensor(inputs,dtype=torch.float32,device='cuda')).cpu().numpy()
                        # Physically test clean-leg/current-width mixtures, like the historical bootstrap.
                        fractions=np.tile(np.linspace(.25,1,per),8)
                        rows=[0,2,3,4,9,11,12,13]
                        back=cmd[:,0]<0
                        mix=(1-fractions[:,None])*actions[:,rows]+fractions[:,None]*other[:,rows]
                        actions[np.ix_(back,rows)]=mix[back]
                result=e.step(actions)
                phi=e._backend.get_physics_state();q=phi[:,1:22];vel=e.get_local_linvel().copy();w=e.get_gyro()[:,2]
                tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,4]**2+q[:,5]**2),-1,1)))
                finite=np.isfinite(obs).all(1)&np.isfinite(actions).all(1)&np.isfinite(result.reward)
                assert finite.all()
                alive&=(tilt<25)&(q[:,2]>contract['fall_height_m'])
                physical=(tilt<20)&(q[:,2]>contract['fall_height_m'])&alive
                directed=np.where(pool==2,np.sign(cmd[:,2])*w>.06,np.sign(cmd[:,0])*vel[:,0]>.01)
                if tick>=150:motion_count+=(physical&directed)
                h=e._foot_height;feet=np.stack([e._backend.get_sensor_data(s) for s in e.cfg.sensor.feet_pos],axis=1)
                yaw=np.arctan2(2*(q[:,3]*q[:,6]+q[:,4]*q[:,5]),1-2*(q[:,5]**2+q[:,6]**2))
                placement=detector.update(feet,h,yaw,q[:,:2],cmd[:,0]);step_count+=placement['valid'].sum(1)
                # BC needs actual achieved motion. Anchors preserve healthy current behavior.
                good=physical & ((tick<50)|directed) if ID in ['P07','P11'] else physical
                if fixture:good=np.ones(n,bool)
                records.append((obs.copy(),actions.copy(),good.copy(),pool.copy(),vel.copy(),q.copy()))
            obs=np.stack([r[0] for r in records]);actions=np.stack([r[1] for r in records]);good=np.stack([r[2] for r in records]);labels=np.stack([r[3] for r in records])
            qualified=None
            if ID in ['P07','P11'] and not fixture:
                qualified=alive&(motion_count>=100)&(step_count>=4)
                good&=qualified[None,:]
            if ID in ['P07','P09']:
                # Preserve the historical four anchor pools: startup, current
                # forward/turn, masked directional knowledge, backward examples.
                kinds=labels.copy();labels=np.where(kinds==1,3,np.where(kinds==2,2,1))
                labels[:100]=0
            required_pools=[0,1,2,3] if ID in ['P07','P09'] else [0,1,2]
            if ID=='P11' and args.dataset:
                name=Path(args.dataset).name
                if name=='forward_teacher.npz':required_pools=[0];good&=(labels==0)
                elif name=='direction_teacher.npz':required_pools=[1,2];good&=np.isin(labels,[1,2])
            o=obs[good].astype(np.float32);y=actions[good].astype(np.float32);labels=labels[good]
            counts={str(i):int((labels==i).sum()) for i in required_pools}
            if performance_gates_enabled(B):
                assert min(counts.values())>=100,('Insufficient physically qualified teacher data',counts)
            else:
                assert min(counts.values())>=2,('Need nonempty train and held-out teacher pools',counts)
            mask=np.ones_like(y)
            if ID in ['P06','P07','P09']:
                masked=labels==2;mask[np.ix_(masked,[1,5,6,7,8,10])]=0
            if ID in ['P10','P11','P12','P13']:mask[:,5:9]=0;y[:,5:9]=0
            if ID in ['P12','P13']:
                mask[:]=0;mask[:,[2,3,4,11,12,13]]=1
                keep=abs(o[:,50])<.01;o=o[keep];y=y[keep];mask=mask[keep];labels=np.zeros(len(o),int)
            dataset=Path(args.dataset) if args.dataset else R/'anchor.npz'
            np.savez_compressed(dataset,obs=o,mean=y,mask=mask,phase=labels,std=parent['actor_state_dict']['distribution.std_param'].numpy().astype(np.float32))
            atomic(dataset.with_suffix('.json'),dict(status='FIXTURE_ONLY' if fixture else 'PASS',model_sha256=contract['model_sha256'],teacher_checkpoint=str(path),teacher_sha256=sha(path),alternate_teacher_sha256=sha(args.teacher) if args.teacher else None,dataset_sha256=sha(dataset),new_model_physical_rollouts=True,frame_counts=counts,qualified_cases=np.flatnonzero(qualified).tolist() if qualified is not None else None,health_filter='tilt<20deg and root>new-model fall height; P07/P11 additionally require 100 directed steady frames and 4 actual steps per case',not_final_acceptance=True))
            print('NEW_TEACHER_DATA',ID,counts,flush=True)
        finally:e.close()
        return

    assert args.mode in ['bootstrap','bc']
    dataset=Path(args.dataset) if args.dataset else R/'anchor.npz'
    data_meta=json.loads(dataset.with_suffix('.json').read_text());assert data_meta['model_sha256']==contract['model_sha256']
    assert data_meta['status']==('FIXTURE_ONLY' if fixture else 'PASS')
    assert data_meta['dataset_sha256']==sha(dataset)
    with np.load(dataset) as z:o=z['obs'].copy();y=z['mean'].copy();mask=z['mask'].copy();labels=z['phase'].copy()
    steps=800 if args.mode=='bootstrap' else 1800
    if fixture:steps=2
    student=Decoder(parent).to('cuda');student.train()
    # The new P11 forward decoder is phase-aware and mirrored; P07 remains native.
    leg=torch.tensor([0,1,2,3,4,9,10,11,12,13],device='cuda')
    x=torch.tensor(o,device='cuda');target=torch.tensor(y,device='cuda');m=torch.tensor(mask,device='cuda');rng=np.random.default_rng(NODE['seed'])
    pools=[np.flatnonzero(labels==i) for i in range(4 if args.mode=='bootstrap' else 3)];assert all(len(p)>=(100 if performance_gates_enabled(B) else 2) for p in pools)
    train_masks=rng.random(len(o))>.1;train=[p[train_masks[p]] for p in pools];hold=[p[~train_masks[p]] for p in pools]
    if not performance_gates_enabled(B):
        for i,pool in enumerate(pools):
            if not len(train[i]) or not len(hold[i]):hold[i]=pool[:1];train[i]=pool[1:]
    opt=torch.optim.Adam(student.net.parameters(),lr=8e-5 if args.mode=='bootstrap' else 7e-5)
    for step in range(steps):
        losses=[]
        for i,pool in enumerate(train):
            ix=rng.choice(pool,128 if args.mode=='bootstrap' else 256,replace=True);pred=student(x[ix]);loss=(((pred-target[ix])/.35).square()*m[ix]).sum()/m[ix].sum().clamp_min(1);losses.append(loss)
        weights=[2.,1.,.5,2.] if args.mode=='bootstrap' else [3.,1.,1.5]
        loss=sum(a*b for a,b in zip(weights,losses));opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(student.net.parameters(),1.);opt.step()
        if (step+1)%200==0:print('SUPERVISED',ID,args.mode,step+1,float(loss.detach()),flush=True)
    with torch.inference_mode():errors=[float((student(x[ix])[:,leg]-target[ix][:,leg]).square().mean().sqrt()) for ix in hold]
    assert np.isfinite(errors).all(),errors
    if not fixture and performance_gates_enabled(B):assert max(errors)<.45,errors
    ck=copy.deepcopy(parent);sd=ck['actor_state_dict']
    for k,v in student.net.state_dict().items():sd['mlp.'+k]=v.detach().cpu()
    ck.pop('optimizer_state_dict',None)
    ck['infos']['supervised']=dict(operation=args.mode,steps=steps,dataset_sha256=sha(dataset),source_sha256=sha(path),holdout_raw_RMS=errors)
    ck['infos']['new_lineage']['mode']='fixture' if fixture else 'train'
    out=B/'audit'/f'{ID}_supervised_fixture.pt' if fixture else R/'seed.pt';torch.save(ck,out)
    atomic(R/(args.mode+'_REPORT.json'),dict(status='FIXTURE_ONLY' if fixture else 'PASS',steps=steps,seed_sha256=sha(out),holdout_raw_RMS=errors,holdout_quality_pass=max(errors)<.45,performance_gate_enforced=performance_gates_enabled(B),ppo_updates=0))

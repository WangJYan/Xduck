"""Compare cached vs reference motor dynamics, including changing gains and resets."""
from pathlib import Path
import sys,importlib.util,copy,json,time,statistics
import numpy as np
B=Path(__file__).resolve().parents[1];P=B/'workspace/stable_step_side400_20261105/project';sys.path.insert(0,str(P/'src'))
from unilab.actuators.gf43x40.actuator import GF43X40Actuator,GF43X40Parameters
ref=B/'audit/motor_gain_backup'/((P/'src/unilab/actuators/gf43x40/actuator.py').relative_to(B))
spec=importlib.util.spec_from_file_location('unilab.actuators.gf43x40.actuator_reference',ref);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
Reference=module.GF43X40Actuator;rng=np.random.default_rng(711);base=GF43X40Parameters.from_bundle();reports=[]
for mode in ['smooth_stribeck','smooth_coupled_approx','isolated_1d']:
    params=copy.deepcopy(base);params.physics.pop('friction_model',None)
    a=Reference(8,14,parameters=params,friction_mode=mode);b=GF43X40Actuator(8,14,parameters=params,friction_mode=mode)
    kp=np.full((8,14),90.);kd=np.full((8,14),2.5);max_error=0.
    for tick in range(600):
        if tick%71==0:kp[rng.integers(8)]=rng.uniform(0,200,14);kd[rng.integers(8)]=rng.uniform(0,4.5,14)
        if tick in [130,300]:params.physics['kp_gain_slope']=params.physics.get('kp_gain_slope',0.)+.001;params.observation['velocity_filter_kp_slope']=params.observation.get('velocity_filter_kp_slope',0.)+.001
        q=rng.normal(0,.2,(8,14));v=rng.uniform(-35,35,(8,14));acc=rng.normal(0,10,(8,14));target=q+rng.normal(0,.1,(8,14));zero=np.zeros((8,14))
        if tick%59==0:
            ids=np.array([1,4]);a.reset(ids);b.reset(ids)
            np.testing.assert_array_equal(a.observe(v,acc),b.observe(v,acc))
        kw=dict(effective_mass=np.full((8,14),.4)) if mode=='isolated_1d' else {}
        old=a.compute_torque(q,v,target,zero,kp,kd,zero,**kw);new=b.compute_torque(q,v,target,zero,kp,kd,zero,**kw)
        max_error=max(max_error,float(np.max(abs(old-new))));np.testing.assert_array_equal(old,new)
        np.testing.assert_array_equal(a.observe(v,acc),b.observe(v,acc))
        for name,value in vars(a).items():
            if isinstance(value,np.ndarray):np.testing.assert_array_equal(value,getattr(b,name),err_msg=name)
    reports.append(dict(mode=mode,steps=600,torque_max_error=max_error,shared_state_arrays_exact=True))
params=copy.deepcopy(base);a=Reference(4096,14,parameters=params,friction_mode='smooth_coupled_approx');b=GF43X40Actuator(4096,14,parameters=params,friction_mode='smooth_coupled_approx')
kp=np.broadcast_to(np.array([90,90,75,100,90,75,90,75,90,90,90,75,100,90.]),(4096,14)).copy();kd=np.full((4096,14),2.5);zero=np.zeros((4096,14));old_times=[];new_times=[]
for tick in range(240):
    q=rng.normal(0,.2,(4096,14));v=rng.normal(0,2,(4096,14));target=q+rng.normal(0,.1,(4096,14));acc=rng.normal(0,5,(4096,14))
    for motor,times in [(a,old_times),(b,new_times)]:
        start=time.perf_counter();motor.compute_torque(q,v,target,zero,kp,kd,zero);motor.observe(v,acc);times.append(time.perf_counter()-start)
before=statistics.median(old_times[10:]);after=statistics.median(new_times[10:])
report=dict(status='PASS_BITWISE_EQUAL',dynamic_gain_reset_and_parameter_tests=reports,num_envs_in_microbenchmark=4096,joints=14,before_median_ms=1000*before,after_median_ms=1000*after,speedup=before/after)
(B/'audit/MOTOR_GAIN_REGRESSION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

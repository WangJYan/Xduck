"""One source of truth for the user's 20cm ->15cm walking route."""
from pathlib import Path
from functools import lru_cache
import json,importlib.util

@lru_cache(None)
def metrics():
    B=Path(__file__).resolve().parents[1]
    file=B/'workspace/stable_step_side400_20261105/metrics.py'
    spec=importlib.util.spec_from_file_location('route_step_metrics',file)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    assert module.measurement_self_test()
    return module

def configuration(B,stage,c):
    path=Path(B)/'audit/STEP_TARGET_CONTRACT.json'
    if not path.exists():return None
    contract=json.loads(path.read_text())
    if stage not in contract['validation_stages']:return None
    goal=contract['stage_step_goals_m'][stage]
    assert abs(float(c.env.step_goal_m)-goal)<1e-9,(stage,c.env.step_goal_m,goal)
    return contract

def measure(events):
    from step_measurement import summarize
    assert not events or all('length' in e for e in events),'Point-only cached histories are not a valid step measurement; supply current-stance distances.'
    return summarize(events)

def accept(stats,goal):
    return metrics().step_target_pass(stats,target=goal)

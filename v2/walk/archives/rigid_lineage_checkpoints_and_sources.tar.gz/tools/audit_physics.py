"""Compare new reset geometry against MuJoCo FK and calibrate the physical IMU."""
from pathlib import Path
import importlib.util,json
import numpy as np
import mujoco

B=Path(__file__).resolve().parents[1];contract=json.loads((B/'audit/MODEL_CONTRACT.json').read_text());m=mujoco.MjModel.from_binary_path(str(B/'physics/effective_training.mjb'));d=mujoco.MjData(m)
p=B/'workspace/stable_step_side400_20261105/project/src/unilab/envs/locomotion/microduck_dm4310/reset_support.py'
spec=importlib.util.spec_from_file_location('new_reset_support',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
support=mod.ResetGroundClearance(str(B/'physics/scene.xml'),'floor')
floor=m.geom('floor').id
def minimum():
    vals=[]
    for g in range(m.ngeom):
        if g==floor or not ((m.geom_contype[g]&m.geom_conaffinity[floor]) or (m.geom_conaffinity[g]&m.geom_contype[floor])):continue
        rz=d.geom_xmat[g].reshape(3,3)[2];s=m.geom_size[g];kind=int(m.geom_type[g])
        if kind==7:
            k=m.geom_dataid[g];v=m.mesh_vert[m.mesh_vertadr[k]:m.mesh_vertadr[k]+m.mesh_vertnum[k]];vals.append(float(np.min(v@rz)+d.geom_xpos[g,2]));continue
        if kind==2:r=s[0]
        elif kind==3:r=s[0]+s[1]*abs(rz[2])
        elif kind==4:r=np.linalg.norm(rz*s)
        elif kind==5:r=s[1]*abs(rz[2])+s[0]*np.linalg.norm(rz[:2])
        elif kind==6:r=np.sum(abs(rz)*s)
        else:raise ValueError(kind)
        vals.append(float(d.geom_xpos[g,2]-r))
    return min(vals)
rng=np.random.default_rng(610);q=np.tile(contract['home_qpos'],(32,1));q[:,7:]+=rng.uniform(-.05,.05,(32,14));q[:,3:7]=rng.normal(size=(32,4));q[:,3:7]/=np.linalg.norm(q[:,3:7],axis=1,keepdims=True)
expected=[];position_error=[];gyro_error=[];force_error=[];physical=m.site('imu').id;proxy=m.site('policy_aligned_imu').id;rotation=np.asarray(contract['physical_imu_to_body_rotation'])
def sensor(name):
    i=m.sensor(name).id;return d.sensordata[m.sensor_adr[i]:m.sensor_adr[i]+m.sensor_dim[i]].copy()
for pose in q:
    d.qpos[:]=pose;d.qvel[:]=rng.normal(0,.2,m.nv)
    tau=rng.uniform(-2,2,14);d.ctrl[:]=pose[7:]+tau;mujoco.mj_forward(m,d)
    expected.append(minimum());position_error.append(np.max(abs(d.site_xpos[physical]-d.site_xpos[proxy])))
    gyro_error.append(np.max(abs(rotation@sensor('angular-velocity')-sensor('imu_ang_vel'))))
    force_error.append(np.max(abs(d.actuator_force-tau)))
actual=support.minimum_z(q);err=float(np.max(abs(actual-expected)))
assert err<1e-7,err
assert max(position_error)<1e-10 and max(gyro_error)<1e-8 and max(force_error)<1e-10
source=mujoco.MjModel.from_xml_path(str(B/'inputs/Xduck_2.0.2/scene.xml'))
np.testing.assert_array_equal(m.qpos0[7:],source.qpos0[7:])
np.testing.assert_allclose(m.key('HOME').qpos[7:],source.key('HOME').qpos[7:],atol=0)
assert np.allclose(m.key('STAND').qpos,m.key('HOME').qpos)
report=dict(status='PASS',random_poses=32,reset_geometry_max_z_error_m=err,physical_proxy_position_error_m=max(position_error),IMU_calibration_gyro_max_error=max(gyro_error),external_GF_native_torque_error_Nm=max(force_error),motor_zero_unchanged=True,HOME_joint_angles_unchanged=True,HOME_standing_height_m=contract['nominal_standing_height_m'],settled_standing_height_m=contract['settled_standing_height_m'],mass_kg=float(m.body_mass.sum()),new_geometry_types_supported=['mesh','box','sphere','capsule','cylinder','ellipsoid'])
(B/'audit/PHYSICS_PARITY.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

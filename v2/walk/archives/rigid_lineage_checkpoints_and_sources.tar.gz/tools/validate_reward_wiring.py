from pathlib import Path
import sys,json
import numpy as np,torch,warp as wp
stage=sys.argv[1];B=Path(__file__).resolve().parents[1];entry=B/'tools/stage_entry.py';sys.path.insert(0,str(B/'tools'));sys.argv=[str(entry),'--stage',stage,'--mode','smoke','--fixture'];g={'__file__':str(entry),'__name__':'reward_wiring'};exec(compile(entry.read_text().split('torch.set_num_threads(2);')[0],str(entry),'exec'),g)
torch.set_num_threads(2);torch.manual_seed(71108131);np.random.seed(71108131);wp.init();ck=g['load_new'](B/'audit'/f'{stage}_input_fixture.pt',True);e=g['setup_env'](g['config'](ck),32)
try:
 e.init_state();e.set_autoreset(False);globals_=type(e)._compute_reward.__globals__;capture={}
 if stage=='P09':
  original=globals_['touchdown_credit']
  def wrapped(valid,pair_valid,lengths,peak,heading,lateral,speed):
   result=original(valid,pair_valid,lengths,peak,heading,lateral,speed);capture.update(valid=valid.copy(),lengths=lengths.copy(),pair_valid=pair_valid.copy(),result=result.copy());return result
  globals_['touchdown_credit']=wrapped
 else:
  original=globals_['phase_terms']
  def wrapped(*a,**kw):
   result=original(*a,**kw);capture.update(valid=a[0].copy(),lengths=a[1].copy(),goal=float(a[15]),result=result['landing'].copy());return result
  globals_['phase_terms']=wrapped
 errors=[];sensor_errors=[];captured=0
 for tick in range(64):
  e.step(np.zeros((32,14)));r=e._step_measurement_audit;feet=r['feet_world'];yaw=r['yaw'];cmd=e.state.info['commands'][:,0];sign=np.where(cmd<-.05,-1.,1.)
  oracle=np.stack([((feet[:,s,0]-r['reference_point'][:,s,0])*np.cos(r['projection_yaw'][:,s])+(feet[:,s,1]-r['reference_point'][:,s,1])*np.sin(r['projection_yaw'][:,s]))*sign for s in [0,1]],axis=1)
  oracle=np.where(r['known_other']&(r['reference_age_s']<=1.5000001),oracle,0.)
  err=float(abs(r['length']-oracle).max());errors.append(err);assert err<1e-10
  np.testing.assert_array_equal(capture['valid'],r['valid']);np.testing.assert_allclose(capture['lengths'],e._pair_lengths,atol=0)
  if stage=='P13':assert capture['goal']==json.loads((B/'audit/STEP_TARGET_CONTRACT.json').read_text())['stage_step_goals_m'][stage]
  sensor=np.stack([e._backend.get_sensor_data(s) for s in e.cfg.sensor.feet_pos],axis=1);sensor_errors.append(float(abs(sensor-feet).max()));captured+=1
 age=e._step_measurement.time.copy();e.reset(np.array([0,3],np.int32));assert e._step_measurement.time[0]==0 and e._step_measurement.time[3]==0;np.testing.assert_array_equal(e._step_measurement.time[4:],age[4:])
 report=dict(status='PASS',stage=stage,control_frames=captured,worlds=32,actual_reward_function_intercepted=True,reward_valid_flags_equal_detector=True,reward_length_cache_equal_measured_updates=True,current_foot_oracle_max_error_m=max(errors),sensor_body_site_max_difference_m=max(sensor_errors),goal_m=float(e.curriculum.goal),partial_reset_isolated=True)
 (B/'audit'/f'{stage}_REWARD_WIRING.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
finally:e.close()

"""Cache exactly repeated gain-only coefficients; invalidate on any gain/parameter change."""
from pathlib import Path
import json,hashlib,ast

def optimized_source(s):
    if '_gain_coefficient_cache' in s:return s
    start=s.find('        gain_feature = kp / (kp + 80.0)')
    if start<0:return s
    end=s.index('        requested = np.clip(requested',start)
    if 'gain_band' not in s[start:end]:return s
    replacement='''        signature=(physical.get("kp_gain_slope",0.0),physical.get("kd_gain_slope",0.0),physical.get("kd_gain_band_slope",0.0))
        cache=getattr(self,"_gain_coefficient_cache",None)
        if cache is None or cache[2]!=signature or not np.array_equal(kp,cache[0]) or not np.array_equal(kd,cache[1]):
            gain_feature=kp/(kp+80.0)
            def smoothstep(value):
                bounded=np.clip(value,0.0,1.0)
                return bounded*bounded*(3.0-2.0*bounded)
            gain_band=(smoothstep((kp-70.0)/10.0)*(1.0-smoothstep((kp-110.0)/20.0))*smoothstep((kd-2.6)/0.3)*(1.0-smoothstep((kd-3.2)/0.3)))
            effective_kp=kp*np.exp(signature[0]*gain_feature)
            effective_kd=kd*np.exp((signature[1]+signature[2]*gain_band)*gain_feature)
            cache=(kp.copy(),kd.copy(),signature,gain_feature,effective_kp,effective_kd)
            self._gain_coefficient_cache=cache
        self._gain_feature[:]=cache[3]
        requested=(cache[4]*(target-q)+cache[5]*(speed_target+physical["velocity_target_bias"]-self.internal_velocity)+physical["feedforward_gain"]*ff)
'''
    s=s[:start]+replacement+s[end:]
    start=s.index('        vtc = obs.get("velocity_filter_tc", 0.0)')
    end=s.index('\n',s.index('        valpha = np.where(vtc > 0, -np.expm1(valpha), 1.0)',start))+1
    s=s[:start]+'''        signature=(obs.get("velocity_filter_tc",0.0),obs.get("velocity_filter_kp_slope",0.0),self.dt)
        cache=getattr(self,"_velocity_gain_cache",None)
        if cache is None or cache[0]!=signature or not np.array_equal(self._gain_feature,cache[1]):
            vtc=signature[0]*np.exp(signature[1]*(self._gain_feature-0.65))
            valpha=np.ones(self.shape)
            np.divide(-self.dt,vtc,out=valpha,where=vtc>0)
            valpha=np.where(vtc>0,-np.expm1(valpha),1.0)
            cache=(signature,self._gain_feature.copy(),valpha)
            self._velocity_gain_cache=cache
        valpha=cache[2]
'''+s[end:]
    ast.parse(s);return s

if __name__=='__main__':
    b=Path(__file__).resolve().parents[1];records=[]
    for p in (b/'workspace').glob('*/project/src/unilab/actuators/gf43x40/actuator.py'):
        old=p.read_bytes();new=optimized_source(old.decode()).encode()
        if new==old:continue
        backup=b/'audit/motor_gain_backup'/p.relative_to(b);backup.parent.mkdir(parents=True,exist_ok=True)
        if not backup.exists():backup.write_bytes(old)
        p.write_bytes(new);records.append(dict(path=str(p.relative_to(b)),before=hashlib.sha256(old).hexdigest(),after=hashlib.sha256(new).hexdigest()))
    (b/'audit/MOTOR_GAIN_PATCHES.json').write_text(json.dumps(records,indent=2));print('Patched',len(records),'gain-cache copies')

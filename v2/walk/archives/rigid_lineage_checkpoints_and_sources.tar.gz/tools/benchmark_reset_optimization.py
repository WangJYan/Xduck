"""A/B sample the same 4096x24 workload with old vs pressure-only reset guard."""
from pathlib import Path
import ast,sys,time,json,types,statistics,os,argparse
import numpy as np,torch,warp as wp
from torch import nn
from omegaconf import OmegaConf
B=Path(__file__).resolve().parents[1];P=B/'workspace/stable_step_side400_20261105/project';sys.path[:0]=[str(P/'src'),str(P/'scripts')]
ap=argparse.ArgumentParser();ap.add_argument('--profile-only',action='store_true');ap.add_argument('--force-resets',action='store_true');args=ap.parse_args()
import train_rsl_rl as E
from unilab.base.backend.mjwarp.backend import MjwarpBackend
from unilab.training.rsl_rl import RslRlVecEnvWrapper
import gc
torch.set_num_threads(2);torch.manual_seed(710);np.random.seed(710);wp.init();wp.set_mempool_release_threshold('cuda:0',0)
c=OmegaConf.load(B/'runs/P01/TRAINING_CONFIG.yaml');E.ensure_registries();e=E.create_env(c,num_envs=4096,env_cfg_override=E.build_ppo_env_cfg_override(c));backend=e._backend
pause=json.loads((B/'audit/OPTIMIZATION_PAUSE.json').read_text());ck=torch.load(B/pause['checkpoint'],map_location='cpu',weights_only=False);sd=ck['actor_state_dict'];old_step=e.step_counter;e.step_counter=int(ck['infos']['unilab_progress']['env_steps_per_env']);e._next_push_step+=e.step_counter-old_step;e._update_curriculum()
net=nn.Sequential(nn.Linear(61,512),nn.ELU(),nn.Linear(512,256),nn.ELU(),nn.Linear(256,128),nn.ELU(),nn.Linear(128,14));net.load_state_dict({k[4:]:v for k,v in sd.items() if k.startswith('mlp.')});net=net.to('cuda').eval();mean=sd['obs_normalizer._mean'].to('cuda');scale=(sd['obs_normalizer._std']+.01).to('cuda');std=sd['distribution.std_param'].to('cuda')
rel=P/'src/unilab/base/backend/mjwarp/xduck_gf.py'
old=B/'audit/reset_optimization_backup'/rel.relative_to(B)
def helper(path):
    tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='XDuckGF43X40WarpBackend');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_execute_device_forward')
    source=ast.unparse(method).replace('super()._execute_device_forward()', 'MjwarpBackend._execute_device_forward(self)')
    ns=dict(time=time,torch=torch,gc=gc,os=os,MjwarpBackend=MjwarpBackend);exec(compile(source,str(path),'exec'),ns);return ns['_execute_device_forward']
helpers={'before':helper(old),'after':helper(rel)};wrapped=RslRlVecEnvWrapper(e,device='cuda')
try:
    obs,_=wrapped.reset();rows=[];phase_totals={};original_step=backend.step
    def timed_step(*a,**kw):
        result=original_step(*a,**kw)
        for k,v in result.get('timing',{}).items():phase_totals[k]=phase_totals.get(k,0.)+float(v)
        return result
    backend.step=timed_step
    for mode in (['after','after'] if args.profile_only else ['after','before','after','before','after','before','after']):
        calls=[0];seconds=[0.];phase_totals.clear()
        def forward(self):
            start=time.perf_counter();calls[0]+=1
            try:return helpers[mode](self)
            finally:seconds[0]+=time.perf_counter()-start
        backend._execute_device_forward=types.MethodType(forward,backend)
        start=time.perf_counter()
        for tick in range(24):
            with torch.inference_mode():action=net((obs['actor']-mean)/scale)+torch.randn((4096,14),device='cuda')*std
            obs,reward,done,_=wrapped.step(action);assert torch.isfinite(reward).all() and torch.isfinite(obs['actor']).all()
            if args.force_resets:e.reset(np.array([tick],dtype=np.int32))
        torch.cuda.synchronize();elapsed=time.perf_counter()-start
        row=dict(mode=mode,rollout_seconds=elapsed,reset_calls=calls[0],reset_forward_seconds=seconds[0],phase_totals_ms=phase_totals.copy());rows.append(row);print('AB_ROLLOUT',json.dumps(row),flush=True)
    if args.profile_only:
        (B/'audit/ROLLOUT_PHASE_PROFILE.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2),flush=True)
        raise SystemExit(0)
    data=rows[1:];before=statistics.median(r['rollout_seconds'] for r in data if r['mode']=='before');after=statistics.median(r['rollout_seconds'] for r in data if r['mode']=='after')
    report=dict(status='PASS_FINITE',num_envs=4096,rollout_steps=24,before_median_seconds=before,after_median_seconds=after,speedup=before/after,rows=rows,checkpoint=pause['checkpoint'],PPO_optimizer_not_benchmarked=True,other_training_processes_not_stopped=True,forced_single_row_reset_each_control_step=args.force_resets)
    (B/'audit'/('RESET_4096_FORCED_AB_BENCHMARK.json' if args.force_resets else 'RESET_4096_AB_BENCHMARK.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
finally:e.close()

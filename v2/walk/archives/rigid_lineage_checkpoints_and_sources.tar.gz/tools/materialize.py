"""Reconstruct an isolated workspace. Never starts training."""
import argparse,json,hashlib,shutil,os
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--stage',default='all');ap.add_argument('--python');ap.add_argument('--uv');a=ap.parse_args()
B=Path(__file__).resolve().parents[1];P=B/'reproduction_payload'
if not (P/'snapshot_manifest.json').exists():raise SystemExit('Documentation-only package: download the full reproduction payload first.')
m=json.loads((P/'snapshot_manifest.json').read_text());dest=Path(a.root).expanduser().absolute();canonical=m['canonical_root']
if str(dest)==canonical or str(dest).startswith(canonical+'/'):raise SystemExit('Refusing to overwrite the original training workspace; choose an isolated root.')
if dest.exists() and any(dest.iterdir()):raise SystemExit('Destination must be empty.')
if any(c in str(dest) for c in ['\n','\r',"'",'"']):raise SystemExit('Use a root without quotes or newlines.')
stages=m.get('snapshot_stages',m['mainline_stages']);aliases={'final':'stable_step_side400_20261105','baseline':'xduck_r2_flex_adapt100_20261010'};selected=stages if a.stage=='all' else [aliases.get(a.stage,a.stage)]
if any(x not in stages for x in selected):raise SystemExit('Unknown stage')
venv=None
if a.python:
 py=Path(a.python).expanduser().absolute();venv=py.parent.parent.resolve()
 if not py.exists() or not (venv/'pyvenv.cfg').exists():raise SystemExit('--python must point to a real Python virtual environment bin/python.')
dest.mkdir(parents=True,exist_ok=True);log=[];count=0
for logical,item in m['files'].items():
 top=logical.split('/')[0]
 if top in stages and top not in selected:continue
 source=P/'blobs'/item['sha256'];data=source.read_bytes()
 if hashlib.sha256(data).hexdigest()!=item['sha256']:raise SystemExit('Corrupt blob: '+logical)
 target=dest/logical;target.parent.mkdir(parents=True,exist_ok=True);old_hash=item['sha256']
 if target.suffix in {'.py','.yaml','.yml','.json','.toml','.lock','.sh','.md','.txt'}:
  try:
   text=data.decode('utf-8');text=text.replace(canonical,str(dest)).replace('/Users/xiaoyaozi/xinchen/Xduck/output',str(dest))
   if a.uv:text=text.replace('/home/xingchen/.local/bin/uv',str(Path(a.uv).absolute()))
   data=text.encode('utf-8')
  except UnicodeDecodeError:pass
 target.write_bytes(data);target.chmod(item['mode']);new_hash=hashlib.sha256(data).hexdigest();count+=1
 if new_hash!=old_hash:log.append({'path':logical,'original_sha256':old_hash,'materialized_sha256':new_hash,'reason':'explicit workspace/uv path relocation only'})
for stage in selected:
 if (dest/stage/'project').exists() and venv:(dest/stage/'project/.venv').symlink_to(venv,target_is_directory=True)
(dest/'MATERIALIZATION.json').write_text(json.dumps({'source_manifest':hashlib.sha256((P/'snapshot_manifest.json').read_bytes()).hexdigest(),'stages':selected,'files':count,'python':a.python,'venv':str(venv) if venv else None,'uv':a.uv,'path_relocations':log,'training_started':False},indent=2))
print(json.dumps({'root':str(dest),'stages':selected,'files':count,'path_relocated_files':len(log),'training_started':False},indent=2))

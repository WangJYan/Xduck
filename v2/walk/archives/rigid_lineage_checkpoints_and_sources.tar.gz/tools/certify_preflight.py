"""Final targeted graph/export checks after the complete route and 4096 preflight."""
from pathlib import Path
import json,subprocess,sys,hashlib
B=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pre=json.loads((B/'audit/PREFLIGHT_COMPLETE.json').read_text());assert pre['status']=='PASS_SOFTWARE_AND_PHYSICS'
def run(stage,mode,path,*extra):
    argv=[sys.executable,'-u',str(B/'tools/stage_entry.py'),'--stage',stage,'--mode',mode,'--fixture','--checkpoint',str(path),*extra]
    with (B/'logs'/f'{stage}_{mode}_final_preflight.log').open('w') as f:subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,check=True,cwd=B)
run('P10','smoke',B/'audit/P10_input_fixture.pt','--envs','32')
for stage in ['P00','P10','P12','P13']:run(stage,'export',B/'audit'/f'{stage}_fixture.pt')
for stage in ['P10','P12','P13']:assert json.loads((B/'audit'/f'{stage}_SEED_PARITY_smoke.json').read_text())['status']=='PASS'
assert json.loads((B/'audit/P00_SMOKE.json').read_text())['num_envs']==4096
assert json.loads((B/'audit/PHYSICS_PARITY.json').read_text())['status']=='PASS'
for p,h in json.loads((B/'audit/FROZEN_INPUTS.json').read_text()).items():assert sha(B/p)==h,p
pre['tools_sha256']={str(p.relative_to(B)):sha(p) for p in sorted((B/'tools').glob('*.py'))}
pre['targeted_graph_parity_and_onnx_exports']='PASS; fixtures only; no historical or fixture weights may enter formal training'
(B/'audit/PREFLIGHT_COMPLETE.json').write_text(json.dumps(pre,indent=2));print('READY_FOR_FORMAL_TRAINING',flush=True)

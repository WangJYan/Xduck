"""Reject gait and toe-heading regressions before a checkpoint becomes a teacher."""
import numpy as np
import json
import torch
from step_target import configuration,measure,accept
from execution_policy import performance_gates_enabled
from step_measurement import StepMeasurement,summarize

def run(g):
    B=g['B'];args=g['args'];checkpoint=g['parent_path']();ck=g['load_new'](checkpoint)
    c=g['config'](ck)
    target_contract=configuration(B,g['ID'],c)
    if g['ID']=='P09':target_contract=json.loads((B/'audit/STEP_TARGET_CONTRACT.json').read_text())
    if 'newstand_bank_path' in c.env:c.env.newstand_bank_path=str(B/'inputs/heldout_standing_bank.npz')
    c.env.domain_rand.velocity_pushes=False;c.env.max_episode_seconds=30.;c.env.audit_twist=[.3,0,0]
    n=args.envs or 32;actor=g['Decoder'](ck).to('cuda').eval();e=g['setup_env'](c,n)
    try:
        if g['ID'] in ['P00','P01','P02','P03']:
            old=e.step_counter;e.step_counter=int(ck['infos']['unilab_progress']['env_steps_per_env']);e._next_push_step+=e.step_counter-old;e._update_curriculum()
        e.init_state();e.set_autoreset(False);original=e._maybe_resample_commands
        def command(state,advance=True):
            if hasattr(e,'_requested'):
                e._requested[:]=[.3,0,0];e._next_switch[:]=1e12
                if hasattr(e,'_task_kind'):e._task_kind[:]=0
                if hasattr(e,'_feedback'):e._feedback[:]=False
                if advance:original(state)
            elif hasattr(e,'_dir_commands'):
                e._dir_commands[:]=0;e._dir_commands[:,0]=.3;e._dir_next_switch[:]=1e12;e._dir_kind[:]=0;state.info['commands'][:]=e._dir_commands
            else:state.info['commands'][:]=0;state.info['commands'][:,0]=.3
        e._maybe_resample_commands=command
        detector=StepMeasurement(n,e.cfg.ctrl_dt)
        alive=np.ones(n,bool);terminated=np.zeros(n,bool);air=np.zeros((n,2),bool);peak=np.zeros((n,2));steps=np.zeros((n,2),int);velocities=[];headings=[];contacts=[];positions=[];events=[[] for _ in range(n)]
        for tick in range(600):
            command(e.state,advance=False);obs=e.state.obs['obs'].copy();obs[:,48:51]=[.3,0,0]
            if hasattr(e,'_phase'):
                obs[:,59:61]=e._phase.encode()
                if hasattr(e._phase,'encode_task'):obs[:,56:59]=e._phase.encode_task()
                if hasattr(e._phase,'encode_motion'):obs[:,51:56]=e._phase.encode_motion()
            with torch.inference_mode():actions=actor(torch.as_tensor(obs,dtype=torch.float32,device='cuda')).cpu().numpy()
            result=e.step(actions);assert np.isfinite(actions).all() and np.isfinite(result.reward).all()
            q=e._backend.get_physics_state()[:,1:22]
            tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,4]**2+q[:,5]**2),-1,1)))
            alive&=(tilt<20)&(q[:,2]>g['CONTRACT']['fall_height_m']);terminated|=result.terminated
            h=e._foot_height
            feet=np.stack([e._backend.get_sensor_data(name) for name in e.cfg.sensor.feet_pos],axis=1)
            yaw=np.arctan2(2*(q[:,3]*q[:,6]+q[:,4]*q[:,5]),1-2*(q[:,5]**2+q[:,6]**2))
            placement=detector.update(feet,h,yaw,q[:,:2],np.full(n,.3))
            steps+=placement['valid']
            if tick>=100:
                for case,side in zip(*np.nonzero(placement['valid'])):
                    events[case].append(dict(time=(tick+1)*.02,side=int(side),length=float(placement['length'][case,side]),root_progress=float(placement['root_progress'][case,side]),interval=float(placement['interval'][case,side])))
            if target_contract is not None:positions.append(q[:,:2].copy())
            if tick>=100:
                velocities.append(e.get_local_linvel()[:,0].copy())
                if hasattr(e,'_gait_style'):headings.append(e._gait_style.heading(e));contacts.append(e._contact.copy())
        speed=np.mean(velocities,axis=0);motion=alive&~terminated&(speed>=.06)&(steps.min(1)>=3)
        style_ok=np.ones(n,bool);mean_heading=None;revision=None
        if headings:
            h=np.degrees(np.asarray(headings));contact=np.asarray(contacts);style=e._gait_style
            mean_heading=np.full((n,2),np.nan)
            for case in range(n):
                for side in range(2):
                    values=h[:,case,side][contact[:,case,side]]
                    if len(values):mean_heading[case,side]=values.mean()
            low=np.degrees(style.low)-3.;high=np.degrees(style.high)+3.
            style_ok=np.isfinite(mean_heading).all(1)&(mean_heading>=low).all(1)&(mean_heading<=high).all(1);revision=style.contract['revision']
        step_ok=np.ones(n,bool);speed_ok=np.ones(n,bool);step_stats=None;speed_max=None
        if target_contract is not None:
            goal=target_contract['stage_step_goals_m'][g['ID']]
            step_stats=[summarize(case) for case in events];step_ok=np.asarray([accept(s,goal) for s in step_stats])
            xy=np.asarray(positions);speed2s=np.linalg.norm(xy[100:]-xy[:-100],axis=2)/2.;speed_max=speed2s.max(0)
            speed_ok=speed_max<=target_contract['speed_upper_m_s']
        good=motion&style_ok&step_ok&speed_ok
        report=dict(status='PASS' if good.mean()>=.75 else 'FAIL',stage=g['ID'],checkpoint_sha256=g['sha'](checkpoint),cases=n,seconds=12,passed_cases=int(good.sum()),motion_passed_cases=int(motion.sum()),style_passed_cases=int(style_ok.sum()),required_fraction=.75,command=[.3,0,0],mean_vx_m_s=speed.tolist(),steps_per_foot=steps.tolist(),physically_stable=alive.tolist(),environment_terminated=terminated.tolist(),loaded_foot_heading_deg=mean_heading.tolist() if mean_heading is not None else None,gait_style_revision=revision,pass_definition='Stable with no episode termination, mean vx>=.06m/s, >=3 measured placements per foot; contact hysteresis1/2mm; no8mm height censoring; signed loaded foot headings within frozen reference envelope +3deg when style contract is active',not_final_acceptance=True)
        if target_contract is not None:
            report.update(step_goal_m=goal,step_target_revision=target_contract['revision'],step_passed_cases=int(step_ok.sum()),speed_passed_cases=int(speed_ok.sum()),step_statistics=step_stats,speed2s_max_m_s=speed_max.tolist(),pass_definition=report['pass_definition']+'; additionally13cm step-target statistics and 0.35m/s maximum 2s translation speed')
        report['performance_gate_enforced']=performance_gates_enabled(B)
        report['measurement_revision']='v201_route_contact_measurement_20261108'
        report['stage_has_explicit_step_goal']=target_contract is not None
        if step_stats is not None:report['step_count_per_case']=[s['step_count'] for s in step_stats]
        g['atomic'](B/'runs'/g['ID']/'PHYSICAL_QUALIFICATION.json',report)
        print('PHYSICAL_QUALIFICATION',g['ID'],report,flush=True)
        if report['performance_gate_enforced']:
            assert report['status']=='PASS','Gait/style regression: downstream training must not start'
    finally:e.close()

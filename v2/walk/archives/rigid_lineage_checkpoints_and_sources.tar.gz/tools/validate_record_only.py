from pathlib import Path
import sys,runpy,json
B=Path(__file__).resolve().parents[1];R=B/'continue_without_performance_gates_20261107';sys.path.insert(0,str(B/'tools'))
from execution_policy import performance_gates_enabled
assert not performance_gates_enabled(B)
import policy_validation
original=policy_validation.run
record={}
def isolated(g):
 save=g['atomic']
 def atomic(path,obj):
  if Path(path).name=='PHYSICAL_QUALIFICATION.json':record.update(obj);save(R/'RECORD_ONLY_VALIDATION.json',obj)
  else:save(path,obj)
 g['atomic']=atomic
 return original(g)
policy_validation.run=isolated
sys.argv=[str(B/'tools/stage_entry.py'),'--stage','P10','--mode','qualify','--checkpoint',str(B/'runs/P10/ppo_run/model_199.pt'),'--envs','4']
runpy.run_path(str(B/'tools/stage_entry.py'),run_name='__main__')
assert record['status']=='FAIL' and record['performance_gate_enforced'] is False
print('RECORD_ONLY_VALIDATION_PASS: measured FAIL preserved, process continued normally',flush=True)

"""Serial, fail-stop orchestration for the new model and new checkpoint lineage."""
from pathlib import Path
import argparse, fcntl, hashlib, json, os, subprocess, sys, time
import numpy as np
import torch
from execution_policy import performance_gates_enabled

B=Path(__file__).resolve().parents[1];PLAN=json.loads((B/'route_plan.json').read_text());NODES=PLAN['nodes'];BYID={n['id']:n for n in NODES}
ap=argparse.ArgumentParser();ap.add_argument('--preflight',action='store_true');ap.add_argument('--execute',action='store_true');ap.add_argument('--resource-check',action='store_true');a=ap.parse_args()
def free_gpu_mib():return int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip().splitlines()[0])
if a.resource_check:
    print(json.dumps({'free_gpu_MiB':free_gpu_mib(),'required_MiB_for_4096_env_stage':12288,'required_MiB_for_small_worker':9216}));raise SystemExit(0)
assert a.preflight!=a.execute
if a.execute and (restart_guard:=B/'audit/GAIT_RESTART_REQUIRED.json').exists():
    if json.loads(restart_guard.read_text()).get('status')!='PREPARED_FRESH_P00':
        raise SystemExit('Route remains paused: prepare and validate a fresh P00 lineage; pre-fix checkpoints cannot be skipped or reused as training parents.')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def atomic(p,x):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2));os.replace(tmp,p)
def step(stage,mode,*extra):
    log=B/'logs'/f'{stage}_{mode}_{"preflight" if a.preflight else "formal"}.log'
    argv=[sys.executable,'-u',str(B/'tools/stage_entry.py'),'--stage',stage,'--mode',mode,*map(str,extra)]
    if a.execute:
        required=12288 if mode=='train' and BYID[stage]['num_envs']==4096 else 9216
        last=None
        while (available:=free_gpu_mib())<required:
            atomic(B/'ROUTE_STATUS.json',dict(status='WAITING_FOR_GPU_MEMORY',stage=stage,operation=mode,pid=os.getpid(),free_gpu_MiB=available,required_gpu_MiB=required,other_processes_untouched=True,updated_unix=time.time()))
            if last!=available:print('GPU_MEMORY_QUEUE',stage,available,required,flush=True);last=available
            time.sleep(5)
    print('DISPATCH',json.dumps(argv),flush=True)
    atomic(B/'ROUTE_STATUS.json',dict(status='PREFLIGHT' if a.preflight else 'RUNNING',stage=stage,operation=mode,pid=os.getpid(),log=str(log.relative_to(B)),started_unix=time.time()))
    env=os.environ.copy()
    if a.execute:env['XDUCK_RESET_WAIT_TIMEOUT_S']='0'  # Preserve physics; wait indefinitely for other GPU users.
    with log.open('w') as f:subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,cwd=B)
def output(stage):
    d=json.loads((B/'runs'/stage/'COMPLETE.json').read_text());p=B/d['checkpoint'];assert sha(p)==d['sha256']
    if (style:=B/'audit/GAIT_STYLE_CONTRACT.json').exists():
        meta=torch.load(p,map_location='cpu',weights_only=False)['infos']['new_lineage']
        assert meta.get('gait_style_revision')==json.loads(style.read_text())['revision'],'Pre-fix checkpoint cannot be reused in the corrected route'
    if (target:=B/'audit/STEP_TARGET_CONTRACT.json').exists():
        contract=json.loads(target.read_text())
        if stage in contract['validation_stages']:
            meta=torch.load(p,map_location='cpu',weights_only=False)['infos']['new_lineage']
            assert meta.get('step_target_revision')==contract['revision'] and abs(meta.get('step_goal_m',0)-contract['stage_step_goals_m'][stage])<1e-9
    return p
def fixture(stage):return B/'audit'/f'{stage}_fixture.pt'
def prep_fixture(stage):
    n=BYID[stage];parent=n['parent']
    if parent:
        path=fixture(parent);ck=torch.load(path,map_location='cpu',weights_only=False)
        ck['infos']['unilab_progress']['env_steps_per_env']=(n['planned_cumulative_ppo_updates']-n['selected_updates_in_this_stage'])*24
        ck['infos']['synthetic_curriculum_progress_for_preflight_only']=True
        path=B/'audit'/f'{stage}_input_fixture.pt';torch.save(ck,path)
        rng=np.random.default_rng(n['seed']);o=rng.normal(0,.02,(512,61)).astype(np.float32)
        np.savez_compressed(B/'audit'/f'{stage}_anchor_fixture.npz',obs=o,mean=np.zeros((512,14),np.float32),mask=np.ones((512,14),np.float32),phase=np.zeros(512,int) if stage in ['P12','P13'] else np.arange(512)%(4 if stage=='P07' else 3),std=np.full(14,.15,np.float32))
        return ['--fixture','--checkpoint',str(path)]
    return []
def merge_bc():
    r=B/'runs/P11';parts=[]
    for filename,pools in [('forward_teacher.npz',[0]),('direction_teacher.npz',[1,2])]:
        z=np.load(r/filename);keep=np.isin(z['phase'],pools);parts.append({k:z[k][keep] for k in ['obs','mean','mask','phase']})
        meta=json.loads((r/filename).with_suffix('.json').read_text());assert meta['status']=='PASS'
    merged={k:np.concatenate([p[k] for p in parts]) for k in parts[0]};assert all((merged['phase']==i).sum()>=(100 if performance_gates_enabled(B) else 2) for i in range(3))
    p=r/'anchor.npz';np.savez_compressed(p,**merged,std=np.full(14,.15,np.float32))
    atomic(p.with_suffix('.json'),dict(status='PASS',model_sha256=json.loads((B/'audit/MODEL_CONTRACT.json').read_text())['model_sha256'],dataset_sha256=sha(p),sources=['forward_teacher.json','direction_teacher.json'],new_model_physical_rollouts=True))

lock=(B/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
    if a.preflight:
        for n in NODES:
            stage=n['id'];extra=prep_fixture(stage)
            step(stage,'smoke','--envs','32',*extra)
        step('P07','collect','--fixture','--checkpoint',fixture('P06'),'--teacher',fixture('P05'),'--envs','16','--dataset',B/'audit/P07_collector_fixture.npz')
        step('P11','collect','--fixture','--checkpoint',fixture('P10'),'--envs','16','--dataset',B/'audit/P11_collector_fixture.npz')
        # Test the supervised worker on explicitly labelled fixtures; never count these as training.
        for stage,mode in [('P07','bootstrap'),('P11','bc')]:
            path=B/'audit'/f'{stage}_anchor_fixture.npz';atomic(path.with_suffix('.json'),dict(status='FIXTURE_ONLY',model_sha256=json.loads((B/'audit/MODEL_CONTRACT.json').read_text())['model_sha256'],dataset_sha256=sha(path)))
            step(stage,mode,'--fixture','--checkpoint',B/'audit'/f'{stage}_input_fixture.pt','--dataset',path)
        step('P13','evaluate','--fixture','--checkpoint',fixture('P13'),'--envs','40')
        # Full intended batch size exercises actual 5090 memory and contact allocations.
        step('P00','smoke','--envs','4096')
        for stage in ['P00','P01','P02','P03','P05','P06','P07','P09','P10','P11','P12','P13']:
            assert json.loads((B/'audit'/f'{stage}_SMOKE.json').read_text())['status']=='PASS'
        files={str(p.relative_to(B)):sha(p) for p in sorted((B/'tools').glob('*.py'))}
        inputs={}
        for p in (B/'physics').rglob('*'):
            if p.is_file():inputs[str(p.relative_to(B))]=sha(p)
        for run in {n['run'] for n in NODES}:
            source=B/'workspace'/run
            for p in (source/'project/src').rglob('*.py'):inputs[str(p.relative_to(B))]=sha(p)
            for p in source.glob('*.py'):inputs[str(p.relative_to(B))]=sha(p)
        for p in (B/'runs').glob('*/TRAINING_CONFIG.yaml'):inputs[str(p.relative_to(B))]=sha(p)
        inputs['inputs/new_standing_bank.npz']=sha(B/'inputs/new_standing_bank.npz')
        inputs['inputs/heldout_standing_bank.npz']=sha(B/'inputs/heldout_standing_bank.npz')
        atomic(B/'audit/FROZEN_INPUTS.json',inputs)
        atomic(B/'audit/PREFLIGHT_COMPLETE.json',dict(status='PASS_SOFTWARE_AND_PHYSICS',model_sha256=json.loads((B/'audit/MODEL_CONTRACT.json').read_text())['model_sha256'],tools_sha256=files,stages=[n['id'] for n in NODES],total_planned_ppo_updates=3442,formal_training_started=False,teacher_quality_must_be_checked_after_each_real_parent_exists=True))
        atomic(B/'ROUTE_STATUS.json',dict(status='READY_FOR_TRAINING',updated_unix=time.time()))
    else:
        pre=json.loads((B/'audit/PREFLIGHT_COMPLETE.json').read_text());assert pre['status']=='PASS_SOFTWARE_AND_PHYSICS'
        assert pre['model_sha256']==json.loads((B/'audit/MODEL_CONTRACT.json').read_text())['model_sha256']
        for name,h in pre['tools_sha256'].items():assert sha(B/name)==h,name
        for name,h in json.loads((B/'audit/FROZEN_INPUTS.json').read_text()).items():assert sha(B/name)==h,name
        for n in NODES:
            stage=n['id'];r=B/'runs'/stage
            if (r/'COMPLETE.json').exists():
                checkpoint=output(stage)
                if (B/'audit/GAIT_STYLE_CONTRACT.json').exists() or stage=='P05':
                    qualification=r/'PHYSICAL_QUALIFICATION.json'
                    accepted=json.loads(qualification.read_text()) if qualification.exists() else {}
                    if accepted.get('checkpoint_sha256')!=sha(checkpoint) or (performance_gates_enabled(B) and accepted.get('status')!='PASS'):
                        step(stage,'qualify','--checkpoint',checkpoint)
                exported=B/'exports'/f'{stage}.json'
                export_meta=json.loads(exported.read_text()) if exported.exists() else {}
                if export_meta.get('checkpoint_sha256')!=sha(checkpoint):step(stage,'export','--checkpoint',checkpoint)
                continue
            # Restarting a failed stage never silently discards partially trained weights.
            resume_args=[]
            if (r/'ppo_run').exists():
                approved=json.loads((r/'RESUME_APPROVED.json').read_text());checkpoint=B/approved['checkpoint']
                assert stage in ['P00','P01','P02','P03'] and approved['stage']==stage
                assert sha(checkpoint)==approved['sha256']
                saved=sorted((r/'ppo_run').glob('model_*.pt'),key=lambda p:int(p.stem.split('_')[-1]));assert saved[-1]==checkpoint
                resume_args=['--resume',str(checkpoint)]
            if stage not in ['P00','P01','P02','P03']:
                if stage=='P11':
                    step(stage,'collect','--checkpoint',output('P10'),'--dataset',r/'forward_teacher.npz')
                    step(stage,'collect','--checkpoint',output('P07'),'--dataset',r/'direction_teacher.npz')
                    merge_bc();step(stage,'bc')
                elif stage=='P07':
                    step(stage,'collect','--teacher',output('P05'));step(stage,'bootstrap')
                else:step(stage,'collect')
                data=json.loads((r/'anchor.json').read_text());assert data['status']=='PASS' and data['dataset_sha256']==sha(r/'anchor.npz')
            step(stage,'train',*resume_args);output(stage)
            if (B/'audit/GAIT_STYLE_CONTRACT.json').exists() or stage=='P05':step(stage,'qualify','--checkpoint',output(stage))
            step(stage,'export','--checkpoint',output(stage))
        step('P13','evaluate','--checkpoint',output('P13'))
        evaluation=json.loads((B/'exports/FINAL_EVALUATION.json').read_text())
        atomic(B/'ROUTE_STATUS.json',dict(status='TRAINING_COMPLETE',evaluation_status=evaluation['status'],ppo_updates=3442,final_checkpoint=str(output('P13').relative_to(B)),updated_unix=time.time()))
except Exception as error:
    status=json.loads((B/'ROUTE_STATUS.json').read_text()) if (B/'ROUTE_STATUS.json').exists() else {}
    status.update(status='FAILED_STOPPED',error=str(error),updated_unix=time.time());atomic(B/'ROUTE_STATUS.json',status)
    raise

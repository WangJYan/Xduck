"""Physical final evaluation using the new HOME and new height thresholds."""
import numpy as np
import torch
from step_measurement import StepMeasurement,summarize

def run(g):
    args=g['args'];assert g['ID']=='P13';B=g['B'];contract=g['CONTRACT'];fixture=args.fixture
    p=g['parent_path']();ck=g['load_new'](p,fixture);actor=g['Decoder'](ck).to('cuda').eval();c=g['config'](ck)
    if (B/'inputs/heldout_standing_bank.npz').exists():c.env.newstand_bank_path=str(B/'inputs/heldout_standing_bank.npz')
    names=['forward','backward','forward_left','forward_right','backward_left','backward_right','inplace_left','inplace_right','side_left','side_right']
    commands=np.array([[.3,0,0],[-.3,0,0],[.3,0,.4],[.3,0,-.4],[-.3,0,.4],[-.3,0,-.4],[0,0,.4],[0,0,-.4],[0,.1,0],[0,-.1,0]])
    n=args.envs or 320;assert n%10==0;K=n//10;cmd=np.repeat(commands,K,axis=0);kind=np.repeat(np.arange(10),K)
    e=g['setup_env'](c,n)
    try:
        e.set_loss_update(400);e.init_state();e.set_autoreset(False)
        old=e._maybe_resample_commands
        def set_command(st):
            e._requested[:]=cmd;e._task_kind[:]=kind;e._next_switch[:]=1e12;e._feedback[:]=False;old(st)
        e._requested[:]=cmd;e._task_kind[:]=kind;e._next_switch[:]=1e12;e._feedback[:]=False
        q0=e._backend.get_physics_state()[:,1:22].copy();q=q0.copy()
        yaw0=np.arctan2(2*(q0[:,3]*q0[:,6]+q0[:,4]*q0[:,5]),1-2*(q0[:,5]**2+q0[:,6]**2))
        e._phase.reset(np.arange(n),yaw0,offset=np.arange(n)%2*.5,body_xy=q0[:,:2],requested=cmd)
        e._phase.advance(yaw0,cmd,dt=0,feedback=False,body_xy=q0[:,:2])
        e._maybe_resample_commands=set_command
        detector=StepMeasurement(n,e.cfg.ctrl_dt)
        frames=[];air=np.zeros((n,2),bool);peak=np.zeros((n,2));lands=[[] for _ in range(n)];events=[[] for _ in range(n)]
        for tick in range(64 if fixture else 1000):
            obs=e.state.obs['obs'].copy()
            # First-frame phase/task encoding follows the same contract as later frames.
            obs[:,59:61]=e._phase.encode();obs[:,56:59]=e._phase.encode_task();obs[:,51:56]=e._phase.encode_motion()
            obs[:,48:51]=e._phase.command_for_policy
            with torch.inference_mode():action=actor(torch.tensor(obs,dtype=torch.float32,device='cuda')).cpu().numpy()
            st=e.step(action);assert np.isfinite(st.reward).all() and np.isfinite(action).all()
            phi=e._backend.get_physics_state();q=phi[:,1:22].copy();velocity=e.get_local_linvel().copy();h=e._foot_height.copy();peak=np.maximum(peak,h)
            feet=np.stack([e._backend.get_sensor_data(s) for s in e.cfg.sensor.feet_pos],axis=1)
            yaw=np.arctan2(2*(q[:,3]*q[:,6]+q[:,4]*q[:,5]),1-2*(q[:,5]**2+q[:,6]**2))
            placement=detector.update(feet,h,yaw,q[:,:2],cmd[:,0])
            for case,side in zip(*np.nonzero(placement['valid'])):
                lands[case].append((tick*.02,int(side)))
                if tick>=200:events[case].append(dict(time=(tick+1)*.02,side=int(side),length=float(placement['length'][case,side]),root_progress=float(placement['root_progress'][case,side]),interval=float(placement['interval'][case,side])))
            frames.append(dict(qpos=q,velocity=velocity,contact=e._contact.copy(),heading_error=e._phase.heading_error.copy(),yaw_rate=e._audit_task['yaw_rate'].copy(),speed=e._audit_task['speed2s'].copy()))
        z={k:np.stack([f[k] for f in frames]) for k in frames[0]}
        from metrics import alternating_step_statistics
        report=[];start=0 if fixture else 100
        for j in range(n):
            q=z['qpos'][:,j];tilt=np.degrees(np.arccos(np.clip(1-2*(q[:,4]**2+q[:,5]**2),-1,1)))
            stable=bool(tilt.max()<20 and q[:,2].min()>contract['fall_height_m'])
            head=float(np.percentile(np.degrees(abs(q[start:,7:][:,5:9]-np.array(contract['home_joint_qpos'])[5:9])),95))
            stats=summarize(events[j])
            side=kind[j]>=8;walk=kind[j]<6;inplace=kind[j] in [6,7];delta=q[-1,:2]-q0[j,:2]
            forward=np.array([np.cos(yaw0[j]),np.sin(yaw0[j])]);left=np.array([-np.sin(yaw0[j]),np.cos(yaw0[j])])
            herror=float(np.degrees(abs(z['heading_error'][start:,j])).max());werr=float(np.mean(abs(z['yaw_rate'][start:,j]-cmd[j,2])))
            signpass=float(np.mean(np.sign(z['yaw_rate'][start:,j])==np.sign(cmd[j,2])))>=.8 if abs(cmd[j,2])>.1 else True
            turn=bool(werr<.15 and herror<20 and signpass)
            if inplace:turn=turn and np.linalg.norm(delta)<.30
            from step_target import accept
            gait=(not walk) or accept(stats,float(c.env.step_goal_m))
            counts=[sum(s==i for _,s in lands[j]) for i in [0,1]];dist=float(delta@left)*(1 if kind[j]==8 else -1)
            last=min(100,len(q));sidepass=(not side) or (.07<=dist<=.13 and abs(delta@forward)<=.04 and np.linalg.norm(z['velocity'][-last:,j,:2],axis=1).mean()<.04 and z['contact'][-last:,j].all(1).mean()>.8 and min(counts)>=1 and max(counts)<=2 and herror<10)
            startup=bool(lands[j] and lands[j][0][0]<=(1.2 if side else .8));speed=bool(z['speed'][start:,j].max()<=.35)
            report.append(dict(scenario=names[kind[j]],case=j%K,stable=stable,max_tilt_deg=float(tilt.max()),min_height_m=float(q[:,2].min()),head_deviation_from_HOME_p95_deg=head,head_pass=head<=5,turn_pass=bool(turn),gait_pass=bool(gait),side_pass=bool(sidepass),startup_pass=startup,speed_pass=speed,left_step_median_m=stats['left_step_median_m'],right_step_median_m=stats['right_step_median_m'],all_pass=bool(stable and head<=5 and turn and gait and sidepass and startup and speed)))
        summary={name:{k:sum(bool(r[k]) for r in report if r['scenario']==name) for k in ['stable','head_pass','turn_pass','gait_pass','side_pass','startup_pass','speed_pass','all_pass']} for name in names}
        target=B/'audit/EVALUATION_FIXTURE.json' if fixture else B/'exports/FINAL_EVALUATION.json'
        g['atomic'](target,dict(status='FIXTURE_FINITE_ONLY' if fixture else ('ALL_MET' if all(r['all_pass'] for r in report) else 'NEEDS_REVIEW'),checkpoint_sha256=g['sha'](p),measurement_revision='v201_route_contact_measurement_20261108',cases_per_scenario=K,seconds=len(frames)*.02,model_contract=contract,summary=summary,records=report))
        print('EVALUATION',summary,flush=True)
    finally:e.close()

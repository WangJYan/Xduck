from pathlib import Path
import json,hashlib
from omegaconf import OmegaConf
B=Path(__file__).resolve().parents[1];BASE=B.parent/'xduck_2_0_1_no_flex_20261106'
def flat(x,p=''):
 out={}
 if isinstance(x,dict):
  for k,v in x.items():out.update(flat(v,p+'.'+k if p else k))
 else:out[p]=x
 return out
allowed={'env.action_offset_low','env.action_offset_high','env.smooth_head_target','env.smooth_walk_height_m','env.fast_step_start_m','env.fast_step_goal_m','env.fast_step_minimum_m','env.fast_step_maximum_m','env.step_goal_m'}
plan=json.loads((B/'route_plan.json').read_text());baseplan=json.loads((BASE/'route_plan.json').read_text());rows=[]
for n,old in zip(plan['nodes'],baseplan['nodes']):
 for key in ['id','parent','num_envs','selected_updates_in_this_stage','optimizer','seed','epochs','minibatches']:
  assert n.get(key)==old.get(key),(n['id'],key)
 a=flat(OmegaConf.to_container(OmegaConf.load(BASE/'runs'/n['id']/'TRAINING_CONFIG.yaml'),resolve=True));b=flat(OmegaConf.to_container(OmegaConf.load(B/'runs'/n['id']/'TRAINING_CONFIG.yaml'),resolve=True));changes=[]
 for k in set(a)|set(b):
  u=a.get(k);v=b.get(k)
  if isinstance(u,str):u=u.replace(str(BASE),'BRANCH')
  if isinstance(v,str):v=v.replace(str(B),'BRANCH')
  if u!=v:
   assert k in allowed,(n['id'],k,u,v);changes.append(k)
 rows.append(dict(stage=n['id'],updates=n['selected_updates_in_this_stage'],num_envs=n['num_envs'],allowed_config_changes=sorted(changes)))
for n in plan['nodes']:
 for f in ['balance_objective.py','task_adapter.py','mirror_policy.py','policy_setup.py','head_freeze.py']:
  a=BASE/'workspace'/n['run']/f;b=B/'workspace'/n['run']/f
  if a.exists():assert a.read_bytes()==b.read_bytes(),(n['id'],f)
entry=(B/'tools/stage_entry.py').read_text();assert 'motion_repair' not in entry and 'freeze_home_head' not in entry
report=dict(status='PASS',baseline=str(BASE),scope='2.0.2 model adaptation +13cm target constants +step detection/measurement fix only',stage_order_unchanged=True,update_counts_unchanged=True,native_batch_sizes_unchanged=True,learning_rates_and_optimizers_unchanged=True,command_samplers_unchanged=True,reward_function_shapes_and_weights_unchanged=True,head_training_schedule_unchanged=True,phase_and_feedback_modules_unchanged=True,stages=rows)
(B/'audit/BASELINE_SCOPE_VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

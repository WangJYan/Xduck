from pathlib import Path
import importlib.util,json,csv,hashlib
import numpy as np,mujoco
from step_measurement import StepMeasurement,summarize
B=Path('/home/xingchen/Xduck_branches/xduck_2_0_2_v201route_step10_fromP07_20261109');OLD=B.parent/'xduck_2_0_2_repair13_20261108';tag='P02_250_cum1151';source=OLD/'videos'/(tag+'_trace.npz');z=np.load(source);V=B/'videos';V.mkdir(exist_ok=True)
def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
p09=load('real_P09_objective',B/'workspace/flex50_direct_step20_24_400_20261104/large_step_objective.py');p13=load('real_P13_objective',B/'workspace/stable_step_side400_20261105/balance_objective.py')
assert p09.GOAL==.13
m=mujoco.MjModel.from_binary_path(str(B/'physics/effective_training.mjb'));d=mujoco.MjData(m);corners=np.array([(x,y,z) for x in [-1,1] for y in [-1,1] for z in [-1,1]])
rows=[];summaries=[];allarrays={};maxerr=0.
for case,name in enumerate(['forward','backward','forward_left','forward_right']):
 m.geom_pos[:]=z['geom_pos'][case];m.geom_quat[:]=z['geom_quat'][case];sites=[m.site(s+'_foot').id for s in ['left','right']];geoms=[[m.geom(s+'_foot_collision').id,m.geom('train_'+s+'_foot_pad').id] for s in ['left','right']];det=StepMeasurement(1);pairs=np.zeros((1,2));pairvalid=np.zeros((1,2),bool);events=[];case_rows=[];feet_trace=[];height_trace=[];contact_trace=[];yaw0=None;oracle_contact=np.zeros(2,bool);oracle_support=np.zeros((2,3));oracle_time=np.zeros(2);oracle_known=np.zeros(2,bool);oracle_on=np.zeros(2,int);oracle_yaw=np.zeros(2)
 cmd=np.array([[.3 if case!=1 else -.3,0,.4 if case==2 else -.4 if case==3 else 0.]])
 # Distances do not depend on requested speed magnitude; use the recorded binding below.
 cmd=np.asarray(json.loads((OLD/'videos'/(tag+'_video_binding.json')).read_text())['commands'])[case:case+1]
 for tick,q in enumerate(z['qpos'][:,case]):
  d.qpos[:]=q;mujoco.mj_forward(m,d);feet=d.site_xpos[sites].copy();height=[]
  for gs in geoms:
   mins=[]
   for gid in gs:
    if m.geom_type[gid]==7:
     k=m.geom_dataid[gid];vertices=m.mesh_vert[m.mesh_vertadr[k]:m.mesh_vertadr[k]+m.mesh_vertnum[k]]
    else:vertices=corners*m.geom_size[gid]
    mins.append(float((vertices@d.geom_xmat[gid].reshape(3,3).T+d.geom_xpos[gid])[:,2].min()))
   height.append(max(0.,min(mins)))
  height=np.array(height)[None];yaw=np.array([np.arctan2(2*(q[3]*q[6]+q[4]*q[5]),1-2*(q[5]**2+q[6]**2))]);yaw0=yaw.copy() if yaw0 is None else yaw0
  r=det.update(feet[None],height,yaw,q[None,:2],cmd[:,0]);sign=-1 if cmd[0,0]<0 else 1
  oracle_contact=np.where(height[0]<=.001,True,np.where(height[0]>=.002,False,oracle_contact))
  oracle_on=np.where(oracle_contact,oracle_on+1,0)
  for side in [0,1]:
   if oracle_on[side]>=3 and not oracle_known[side]:oracle_support[side]=feet[side];oracle_yaw[side]=yaw[0];oracle_known[side]=True
  oracle_ref=oracle_support[::-1].copy();oracle=np.zeros(2)
  for side in [0,1]:
   other=1-side;age=(tick+1)*.02-oracle_time[other];delta=yaw[0]-oracle_yaw[other];middle=yaw[0]-.5*np.arctan2(np.sin(delta),np.cos(delta))
   if oracle_known[other] and age<=1.5000001:oracle[side]=float((feet[side]-oracle_ref[side])@np.array([np.cos(middle),np.sin(middle),0]))*sign
  for side in np.flatnonzero(r['landing'][0]):oracle_support[side]=feet[side];oracle_time[side]=(tick+1)*.02;oracle_yaw[side]=yaw[0];oracle_known[side]=True


  error=float(abs(oracle-r['length'][0]).max());maxerr=max(maxerr,error);assert error<1e-10
  landing=r['landing'];valid=r['valid'];pairvalid[landing&~valid]=False
  if landing.any() and not r['alternating'][0]:pairvalid[:]=False
  pairs[valid]=r['length'][valid];pairvalid[valid]=True
  xy=z['qpos'][:,case,:2];old=max(0,tick-100);elapsed=max(.02,(tick-old)*.02);net=(q[:2]-xy[old])/elapsed;speed=np.array([np.linalg.norm(net)]);heading=np.arctan2(np.sin(yaw-yaw0),np.cos(yaw-yaw0));lateral=np.array([-np.sin(yaw[0])*net[0]+np.cos(yaw[0])*net[1]])
  reward09=p09.touchdown_credit(valid,pairvalid,pairs,r['peak'],heading,lateral,speed)
  zero=np.zeros(1);zero2=np.zeros((1,2));zero3=np.zeros((1,3));one=np.ones(1);contact=r['contact'];height_quality=r['peak']
  result13=p13.terms(valid,pairs,height_quality,zero2,height,contact,zero2,height,~contact,one,speed,zero,cmd,pairvalid.all(1).astype(float),lateral,.13,True,local_velocity=z['velocity'][tick,case:case+1],requested=cmd,heading_error=heading,side=np.zeros(1,bool),side_displacement=zero,forward_displacement=zero,segment_age=np.array([(tick+1)*.02]),side_lands=zero2,side_tracking=zero,extra_events=zero,net_velocity=net[None],side_foot_cost=zero,side_goal=one*.1,roll=zero,pitch=zero,has_started=np.ones(1,bool),first_step_event=np.zeros(1,bool),step_interval=r['interval'],loss_update=400)
  row=dict(scenario=name,frame=tick,time_s=(tick+1)*.02,left_x=float(feet[0,0]),left_y=float(feet[0,1]),right_x=float(feet[1,0]),right_y=float(feet[1,1]),body_yaw_rad=float(yaw[0]),left_clearance_mm=float(height[0,0]*1000),right_clearance_mm=float(height[0,1]*1000),left_peak_mm=float(r['peak'][0,0]*1000),right_peak_mm=float(r['peak'][0,1]*1000),left_contact=int(contact[0,0]),right_contact=int(contact[0,1]),left_landing=int(landing[0,0]),right_landing=int(landing[0,1]),left_valid=int(valid[0,0]),right_valid=int(valid[0,1]),left_length_cm=float(r['length'][0,0]*100),right_length_cm=float(r['length'][0,1]*100),left_oracle_cm=float(oracle[0]*100),right_oracle_cm=float(oracle[1]*100),left_root_progress_cm=float(r['root_progress'][0,0]*100),right_root_progress_cm=float(r['root_progress'][0,1]*100),P09_landing_reward=float(reward09[0]),P13_landing_reward=float(result13['landing'][0]),left_reference_x=float(oracle_ref[0,0]),left_reference_y=float(oracle_ref[0,1]),right_reference_x=float(oracle_ref[1,0]),right_reference_y=float(oracle_ref[1,1]),oracle_error_m=error)
  rows.append(row);case_rows.append(row);feet_trace.append(feet);height_trace.append(height[0]);contact_trace.append(contact[0])
  if tick>=100:
   for s in np.flatnonzero(valid[0]):events.append(dict(time=(tick+1)*.02,side=int(s),length=float(r['length'][0,s]),root_progress=float(r['root_progress'][0,s]),interval=float(r['interval'][0,s])))
 stats=summarize(events);stats.update(scenario=name,low_clearance_placements=sum(1 for rr in case_rows[100:] for s in ['left','right'] if rr[s+'_valid'] and rr[s+'_peak_mm']<8),maximum_P09_landing_reward_after2s=max(rr['P09_landing_reward'] for rr in case_rows[100:]),maximum_P13_landing_reward_after2s=max(rr['P13_landing_reward'] for rr in case_rows[100:]))
 summaries.append(stats);allarrays[name+'_feet']=np.array(feet_trace);allarrays[name+'_height']=np.array(height_trace);allarrays[name+'_contact']=np.array(contact_trace);print('FRAME_REVIEW',name,stats,flush=True)
with (V/(tag+'_frame_review.csv')).open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
np.savez_compressed(V/(tag+'_verified_geometry.npz'),**allarrays)
# Verify the real unmodified baseline reward function on known distances.
known={}
for length in [.03,.13]:
 known[str(length)]=float(p09.touchdown_credit(np.array([[True,False]]),np.ones((1,2),bool),np.full((1,2),length),np.full((1,2),.035),np.zeros(1),np.zeros(1),np.full(1,.3))[0])
assert known['0.03']<known['0.13']*.1
report=dict(status='PASS',source_trace=str(source),source_trace_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),video_checkpoint_binding=json.loads((OLD/'videos'/(tag+'_video_binding.json')).read_text()),frames_per_scenario=1000,scenarios=4,all_4000_frames_oracle_checked=True,maximum_measurement_oracle_error_m=maxerr,measurement_revision='v201_route_contact_measurement_20261108',reward_scope='Original P09/P13 landing reward components evaluated on the SAME recorded trajectory; not a claim about the old P02 full training reward',known_real_P09_landing_rewards=known,summary=summaries,trajectory_changed=False)
(V/(tag+'_measurement_reward_review.json')).write_text(json.dumps(report,indent=2))

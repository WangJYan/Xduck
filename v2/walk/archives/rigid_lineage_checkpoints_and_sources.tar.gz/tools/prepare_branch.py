"""Prepare an isolated new-robot route; never start training or load old weights."""
from pathlib import Path
import json, shutil, hashlib, re, sys, xml.etree.ElementTree as ET
import numpy as np
import mujoco
from omegaconf import OmegaConf

B=Path(__file__).resolve().parents[1]
W=B/'workspace'
PLAN=json.loads((B/'route_plan.json').read_text())
SOURCES={n['id']:W/n['run'] for n in PLAN['nodes']}
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def model():
    dest=B/'physics'
    if dest.exists():shutil.rmtree(dest)
    shutil.copytree(B/'inputs/Xduck_2.0.2',dest)
    original=mujoco.MjModel.from_xml_path(str(dest/'scene.xml'))
    d=mujoco.MjData(original);mujoco.mj_resetData(original,d);mujoco.mj_forward(original,d)
    base=original.body('base_link').id;imu=original.site('imu').id
    imu_pos=d.xmat[base].reshape(3,3).T@(d.site_xpos[imu]-d.xpos[base])
    imu_rot=d.xmat[base].reshape(3,3).T@d.site_xmat[imu].reshape(3,3)
    tree=ET.parse(dest/'robot.xml');r=tree.getroot()
    proxy=next(e for e in r.iter('site') if e.get('name')=='policy_aligned_imu')
    proxy.set('pos',' '.join(map(str,imu_pos)));proxy.set('quat','1 0 0 0')
    # Sensor calibration maps the physical IMU axes to body axes at the same point.
    sensor=r.find('sensor')
    if not any(e.get('name')=='root_angmom' for e in sensor):ET.SubElement(sensor,'subtreeangmom',name='root_angmom',body='base_link')
    for body in r.iter('body'):
        name=body.get('name')
        if name:
            ET.SubElement(sensor,'framepos',name='track_pos_w_'+name,objtype='body',objname=name)
            ET.SubElement(sensor,'framequat',name='track_quat_w_'+name,objtype='body',objname=name)
    # Preserve the calibrated GF motor, solver, timestep and torque encoding.
    old=mujoco.MjModel.from_binary_path(str(SOURCES['P00']/'physics/effective_training.mjb'))
    option=r.find('option');option.set('timestep','.001')
    option.set('iterations',str(old.opt.iterations));option.set('ls_iterations',str(old.opt.ls_iterations))
    option.set('tolerance',str(old.opt.tolerance));option.set('solver', ['PGS','CG','Newton'][old.opt.solver])
    option.set('integrator', ['Euler','RK4','implicit','implicitfast'][old.opt.integrator])
    for e in r.find('actuator'):
        e.set('kp','1');e.set('kv','0');e.set('ctrlrange',' '.join(map(str,old.actuator_ctrlrange[0])))
        e.set('forcerange',' '.join(map(str,old.actuator_forcerange[0])));e.set('ctrllimited','true');e.set('forcelimited','true')
    tree.write(dest/'robot.xml',encoding='unicode')
    for geom in r.iter('geom'):
        if geom.get('margin') is not None:geom.set('margin','0')
    tree.write(dest/'robot.xml',encoding='unicode')
    scene=ET.parse(dest/'scene.xml');keys=scene.getroot().find('keyframe')
    home=next(e for e in keys if e.get('name')=='HOME')
    # Legacy source uses STAND; it is an alias of HOME, never motor-zero qpos0.
    alias=ET.SubElement(keys,'key',dict(home.attrib));alias.set('name','STAND')
    scene.write(dest/'scene.xml',encoding='unicode')
    m=mujoco.MjModel.from_xml_path(str(dest/'scene.xml'));d=mujoco.MjData(m)
    mujoco.mj_resetDataKeyframe(m,d,m.key('HOME').id);mujoco.mj_forward(m,d)
    lowest=[]
    for side in ['left','right']:
        g=m.geom(side+'_foot_collision').id;k=m.geom_dataid[g]
        verts=m.mesh_vert[m.mesh_vertadr[k]:m.mesh_vertadr[k]+m.mesh_vertnum[k]]
        world=verts@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]
        lowest.append(float(world[:,2].min()))
    # A small contact margin avoids inserting the soles into the floor at reset.
    ground=m.geom('floor').id;support_minima={}
    for g in range(m.ngeom):
        if g==ground or not ((m.geom_contype[g]&m.geom_conaffinity[ground]) or (m.geom_conaffinity[g]&m.geom_contype[ground])):continue
        rotation=d.geom_xmat[g].reshape(3,3);rz=rotation[2];size=m.geom_size[g];kind=int(m.geom_type[g])
        if kind==7:
            k=m.geom_dataid[g];v=m.mesh_vert[m.mesh_vertadr[k]:m.mesh_vertadr[k]+m.mesh_vertnum[k]];z=(v@rotation.T)[:,2].min()+d.geom_xpos[g,2]
        else:
            if kind==6:radius=np.sum(np.abs(rz)*size)
            elif kind==2:radius=size[0]
            elif kind==3:radius=size[0]+size[1]*abs(rz[2])
            elif kind==5:radius=size[1]*abs(rz[2])+size[0]*np.linalg.norm(rz[:2])
            elif kind==4:radius=np.linalg.norm(rz*size)
            else:raise ValueError(('unsupported ground geometry',kind))
            z=d.geom_xpos[g,2]-radius
        support_minima[m.geom(g).name]=float(z)
    shift=.0001-min(support_minima.values())
    home_q=m.key('HOME').qpos.copy();home_q[2]+=shift
    for key in [home,alias]:key.set('qpos',' '.join(map(str,home_q)))
    scene.write(dest/'scene.xml',encoding='unicode')
    m=mujoco.MjModel.from_xml_path(str(dest/'scene.xml'))
    m.opt.enableflags=old.opt.enableflags;m.opt.disableflags=old.opt.disableflags
    ids=m.actuator_trnid[:,0];qi=m.jnt_qposadr[ids];vi=m.jnt_dofadr[ids]
    m.dof_armature[vi]=old.dof_armature[old.jnt_dofadr[old.actuator_trnid[:,0]]]
    m.dof_damping[vi]=0;m.dof_frictionloss[vi]=0
    mujoco.mj_saveModel(m,str(dest/'effective_training.mjb'),None)
    h=float(home_q[2]);zero=m.qpos0[qi].copy();target=home_q[qi]
    assert m.nu==14 and m.nq==21 and m.nv==20
    assert np.all(target>=m.jnt_range[ids,0]) and np.all(target<=m.jnt_range[ids,1])
    contract=dict(model_sha256=digest(dest/'effective_training.mjb'),joint_names=[m.joint(int(j)).name for j in ids],motor_zero_qpos=zero.tolist(),home_joint_qpos=target.tolist(),home_qpos=home_q.tolist(),nominal_standing_height_m=h,home_source_height_m=float(original.key('HOME').qpos[2]),ground_alignment_shift_m=shift,sole_min_z_before_alignment_m=lowest,ground_geometry_minima_before_alignment=support_minima,standing_height_band_m=[h-.02,h+.02],fall_height_m=h-.07,imu_body_position_m=imu_pos.tolist(),physical_imu_to_body_rotation=imu_rot.tolist(),policy_imu_axes='calibrated body axes at physical IMU position',policy_action_reference='HOME',motor_zero_reference='unmodified MJCF qpos0/joint ref',joint_limits_rad=m.jnt_range[ids].tolist(),mass_kg=float(m.body_mass.sum()),physical_scale_rad=OmegaConf.to_container(OmegaConf.load(SOURCES['P00']/'TRAINING_CONFIG.yaml').env.physical_action_scale_rad))
    (B/'audit/MODEL_CONTRACT.json').write_text(json.dumps(contract,indent=2))
    return contract

def patch_sources(contract):
    edits=[];done=set()
    payload=B/'archive/reproduction_payload';manifest=json.loads((payload/'snapshot_manifest.json').read_text())['files']
    for root in SOURCES.values():
        if root in done:continue
        done.add(root)
        for p in (root/'project/src/unilab').rglob('*.py'):
            logical=str(p.relative_to(W));item=manifest.get(logical)
            old=(payload/'blobs'/item['sha256']).read_text() if item else p.read_text()
            s=old
            s=s.replace('"trunk_base"','"base_link"').replace("'trunk_base'","'base_link'")
            s=s.replace('HEAD_COM_BODY_NAMES = ("neck", "neck_pitch", "yaw_roll_motion", "jaw_soft")','HEAD_COM_BODY_NAMES = ("neck_pitch", "head_pitch", "head_yaw", "head_roll")')
            s=s.replace('self._backend.get_joint_dof_indices(POLICY_JOINT_NAMES)','self._backend.get_joint_dof_indices(self._active_names)')
            s=s.replace('plan.qpos[:, 2] = np.random.uniform(0.12 * SCALE, 0.13 * SCALE, size=n)', 'plan.qpos[:, 2] = env._init_qpos[2]  # HOME height, not the old robot\'s fixed height')
            if p.name=='xduck_gf.py' and 'time.monotonic()-started>600' in s:
                s=s.replace('import time\n','import time\nimport os\n')
                s=s.replace('if time.monotonic()-started>600:', "if float(os.environ.get('XDUCK_RESET_WAIT_TIMEOUT_S','600'))>0 and time.monotonic()-started>float(os.environ.get('XDUCK_RESET_WAIT_TIMEOUT_S','600')):")
            if p.name=='xduck_gf.py':
                from reset_optimization import optimized_source
                s=optimized_source(s)
            if p.name=='actuator.py' and p.parent.name=='gf43x40':
                from motor_gain_optimization import optimized_source
                s=optimized_source(s)
            # Height literals are replaced only in expressions that test base/root height.
            h=contract.get('settled_standing_height_m',contract['nominal_standing_height_m']);fall=contract['fall_height_m']
            for a,b in [('height < .25',f'height < {fall!r}'),('height<.25',f'height<{fall!r}'),('[:,2]<.25',f'[:,2]<{fall!r}'),('[:, 2] < .25',f'[:, 2] < {fall!r}'),('height-.34',f'height-{h+.02!r}'),('.26-height',f'{h-.06!r}-height')]:s=s.replace(a,b)
            if p.name=='rigid_gpu.py':
                # New model topology has no passive flex coordinates in any retained stage.
                s=s.replace('flexible_dr_enabled: bool = True','flexible_dr_enabled: bool = False')
                s=s.replace("[self._backend.get_geom_id(side+'_'+part+'_collision') for side in ['left','right'] for part in ['foot','ankle']]", "[self._backend.get_geom_id(name) for side in ['left','right'] for name in (side+'_foot_collision','train_'+side+'_foot_pad','train_'+side+'_ankle_mount')]")
                s=s.replace('            self._sole_vertices.append(vertices@rot.reshape(3,3).T+m.geom_pos[g])', '''            pad=m.geom('train_'+side+'_foot_pad').id
            pad_corners=np.array([(x,y,z) for x in (-1,1) for y in (-1,1) for z in (-1,1)])*m.geom_size[pad]
            pad_rotation=np.empty(9);mujoco.mju_quat2Mat(pad_rotation,m.geom_quat[pad])
            self._sole_vertices.append(np.concatenate([vertices@rot.reshape(3,3).T+m.geom_pos[g],pad_corners@pad_rotation.reshape(3,3).T+m.geom_pos[pad]]))''')
                s=s.replace("        self._sole_geom_ids=[self._backend.get_geom_id(side+'_foot_collision') for side in ['left','right']]", "        self._sole_geom_ids=[self._backend.get_geom_id(side+'_foot_collision') for side in ['left','right']]\n        self._sole_pad_geom_ids=[self._backend.get_geom_id('train_'+side+'_foot_pad') for side in ['left','right']]")
                s=s.replace('            env._sole_delta_quat[env_ids,j]=dq', '''            pad=env._sole_pad_geom_ids[j]
            v=qp[:,pad].copy()
            qp[:,pad]=v+2*np.cross(u,np.cross(u,v)+dq[:,:1]*v)
            qq[:,pad]=np_quat_mul(dq,qq[:,pad])
            env._sole_delta_quat[env_ids,j]=dq''')
            if p.name=='reset_support.py' and 'primitive_support' not in s:
                s=s.replace('            points = []','            points = []\n            primitive_support = []')
                start=s.index('                else:\n                    raise ValueError(\n                        "Re-audit reset support')
                end=s.index('                rotation = quaternion_matrix',start)
                s=s[:start]+'''                elif model.geom_type[geom] in (mujoco.mjtGeom.mjGEOM_SPHERE,mujoco.mjtGeom.mjGEOM_CAPSULE,mujoco.mjtGeom.mjGEOM_CYLINDER,mujoco.mjtGeom.mjGEOM_ELLIPSOID):
                    primitive_support.append((int(model.geom_type[geom]),model.geom_size[geom].copy(),model.geom_pos[geom].copy(),quaternion_matrix(model.geom_quat[geom])))
                    continue
                else:
                    raise ValueError("Unsupported new collision primitive")
''' + s[end:]
                s=s.replace('                    cloud,','                    cloud,\n                    primitive_support,')
                s=s.replace('for parent, local_pos, local_rot, joints, cloud in self.bodies:', 'for parent, local_pos, local_rot, joints, cloud, primitive_support in self.bodies:')
                s=s.replace('            if len(cloud):','''            for kind,size,offset,local_rotation in primitive_support:
                world_rotation=rotation@local_rotation
                rz=world_rotation[:,2,:]
                center=position[:,2]+np.einsum("ni,i->n",rotation[:,2,:],offset)
                if kind==2: radius=np.full(n,size[0])
                elif kind==3: radius=size[0]+size[1]*np.abs(rz[:,2])
                elif kind==5: radius=size[1]*np.abs(rz[:,2])+size[0]*np.linalg.norm(rz[:,:2],axis=1)
                elif kind==4: radius=np.linalg.norm(rz*size,axis=1)
                else: raise ValueError(kind)
                minimum=np.minimum(minimum,center-radius)
            if len(cloud):''')
            if s!=old:edits.append(str(p.relative_to(B)))
            if s!=p.read_text():p.write_text(s)
    (B/'audit/SOURCE_PATCHES.json').write_text(json.dumps(edits,indent=2))

def configs(contract):
    previous=0
    for n in PLAN['nodes']:
        stage=n['id'];src=SOURCES[stage];root=B/'runs'/stage;root.mkdir(exist_ok=True)
        cfgfile=src/n['config']
        if not cfgfile.exists():cfgfile=src/'TRAINING_CONFIG.yaml'
        c=OmegaConf.load(cfgfile)
        c.env.scene.model_file=str(B/'physics/scene.xml');c.env.scene.visual_model_file=str(B/'physics/scene.xml');c.env.scene.fragment_files=[]
        c.env.warp_compiled_model_file=str(B/'physics/effective_training.mjb');c.env.physics_microsteps=1
        c.env.asset={'base_name':'base_link','ground':'floor'}
        c.env.flexible_dr_enabled=False
        c.env.reset_root_z_offset_m=0.
        c.env.domain_rand.push_body_name='base_link'
        # The policy's zero action is HOME; motor zero is retained separately.
        target=np.array(contract['home_joint_qpos']);limits=np.array(contract['joint_limits_rad'])
        c.env.action_offset_low=(limits[:,0]+1e-5-target).tolist();c.env.action_offset_high=(limits[:,1]-1e-5-target).tolist()
        c.algo.num_envs=n['num_envs'];c.algo.max_iterations=n['selected_updates_in_this_stage'];c.algo.seed=n['seed'];c.algo.save_interval=50
        c.algo.resume=False;c.algo.load_run='-1';c.algo.resume_path=None
        c.training.log_dir=str(root/'ppo_run')
        # Each custom stage has its own local update clock and the historical DR plateau.
        if stage not in ['P00','P01','P02','P03']:
            c.env.startup_initial_step=previous*24
            c.env.newstand_bank_path=str(B/'inputs/new_standing_bank.npz')
            c.env.smooth_head_target=target[[5,6]].tolist()
            if 'smooth_walk_height_m' in c.env:c.env.smooth_walk_height_m=contract.get('settled_standing_height_m',contract['nominal_standing_height_m'])
        if 'reference_path' in c.env and c.env.reference_path:
            # The reference is foot clearance/pitch vs time, independent of old motor angles.
            rp=Path(c.env.reference_path)
            if not rp.exists():raise FileNotFoundError(rp)
        if 'anchor_dataset' in c.algo.algorithm:c.algo.algorithm.anchor_dataset=str(root/'anchor.npz')
        if stage in ['P01','P02','P03']:c.env.stage_schedule_enabled=True
        if stage=='P00':c.env.stage_schedule_enabled=False
        # The latest stage's side-step distance ramp is tracked by local PPO update.
        if stage in ['P09','P10','P11','P12','P13']:
            c.env.newstand_bank_path=str(B/'inputs/new_standing_bank.npz')
        if (step_contract:=B/'audit/STEP_TARGET_CONTRACT.json').exists():
            specification=json.loads(step_contract.read_text())
            if stage in specification['validation_stages']:
                goal=specification['stage_step_goals_m'][stage]
                c.env.step_goal_m=goal;c.env.fast_step_start_m=goal;c.env.fast_step_goal_m=goal
                c.env.fast_step_minimum_m=.9*goal;c.env.fast_step_maximum_m=1.1*goal
        OmegaConf.save(c,root/'TRAINING_CONFIG.yaml')
        meta=dict(stage=stage,source=str(src),parent_stage=n['parent'],updates=n['selected_updates_in_this_stage'],cumulative_before=previous,cumulative_after=previous+n['selected_updates_in_this_stage'],optimizer=n['optimizer'],curriculum_clock='inherited PPO/environment progress' if stage in ['P00','P01','P02','P03'] else 'historical DR plateau plus explicit local stage PPO counter',pose_contract='audit/MODEL_CONTRACT.json')
        (root/'STAGE.json').write_text(json.dumps(meta,indent=2));previous=meta['cumulative_after']
    assert previous==3442

if __name__=='__main__':
    if '--refresh-standing' in sys.argv:
        c=json.loads((B/'audit/MODEL_CONTRACT.json').read_text());standing=json.loads((B/'audit/STANDING_BANK.json').read_text())
        assert standing['status']=='PASS' and standing['model_sha256']==c['model_sha256']
        neutral=B/'inputs/HOME_nominal_bank.npz'
        height=float(np.median(np.load(neutral)['qpos'][:,2])) if neutral.exists() else standing['median_height_m']
        c['settled_standing_height_m']=height;c['randomized_bank_median_height_m']=standing['median_height_m'];c['standing_height_band_m']=[height-.02,height+.02];c['fall_height_m']=height-.07
        (B/'audit/MODEL_CONTRACT.json').write_text(json.dumps(c,indent=2))
    else:c=model()
    patch_sources(c)
    from fix_body_frame import apply as fix_body_frames
    fix_body_frames()
    configs(c)
    print(json.dumps(c,indent=2))

"""Remove unconditional allocator/GC work from the hot reset path."""
from pathlib import Path
import ast,json,hashlib

OPTIMIZED_FORWARD='''    def _execute_device_forward(self):
        # Same simulation forward. Reclaim memory only under pressure or after OOM.
        profile=getattr(self,'_reset_guard_profile',None)
        if profile is None:
            profile={'calls':0,'memory_reclaims':0,'oom_retries':0,'seconds':0.0}
            self._reset_guard_profile=profile
        profile['calls']+=1
        elapsed_start=time.monotonic()
        timeout=float(os.environ.get('XDUCK_RESET_WAIT_TIMEOUT_S','600'))
        try:
            for attempt in range(3):
                started=time.monotonic()
                reclaimed=False
                while True:
                    free,total=torch.cuda.mem_get_info()
                    if free>=7*1024**3:break
                    if not reclaimed:
                        self._warp.synchronize_device()
                        torch.cuda.empty_cache()
                        gc.collect()
                        profile['memory_reclaims']+=1
                        reclaimed=True
                        continue
                    if timeout>0 and time.monotonic()-started>timeout:
                        raise RuntimeError(f'GPU reset workspace unavailable: {free} bytes free; require7GiB')
                    print('RESET_WORKSPACE_WAIT',free,flush=True)
                    time.sleep(2)
                    torch.cuda.empty_cache()
                allocation_failure=None
                try:
                    return super()._execute_device_forward()
                except RuntimeError as error:
                    if 'Failed to allocate' not in str(error) and 'out of memory' not in str(error).lower():raise
                    allocation_failure=str(error)
                # Keep the old fail-safe retry after releasing exception references.
                gc.collect()
                torch.cuda.empty_cache()
                profile['memory_reclaims']+=1
                profile['oom_retries']+=1
                if attempt==2:raise RuntimeError(allocation_failure)
                print('RESET_WORKSPACE_RETRY',allocation_failure,flush=True)
                time.sleep(2)
        finally:
            profile['seconds']+=time.monotonic()-elapsed_start

'''

def optimized_source(s):
    for module in ['os','gc']:
        if 'import '+module+'\n' not in s:s=s.replace('import time\n','import time\nimport '+module+'\n',1)
    end=s.index('    def _initialize_cuda_graphs(')
    start=s.find('    def _execute_device_forward(self):')
    if start<0:start=end
    result=s[:start]+OPTIMIZED_FORWARD+s[end:];ast.parse(result);return result

if __name__=='__main__':
    b=Path(__file__).resolve().parents[1];backup=b/'audit/reset_optimization_backup';records=[]
    for p in (b/'workspace').glob('*/project/src/unilab/base/backend/mjwarp/xduck_gf.py'):
        old=p.read_bytes();s=optimized_source(old.decode());dest=backup/p.relative_to(b);dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():dest.write_bytes(old)
        p.write_text(s);records.append(dict(path=str(p.relative_to(b)),before=hashlib.sha256(old).hexdigest(),after=hashlib.sha256(p.read_bytes()).hexdigest()))
    (b/'audit/RESET_OPTIMIZATION_PATCHES.json').write_text(json.dumps(records,indent=2));print('Patched',len(records),'isolated backend copies')
